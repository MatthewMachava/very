#!/usr/bin/env python3
"""
Script para criar um funcionário do tipo "verificar" no sistema Emme Verificação
"""

import sys
import os
import hashlib
import json
from datetime import datetime

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from firebase_manager import FirebaseManager
from database_manager import DatabaseManager

def criar_funcionario_verificar():
    """Cria um funcionário do tipo verificar"""

    # Dados do funcionário
    funcionario_data = {
        'nome': 'João Verificador',
        'codigo': 'VER001',
        'email': 'verificar@emme.com',
        'tipo': 'verificar',
        'status': 'ativo',
        'meta_diaria': 250,
        'data_criacao': datetime.now().isoformat(),
        'permissoes': {
            'verificar_matriculas': True,
            'registrar_viaturas': True,
            'visualizar_relatorios': False,
            'gerir_usuarios': False,
            'gerir_senhas': False
        }
    }

    # Senha inicial
    senha = 'Verificar123!'
    password_hash = hashlib.sha256(senha.encode()).hexdigest()

    print("🔧 Iniciando criação do funcionário...")
    print(f"📧 Email: {funcionario_data['email']}")
    print(f"👤 Nome: {funcionario_data['nome']}")
    print(f"🏷️  Tipo: {funcionario_data['tipo']}")
    print(f"📊 Meta diária: {funcionario_data['meta_diaria']}")

    # Inicializar gerenciadores
    firebase = FirebaseManager()
    db_manager = DatabaseManager()

    try:
        # Primeiro, tentar criar usuário no Firebase Auth
        print("\n🔐 Criando usuário no Firebase Auth...")
        user, error = firebase.sign_in_with_email_and_password(funcionario_data['email'], senha)

        if error:
            # Se o usuário já existe, vamos apenas atualizar os dados
            if 'EMAIL_EXISTS' in error or 'already exists' in error.lower():
                print("⚠️  Usuário já existe no Firebase Auth, continuando...")
            else:
                print(f"❌ Erro ao criar usuário no Firebase Auth: {error}")
                return False

        # Obter o user_id (se conseguiu criar ou se já existia)
        if user and 'localId' in user:
            user_id = user['localId']
        else:
            # Tentar fazer login para obter o user_id
            user, error = firebase.login_user(funcionario_data['email'], senha)
            if user and 'localId' in user:
                user_id = user['localId']
            else:
                print("❌ Não foi possível obter o user_id do usuário")
                return False

        print(f"✅ User ID obtido: {user_id}")

        # Salvar dados do funcionário no Firebase (/Funcionarios/{user_id})
        print("\n💾 Salvando dados do funcionário no Firebase...")
        path = f"Funcionarios/{user_id}"

        success, message = firebase.get_db_data(path)
        if success is None:  # Caminho não existe, pode salvar
            # Usar requests diretamente para salvar
            import requests

            url = f"{firebase.config['databaseURL']}/{path}.json"
            params = {'auth': firebase.id_token} if firebase.id_token else {}

            response = requests.put(url, params=params, json=funcionario_data, timeout=10)

            if response.status_code == 200:
                print("✅ Dados do funcionário salvos no Firebase com sucesso")
            else:
                print(f"❌ Erro ao salvar no Firebase: {response.status_code} - {response.text}")
                return False
        else:
            print("⚠️  Funcionário já existe no Firebase, atualizando dados...")

            # Atualizar dados existentes
            url = f"{firebase.config['databaseURL']}/{path}.json"
            params = {'auth': firebase.id_token} if firebase.id_token else {}

            response = requests.patch(url, params=params, json=funcionario_data, timeout=10)

            if response.status_code == 200:
                print("✅ Dados do funcionário atualizados no Firebase")
            else:
                print(f"❌ Erro ao atualizar no Firebase: {response.status_code} - {response.text}")

        # Salvar no banco local
        print("\n💽 Salvando no banco de dados local...")
        stats_iniciais = {
            'pesquisas': 0,
            'registros': 0,
            'ultimas_viaturas': [],
            'ultimas_verificacoes': [],
            'meta_diaria': funcionario_data['meta_diaria']
        }

        success = db_manager.save_user(
            email=funcionario_data['email'],
            password_hash=password_hash,
            firebase_uid=user_id,
            stats=stats_iniciais
        )

        if success:
            print("✅ Funcionário salvo no banco local com sucesso")

            # Adicionar ao histórico
            db_manager.add_historico(
                funcionario_data['email'],
                'criacao_funcionario',
                None,
                f'Funcionário {funcionario_data["tipo"]} criado: {funcionario_data["nome"]}'
            )
            print("✅ Histórico de criação adicionado")
        else:
            print("❌ Erro ao salvar no banco local")
            return False

        print("\n🎉 Funcionário criado com sucesso!")
        print("\n" + "="*50)
        print("DADOS DO FUNCIONÁRIO CRIADO:")
        print("="*50)
        print(f"Nome: {funcionario_data['nome']}")
        print(f"Email: {funcionario_data['email']}")
        print(f"Tipo: {funcionario_data['tipo']}")
        print(f"Código: {funcionario_data['codigo']}")
        print(f"Status: {funcionario_data['status']}")
        print(f"Meta diária: {funcionario_data['meta_diaria']}")
        print(f"Senha inicial: {senha}")
        print("="*50)
        print("\n⚠️  IMPORTANTE: Anote a senha inicial e forneça ao funcionário!")
        print("   O funcionário deve alterar a senha no primeiro login.")

        return True

    except Exception as e:
        print(f"❌ Erro inesperado: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🚀 Criando funcionário do tipo 'verificar'...")
    sucesso = criar_funcionario_verificar()

    if sucesso:
        print("\n✅ Processo concluído com sucesso!")
        sys.exit(0)
    else:
        print("\n❌ Falha na criação do funcionário!")
        sys.exit(1)
