#!/usr/bin/env python3
"""
Script para criar usuário administrador no Firebase
"""

import sys
import os
import json
import hashlib
from datetime import datetime

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from firebase_manager import FirebaseManager
from database_manager import DatabaseManager

def create_admin_user():
    """Cria usuário administrador no Firebase"""

    print("🚀 Criando usuário administrador...")

    # Dados do admin
    admin_email = "admin@emme.com"
    admin_password = "admin123456"
    admin_name = "Administrador Sistema"
    admin_code = "ADM001"

    # Inicializar Firebase
    firebase = FirebaseManager()
    db_manager = DatabaseManager()

    try:
        print("🔐 Criando usuário no Firebase Auth...")

        # Criar usuário no Firebase Auth
        user_result, error = firebase.create_user(admin_email, admin_password)

        if not user_result:
            if "EMAIL_EXISTS" in str(error):
                print("⚠️  Usuário administrador já existe, tentando fazer login...")
                # Tentar fazer login em vez de criar
                user_result, login_error = firebase.sign_in_with_email_and_password(admin_email, admin_password)
                if not user_result:
                    print(f"❌ Erro ao fazer login no usuário existente: {login_error}")
                    return False
                print("✅ Login realizado com sucesso no usuário administrador existente")
            else:
                print(f"❌ Erro ao criar usuário no Firebase Auth: {error}")
                return False

        user_id = user_result.get('localId')
        if not user_id:
            print("❌ User ID não obtido")
            return False

        print(f"✅ Usuário criado com sucesso. User ID: {user_id}")

        # Salvar dados do funcionário no Firebase
        print("💾 Salvando dados do administrador no Firebase...")

        admin_data = {
            'nome': admin_name,
            'codigo': admin_code,
            'email': admin_email,
            'tipo': 'admin',
            'status': 'ativo',
            'permissoes': {
                'gerir_senhas': True,
                'gerir_funcionarios': True,
                'ver_relatorios': True,
                'gerir_pagamentos': True
            },
            'data_criacao': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'meta_diaria': 0
        }

        # Primeiro, tentar salvar na estrutura Funcionarios
        success, message = firebase.save_funcionario_data(user_id, admin_data)

        if not success:
            print(f"⚠️ Erro ao salvar em Funcionarios: {message}")
            print("🔄 Tentando abordagem alternativa...")

            # Abordagem alternativa: salvar diretamente no caminho
            try:
                # Salvar dados do funcionário
                path_funcionario = f"Funcionarios/{user_id}"
                success_func, msg_func = firebase.set_db_data(path_funcionario, admin_data)

                # Salvar na lista de admins
                path_admin = f"admins/{user_id}"
                admin_ref = {'email': admin_email, 'nome': admin_name, 'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                success_admin, msg_admin = firebase.set_db_data(path_admin, admin_ref)

                if success_func and success_admin:
                    print("✅ Administrador criado com sucesso via abordagem alternativa!")
                else:
                    print(f"❌ Erro na abordagem alternativa: Func={msg_func}, Admin={msg_admin}")
                    return False

            except Exception as e:
                print(f"❌ Erro na abordagem alternativa: {str(e)}")
                return False
        else:
            print("✅ Administrador criado com sucesso!")

        # Salvar no banco local
        print("💾 Salvando no banco local...")
        password_hash = hashlib.sha256(admin_password.encode()).hexdigest()

        success_local = db_manager.save_user(
            email=admin_email,
            password_hash=password_hash,
            firebase_uid=user_id,
            stats={
                'pesquisas': 0,
                'registros': 0,
                'ultimas_viaturas': [],
                'meta_diaria': 0
            }
        )

        if success_local:
            print("✅ Dados salvos no banco local!")
        else:
            print("⚠️ Erro ao salvar no banco local")

        # Criar arquivo de configuração para facilitar login
        config = {
            'admin_email': admin_email,
            'admin_password': admin_password,
            'admin_user_id': user_id,
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        with open('admin_config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        print("✅ Arquivo de configuração criado: admin_config.json")

        print("\n" + "="*50)
        print("🎉 ADMINISTRADOR CRIADO COM SUCESSO!")
        print("="*50)
        print(f"📧 Email: {admin_email}")
        print(f"🔑 Senha: {admin_password}")
        print(f"🆔 User ID: {user_id}")
        print("="*50)
        print("⚠️ IMPORTANTE: Use essas credenciais para fazer login")
        print("⚠️ e criar outros funcionários do sistema.")
        print("="*50)

        return True

    except Exception as e:
        print(f"❌ Erro geral: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

    finally:
        db_manager.disconnect()

if __name__ == '__main__':
    success = create_admin_user()
    if success:
        print("\n✅ Processo concluído com sucesso!")
        sys.exit(0)
    else:
        print("\n❌ Processo falhou!")
        sys.exit(1)
