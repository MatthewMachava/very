import logging
from typing import Dict, List, Optional, Tuple, Union, Any
from datetime import datetime, timedelta
import re
import requests
import pyrebase
from time import sleep
import time  # Adicione esta importação
from requests.exceptions import HTTPError, RequestException
import json
from kivy.storage.jsonstore import JsonStore
from offline_cache_manager import OfflineCacheManager

class FirebaseManager:
    def __init__(self):
        """Inicializa o gerenciador do Firebase com tratamento robusto de erros."""
        self.logger = self._setup_logging()
        self.config = self._load_config()
        self.offline_mode = False
        self._initialize_components()
        
        try:
            self._initialize_firebase()
            self._load_saved_tokens()  # Carrega tokens salvos
        except Exception as e:
            self.logger.warning(f"Firebase indisponível, operando em modo offline: {str(e)}")
            self.offline_mode = True
            self._setup_offline_mode()

    def _initialize_components(self):
        """Inicializa todos os componentes principais."""
        self.firebase = None
        self.auth = None
        self.db = None
        self.id_token = None
        self.refresh_token = None
        self.token_expiration = None
        self.user_id = None
        self.offline_cache = OfflineCacheManager()

    # ============ SISTEMA DE TOKENS MELHORADO ============

    def get_valid_token(self) -> Optional[str]:
        """Obtém um token válido, renovando automaticamente se necessário."""
        if self.offline_mode:
            return "offline_token"
            
        if self._is_token_expired():
            self.logger.info("Token expirado, tentando renovar...")
            success = self._refresh_token()
            if not success:
                self.logger.error("Falha ao renovar token")
                return None
                
        return self.id_token

    def _is_token_expired(self) -> bool:
        """Verifica se o token expirou (com margem de segurança de 5 minutos)."""
        if not self.token_expiration:
            return True
            
        # Adiciona margem de segurança de 5 minutos
        safety_margin = timedelta(minutes=5)
        return datetime.now() > (self.token_expiration - safety_margin)

    def _refresh_token(self) -> bool:
        """Renova o token usando refresh_token - MÉTODO CORRIGIDO."""
        if not self.refresh_token:
            self.logger.error("Nenhum refresh token disponível")
            return False
            
        try:
            # URL correta para refresh token
            url = f"https://securetoken.googleapis.com/v1/token?key={self.config['apiKey']}"
            
            payload = {
                "grant_type": "refresh_token",
                "refresh_token": self.refresh_token
            }
            
            headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            }
            
            response = requests.post(url, data=payload, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                
                # Atualiza tokens
                self.id_token = data.get('id_token')
                self.refresh_token = data.get('refresh_token', self.refresh_token)
                
                if not self.id_token:
                    self.logger.error("Token ID não encontrado na resposta de refresh")
                    return False
                    
                # Calcula novo tempo de expiração
                expires_in = data.get('expires_in', 3600)
                self.token_expiration = datetime.now() + timedelta(seconds=expires_in)
                
                self._save_tokens()
                self.logger.info("Token renovado com sucesso")
                return True
                
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(f"Falha ao renovar token: {error_msg}")
                self._clear_tokens()
                return False
                
        except Exception as e:
            self.logger.error(f"Exceção ao renovar token: {str(e)}")
            self._clear_tokens()
            return False

    def ensure_valid_token(self) -> Tuple[bool, Optional[str]]:
        """Garante que temos um token válido - MÉTODO ATUALIZADO."""
        if self.offline_mode:
            return True, None
        
        token = self.get_valid_token()
        if token:
            return True, None
        else:
            return False, "Não foi possível obter token válido"

    # ============ MÉTODOS DE AUTENTICAÇÃO ATUALIZADOS ============

    def _login_online(self, email: str, password: str) -> Tuple[Optional[dict], Optional[str]]:
        """Autenticação em modo online - MÉTODO ATUALIZADO."""
        try:
            self.logger.info(f"Tentando login para: {email}")
            
            # Limpa tokens anteriores
            self._clear_tokens()
            
            # Usa método direto com requests para maior controle
            url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={self.config['apiKey']}"
            
            payload = {
                "email": email,
                "password": password,
                "returnSecureToken": True
            }
            
            response = requests.post(url, json=payload, timeout=10)
            result = response.json()
            
            if response.status_code == 200:
                # Atualiza tokens
                self.id_token = result['idToken']
                self.refresh_token = result.get('refreshToken', '')
                self.user_id = result['localId']
                self.token_expiration = datetime.now() + timedelta(seconds=3600)
                
                self._save_tokens()
                self.logger.info(f"Usuário {email} autenticado com sucesso")
                
                return {
                    'idToken': self.id_token,
                    'refreshToken': self.refresh_token,
                    'localId': self.user_id,
                    'email': result['email']
                }, None
                
            else:
                error_msg = result.get('error', {}).get('message', 'Erro desconhecido')
                translated_error = self._translate_error(error_msg)
                self.logger.error(f"Erro de autenticação: {translated_error}")
                return None, translated_error

        except Exception as e:
            error_msg = f"Erro inesperado durante login: {str(e)}"
            self.logger.error(error_msg)
            return None, error_msg

    # ============ OPERAÇÕES COM VIATURAS ATUALIZADAS ============

    def _check_viatura_online(self, matricula: str) -> Optional[dict]:
        """Consulta viatura em modo online - MÉTODO ATUALIZADO."""
        # Garante token válido usando novo método
        token = self.get_valid_token()
        if not token:
            self.logger.error("Token inválido para consulta")
            return None

        try:
            url = f"{self.config['databaseURL']}/multas.json"
            params = {
                'auth': token,  # Usa token válido
                'orderBy': '"matricula"',
                'equalTo': f'"{matricula.upper()}"'
            }

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                result = None
                if data:
                    # Filtra para garantir que é a matrícula exata
                    filtered_data = {
                        key: val for key, val in data.items()
                        if val and val.get('matricula') == matricula.upper()
                    }
                    result = filtered_data if filtered_data else None

                # Armazena no cache offline se encontrou resultado
                if result:
                    self.offline_cache.cache_matricula_verification(matricula, result)

                return result
                
            elif response.status_code == 401:
                self.logger.warning("Token inválido durante consulta - tentando renovar")
                # Tenta renovar token e refazer a consulta
                if self._refresh_token():
                    return self._check_viatura_online(matricula)
                return None
                
            else:
                self.logger.error(f"Erro HTTP na consulta: {response.status_code}")
                return None

        except Exception as e:
            self.logger.error(f"Erro na consulta online: {str(e)}")
            return None

    def add_viatura(self, dados_viatura):
        """Adiciona uma viatura ao Firebase - MÉTODO ATUALIZADO."""
        matricula = dados_viatura['matricula'].upper()

        if self.offline_mode:
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return True, "Registro salvo offline para sincronização posterior"

        # Garante token válido usando novo método
        token = self.get_valid_token()
        if not token:
            self.logger.warning("Token inválido, armazenando offline")
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, "Erro de autenticação. Dados salvos offline."

        try:
            viatura_data = {
                'matricula': matricula,
                'local': dados_viatura['local'],
                'data_registro': dados_viatura['data_registro'],
                'hora_registro': dados_viatura['hora_registro'],
                'status': 'pendente',
                'usuario': self.user_id,
                'estado_pagamento': dados_viatura.get('estado_pagamento', 'pendente'),
                'latitude': dados_viatura.get('latitude'),
                'longitude': dados_viatura.get('longitude'),
                'timestamp': datetime.now().isoformat()
            }

            # Remove campos None
            viatura_data = {k: v for k, v in viatura_data.items() if v is not None}

            url = f"{self.config['databaseURL']}/multas/{matricula}.json"
            params = {'auth': token}

            response = requests.put(url, params=params, json=viatura_data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Viatura {matricula} salva com sucesso")
                self.offline_cache.mark_registration_synced(matricula)
                return True, "Registro salvo com sucesso"
                
            elif response.status_code == 401:
                self.logger.warning("Token inválido ao salvar - tentando renovar")
                if self._refresh_token():
                    return self.add_viatura(dados_viatura)  # Recursão com token renovado
                else:
                    self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
                    return False, "Erro de autenticação. Dados salvos offline."
                    
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
                return False, f"{error_msg}. Dados salvos offline."

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão: {str(e)}")
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, "Erro de conexão. Dados salvos offline."
        except Exception as e:
            self.logger.error(f"Erro inesperado: {str(e)}")
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, f"Erro inesperado. Dados salvos offline."

    # ============ OPERAÇÕES DE BANCO DE DADOS ATUALIZADAS ============

    def get_db_data(self, path):
        """Busca dados do Firebase Realtime Database - MÉTODO ATUALIZADO."""
        try:
            # Usa novo método para token válido
            token = self.get_valid_token()
            if not token:
                self.logger.error("Token inválido para buscar dados")
                return None
            
            # Remove barras extras
            if path.startswith('/'):
                path = path[1:]
                
            url = f"{self.config['databaseURL']}/{path}.json"
            params = {'auth': token}
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.logger.info(f"Dados encontrados no caminho: {path}")
                return data
                
            elif response.status_code == 401:
                self.logger.warning("Token inválido na busca - tentando renovar")
                if self._refresh_token():
                    return self.get_db_data(path)  # Recursão com token renovado
                return None
                
            elif response.status_code == 404:
                self.logger.info(f"Caminho não encontrado: {path}")
                return None
                
            else:
                self.logger.error(f"Erro ao buscar dados ({response.status_code}): {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Exception ao buscar dados: {str(e)}")
            return None

    def set_db_data(self, path: str, data: dict) -> Tuple[bool, str]:
        """Define dados em um caminho específico - MÉTODO ATUALIZADO."""
        try:
            token = self.get_valid_token()
            if not token:
                return False, "Token inválido"

            if path.startswith('/'):
                path = path[1:]

            url = f"{self.config['databaseURL']}/{path}.json"
            params = {'auth': token}

            response = requests.put(url, params=params, json=data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Dados salvos com sucesso no caminho: {path}")
                return True, "Dados salvos com sucesso"
                
            elif response.status_code == 401:
                self.logger.warning("Token inválido ao salvar - tentando renovar")
                if self._refresh_token():
                    return self.set_db_data(path, data)  # Recursão com token renovado
                return False, "Erro de autenticação após tentativa de renovação"
                
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                return False, error_msg

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao salvar dados: {str(e)}")
            return False, "Erro de conexão"
        except Exception as e:
            self.logger.error(f"Erro inesperado ao salvar dados: {str(e)}")
            return False, f"Erro inesperado: {str(e)}"

    # ============ MÉTODOS DE GERENCIAMENTO DE SESSÃO ============

    def get_session_info(self) -> Dict[str, Any]:
        """Retorna informações da sessão atual para debug."""
        return {
            'has_token': self.id_token is not None,
            'has_refresh_token': self.refresh_token is not None,
            'token_expiration': self.token_expiration.isoformat() if self.token_expiration else None,
            'user_id': self.user_id,
            'offline_mode': self.offline_mode,
            'is_token_expired': self._is_token_expired() if self.token_expiration else True
        }

    def force_token_refresh(self) -> bool:
        """Força a renovação do token independente do estado."""
        self.logger.info("Forçando renovação de token...")
        return self._refresh_token()

    # ============ MÉTODOS EXISTENTES (MANTIDOS) ============

    def _setup_logging(self) -> logging.Logger:
        """Configura o sistema de logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)

    def _load_config(self) -> Dict[str, str]:
        """Carrega a configuração do Firebase."""
        return {
            'apiKey': "AIzaSyBuSy5DSN4L4RaQTAk85J_8YihabvuK2E0",
            'authDomain': "emmeprojectv01.firebaseapp.com",
            'databaseURL': "https://emmeprojectv01-default-rtdb.firebaseio.com",
            'projectId': "emmeprojectv01",
            'storageBucket': "emmeprojectv01.firebasestorage.app",
            'messagingSenderId': "645297307648",
            'appId': "1:645297307648:web:89f3afd5a52fa319fdd8e5",
            'measurementId': "G-70ND6HFKWS"
        }

    def _initialize_firebase(self):
        """Configura a conexão com o Firebase."""
        try:
            self.firebase = pyrebase.initialize_app(self.config)
            self.auth = self.firebase.auth()
            self.db = self.firebase.database()
            self.logger.info("Firebase inicializado com sucesso")
        except Exception as e:
            self.logger.error(f"Falha na inicialização do Firebase: {str(e)}")
            raise RuntimeError("Não foi possível inicializar o Firebase")

    def _load_saved_tokens(self):
        """Carrega tokens salvos do armazenamento local."""
        try:
            store = JsonStore('firebase_tokens.json')
            if store.exists('auth'):
                auth_data = store.get('auth')
                self.id_token = auth_data.get('idToken')
                self.refresh_token = auth_data.get('refreshToken')
                expiry_str = auth_data.get('expiry')
                if expiry_str:
                    self.token_expiration = datetime.fromisoformat(expiry_str)
                self.user_id = auth_data.get('userId')
                
                if self.id_token and self.token_expiration:
                    if datetime.now() < self.token_expiration - timedelta(minutes=5):
                        self.logger.info("Token válido encontrado no armazenamento local")
                    else:
                        self.logger.info("Token expirado, será necessário refresh")
                        self.id_token = None
        except Exception as e:
            self.logger.warning(f"Erro ao carregar tokens salvos: {e}")

    def _save_tokens(self):
        """Salva tokens no armazenamento local."""
        try:
            store = JsonStore('firebase_tokens.json')
            store.put('auth',
                idToken=self.id_token,
                refreshToken=self.refresh_token,
                expiry=self.token_expiration.isoformat() if self.token_expiration else None,
                userId=self.user_id
            )
            self.logger.debug("Tokens salvos com sucesso")
        except Exception as e:
            self.logger.error(f"Erro ao salvar tokens: {e}")

    def _clear_tokens(self):
        """Limpa todos os tokens."""
        self.id_token = None
        self.refresh_token = None
        self.token_expiration = None
        self.user_id = None
        try:
            store = JsonStore('firebase_tokens.json')
            store.delete('auth')
        except:
            pass

    def _setup_offline_mode(self):
        """Configura o modo offline com dados mock."""
        self.logger.info("Configurando modo offline...")
        self.mock_database = {
            "ABC-123-CD": {
                "matricula": "ABC-123-CD",
                "data_registro": "2024-01-15 10:30:00",
                "local": "Maputo",
                "usuario": "teste@emme.com",
                "status": "pendente"
            }
        }

    def get_estacionamentos_verificador(self):
        """Método ESPECÍFICO para verificador - acesso a todos estacionamentos"""
        try:
            token = self.get_valid_token()
            if not token:
                logging.error("❌ Token inválido")
                return None
                
            # Verifica se é funcionário/autorizado
            if not self._is_funcionario():
                logging.warning("❌ Usuário não é funcionário")
                return None
                
            url = f"{self.config['databaseURL']}/estacionamentos.json"
            params = {'auth': token}
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                logging.info(f"✅ Verificador - {len(data) if data else 0} estacionamentos encontrados")
                return data
            else:
                logging.error(f"❌ Erro {response.status_code}: {response.text}")
                return None
                
        except Exception as e:
            logging.error(f"❌ Erro ao buscar estacionamentos: {str(e)}")
            return None

    def _is_funcionario(self):
        """Verifica se o usuário atual é funcionário"""
        try:
            if not self.user_id:
                return False
                
            funcionario_data = self.get_db_data(f"Funcionarios/{self.user_id}")
            return funcionario_data is not None
            
        except Exception as e:
            logging.error(f"Erro ao verificar funcionário: {str(e)}")
            return False
    
    def login_user(self, email: str, password: str) -> Tuple[Optional[dict], Optional[str]]:
        """Autentica um usuário com email e senha."""
        if not email or not password:
            return None, "Email e senha são obrigatórios"

        if "@" not in email or "." not in email:
            return None, "Formato de email inválido"

        if self.offline_mode:
            return self._login_offline(email, password)
        else:
            return self._login_online(email, password)

    def _login_offline(self, email: str, password: str) -> Tuple[Optional[dict], Optional[str]]:
        """Autenticação em modo offline."""
        if email in self.mock_users and self.mock_users[email]['password'] == password:
            user = self.mock_users[email].copy()
            self.id_token = user['idToken']
            self.refresh_token = user['refreshToken']
            self.user_id = user['localId']
            self.token_expiration = datetime.now() + timedelta(seconds=3600)
            self.logger.info(f"Usuário {email} autenticado com sucesso (modo offline)")
            return user, None
        else:
            return None, "Credenciais inválidas (modo offline)"

    def _login_online(self, email: str, password: str) -> Tuple[Optional[dict], Optional[str]]:
        """Autenticação em modo online."""
        try:
            self.logger.info(f"Tentando login para: {email}")
            
            # Limpa tokens anteriores
            self._clear_tokens()
            
            # Tenta fazer login
            user = self.auth.sign_in_with_email_and_password(email, password)

            if not user:
                return None, "Resposta de autenticação vazia"

            # Verifica se temos os campos necessários
            if not all(key in user for key in ['idToken', 'refreshToken', 'localId']):
                self.logger.error(f"Resposta incompleta: {user.keys()}")
                return None, "Resposta de autenticação incompleta"

            self._update_tokens_from_response(user)
            self._save_tokens()
            
            self.logger.info(f"Usuário {email} autenticado com sucesso")
            return user, None

        except HTTPError as e:
            error_msg = self._extract_error_message(e)
            translated_error = self._translate_error(error_msg)
            self.logger.error(f"Erro de autenticação HTTP: {translated_error}")
            
            # Log detalhado para debugging
            if hasattr(e, 'response') and e.response is not None:
                self.logger.error(f"Status code: {e.response.status_code}")
                self.logger.error(f"Response: {e.response.text}")
            
            return None, translated_error

        except Exception as e:
            error_msg = f"Erro inesperado durante login: {str(e)}"
            self.logger.error(error_msg)
            return None, error_msg

    def create_user(self, email: str, password: str) -> Tuple[Optional[dict], Optional[str]]:
        """Cria um novo usuário no Firebase Auth."""
        try:
            import requests
            import json

            url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={self.config['apiKey']}"

            payload = {
                "email": email,
                "password": password,
                "returnSecureToken": True
            }

            response = requests.post(url, json=payload)
            result = response.json()

            if response.status_code == 200:
                # Salva os tokens
                self.id_token = result['idToken']
                self.refresh_token = result.get('refreshToken', '')
                self.user_id = result['localId']

                return {
                    'idToken': self.id_token,
                    'refreshToken': self.refresh_token,
                    'localId': self.user_id,
                    'email': result['email']
                }, None
            else:
                error_msg = result.get('error', {}).get('message', 'Erro desconhecido')
                return None, error_msg

        except Exception as e:
            return None, f"Erro de conexão: {str(e)}"

    def sign_in_with_email_and_password(self, email, password):
        """Faz login com email e senha"""
        try:
            import requests
            import json

            url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={self.config['apiKey']}"

            payload = {
                "email": email,
                "password": password,
                "returnSecureToken": True
            }

            response = requests.post(url, json=payload)
            result = response.json()

            if response.status_code == 200:
                # Salva os tokens
                self.id_token = result['idToken']
                self.refresh_token = result.get('refreshToken', '')
                self.user_id = result['localId']

                return {
                    'idToken': self.id_token,
                    'refreshToken': self.refresh_token,
                    'localId': self.user_id,
                    'email': result['email']
                }, None
            else:
                error_msg = result.get('error', {}).get('message', 'Erro desconhecido')
                return None, error_msg

        except Exception as e:
            return None, f"Erro de conexão: {str(e)}"
    
    def refresh_id_token(self) -> Tuple[Optional[dict], Optional[str]]:
        """Atualiza o token de autenticação usando o refresh token."""
        if not self.refresh_token:
            return None, "Nenhum refresh token disponível"
        
        try:
            # Método correto para refresh no Pyrebase
            user = self.auth.refresh(self.refresh_token)
            
            if not user:
                return None, "Resposta de refresh vazia"
            
            # Atualiza tokens
            self.id_token = user.get('idToken') or user.get('id_token')
            new_refresh = user.get('refreshToken') or user.get('refresh_token')
            if new_refresh:
                self.refresh_token = new_refresh
            self.user_id = user.get('localId') or user.get('user_id')
            
            if not self.id_token:
                return None, "Token ID não encontrado na resposta"
            
            self.token_expiration = datetime.now() + timedelta(seconds=3500)
            self._save_tokens()  # Salva tokens atualizados
            self.logger.info("Token renovado com sucesso")
            
            return {
                'idToken': self.id_token,
                'refreshToken': self.refresh_token,
                'localId': self.user_id
            }, None
            
        except HTTPError as e:
            error_msg = self._extract_error_message(e)
            self.logger.error(f"Erro HTTP ao renovar token: {error_msg}")
            # Limpa tokens inválidos
            self._clear_tokens()
            return None, f"Erro de autenticação: {error_msg}"
            
        except Exception as e:
            self.logger.error(f"Erro inesperado ao renovar token: {str(e)}")
            return None, f"Erro inesperado: {str(e)}"

    def _update_tokens_from_response(self, user_response: dict):
        """Atualiza os tokens a partir da resposta do Firebase."""
        self.id_token = user_response['idToken']
        self.refresh_token = user_response.get('refreshToken', self.refresh_token)
        self.user_id = user_response.get('localId', self.user_id)
        self.token_expiration = datetime.now() + timedelta(seconds=3500)

    def _clear_tokens(self):
        """Limpa todos os tokens."""
        self.id_token = None
        self.refresh_token = None
        self.token_expiration = None
        self.user_id = None
        try:
            store = JsonStore('firebase_tokens.json')
            store.delete('auth')
        except:
            pass

    def is_token_expired(self) -> bool:
        """Verifica se o token expirou."""
        if not self.token_expiration:
            return True
        return datetime.now() >= self.token_expiration

    def ensure_valid_token(self) -> Tuple[bool, Optional[str]]:
        """Garante que temos um token válido antes de operações - CORRIGIDO"""
        if self.offline_mode:
            return True, None
        
        # Se não tem token ou token expirado, tenta renovar
        if not self.id_token or self.is_token_expired():
            self.logger.warning("Token inválido ou expirado, renovando...")
            user, error = self.refresh_id_token()
            if error:
                self.logger.error(f"Falha ao renovar token: {error}")
                return False, error
        
        return True, None

    def logout(self):
        """Realiza logout e limpa todos os tokens."""
        self._clear_tokens()
        self.logger.info("Usuário deslogado com sucesso")

    # ============ OPERAÇÕES COM VIATURAS ============
    
    def check_viatura(self, matricula: str) -> Optional[dict]:
        """Consulta uma viatura no banco de dados."""
        if not self._validate_plate(matricula):
            return None

        # Primeiro, tenta buscar no cache offline se estiver válido
        cached_result = self.offline_cache.get_cached_verification(matricula)
        if cached_result:
            self.logger.info(f"Resultado encontrado no cache offline para {matricula}")
            return cached_result

        if self.offline_mode:
            return self._check_viatura_offline(matricula)
        else:
            return self._check_viatura_online(matricula)

    def _check_viatura_offline(self, matricula: str) -> Optional[dict]:
        """Consulta viatura em modo offline."""
        matricula_upper = matricula.upper()
        if matricula_upper in self.mock_database:
            self.logger.info(f"Viatura encontrada no modo offline: {matricula_upper}")
            return {matricula_upper: self.mock_database[matricula_upper]}
        else:
            self.logger.info(f"Viatura não encontrada no modo offline: {matricula_upper}")
            return None

    def _check_viatura_online(self, matricula: str) -> Optional[dict]:
        """Consulta viatura em modo online."""
        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            self.logger.error(f"Token inválido para consulta: {error}")
            return None

        try:
            # Usa requests diretamente para maior confiabilidade
            url = f"{self.config['databaseURL']}/multas.json"
            params = {
                'auth': self.id_token,
                'orderBy': '"matricula"',
                'equalTo': f'"{matricula.upper()}"'
            }

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                result = None
                if data:
                    # Filtra para garantir que é a matrícula exata
                    filtered_data = {
                        key: val for key, val in data.items()
                        if val and val.get('matricula') == matricula.upper()
                    }
                    result = filtered_data if filtered_data else None

                # Armazena no cache offline se encontrou resultado
                if result:
                    self.offline_cache.cache_matricula_verification(matricula, result)

                return result
            elif response.status_code == 401:
                self.logger.warning("Token inválido durante consulta")
                return None
            else:
                self.logger.error(f"Erro HTTP na consulta: {response.status_code}")
                return None

        except Exception as e:
            self.logger.error(f"Erro na consulta online: {str(e)}")
            return None

    def add_viatura(self, dados_viatura):
        """Adiciona uma viatura ao Firebase"""
        matricula = dados_viatura['matricula'].upper()

        if self.offline_mode:
            # Em modo offline, armazena no cache para sincronização posterior
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return self._add_viatura_offline(
                dados_viatura['matricula'],
                dados_viatura['local'],
                dados_viatura['usuario']
            )

        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            # Se não conseguir token válido, armazena no cache offline
            self.logger.warning(f"Token inválido, armazenando offline: {error}")
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, f"Erro de autenticação. Dados salvos offline para sincronização posterior."

        try:
            # Estrutura completa conforme esperado pelo Firebase
            # Nota: 'usuario' deve ser auth.uid (user_id), não o email
            # 'status' deve ser 'pendente', 'paga', ou 'cancelada'
            viatura_data = {
                'matricula': matricula,
                'local': dados_viatura['local'],
                'data_registro': dados_viatura['data_registro'],
                'hora_registro': dados_viatura['hora_registro'],
                'status': 'pendente',  # Status fixo conforme regras de validação
                'usuario': self.user_id,  # Usa user_id (auth.uid) em vez do email
                'estado_pagamento': dados_viatura.get('estado_pagamento', 'pendente'),
                'latitude': dados_viatura.get('latitude'),
                'longitude': dados_viatura.get('longitude'),
                'timestamp': datetime.now().isoformat()
            }

            # Remove campos None para evitar problemas no Firebase
            viatura_data = {k: v for k, v in viatura_data.items() if v is not None}

            # Usar a matrícula como chave única
            url = f"{self.config['databaseURL']}/multas/{matricula}.json"
            params = {'auth': self.id_token}

            response = requests.put(url, params=params, json=viatura_data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Viatura {matricula} salva com sucesso no Firebase")
                # Remove do cache se estava pendente
                self.offline_cache.mark_registration_synced(matricula)
                return True, "Registro salvo com sucesso"
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                # Armazena no cache offline para tentar novamente depois
                self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
                return False, f"{error_msg}. Dados salvos offline para sincronização posterior."

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao salvar no Firebase: {str(e)}")
            # Armazena no cache offline
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, "Erro de conexão. Dados salvos offline para sincronização posterior."
        except Exception as e:
            self.logger.error(f"Erro inesperado ao salvar no Firebase: {str(e)}")
            # Armazena no cache offline
            self.offline_cache.cache_matricula_registration(matricula, dados_viatura)
            return False, f"Erro inesperado: {str(e)}. Dados salvos offline para sincronização posterior."

    def _add_viatura_with_retry(self, matricula: str, local: str, usuario: str, max_retries: int = 2) -> Tuple[bool, str]:
        """Tenta adicionar viatura com múltiplas tentativas."""
        for attempt in range(max_retries):
            try:
                success, message = self._add_viatura_online(matricula, local, usuario)
                if success:
                    return True, message
                
                # Se é erro de autenticação, não adianta retry
                if any(keyword in message.lower() for keyword in ['sessão', 'token', 'auth', '401', 'unauthorized']):
                    return False, message
                    
                # Wait before retry
                sleep(1 * (attempt + 1))
                
            except Exception as e:
                if attempt == max_retries - 1:  # Last attempt
                    return False, f"Erro após {max_retries} tentativas: {str(e)}"
                sleep(1 * (attempt + 1))
        
        return False, "Falha após múltiplas tentativas"

    def _add_viatura_offline(self, matricula: str, local: str, usuario: str) -> Tuple[bool, str]:
        """Adiciona viatura em modo offline."""
        existing = self.check_viatura(matricula)
        if existing:
            return False, "Matrícula já registrada (modo offline)"

        dados = {
            "matricula": matricula,
            "data_registro": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "local": local.strip(),
            "usuario": usuario.strip(),
            "status": "pendente"
        }

        self.mock_database[matricula] = dados
        self.logger.info(f"Matrícula {matricula} registrada com sucesso (modo offline)")
        return True, "Registro realizado com sucesso (modo offline)"

    def _add_viatura_online(self, matricula: str, local: str, usuario: str) -> Tuple[bool, str]:
        """Adiciona viatura em modo online."""
        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            return False, f"Erro de autenticação: {error}"

        # Verifica se a matrícula já existe
        existing = self.check_viatura(matricula)
        if existing:
            return False, "Matrícula já registrada"

        # Prepara os dados
        dados = {
            "matricula": matricula.upper(),
            "local": local.strip(),
            "usuario": usuario.strip(),
            "timestamp": datetime.now().isoformat(),
            "created_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        # Tenta adicionar usando requests diretamente (mais confiável)
        try:
            url = f"{self.config['databaseURL']}/multas.json"
            params = {'auth': self.id_token}
            
            response = requests.post(url, params=params, json=dados, timeout=10)
            
            if response.status_code == 200:
                self.logger.info(f"Matrícula {matricula} registrada com sucesso")
                return True, "Registro realizado com sucesso"
            elif response.status_code == 401:
                return False, "Sessão expirada. Faça login novamente."
            else:
                error_data = response.json().get('error', 'Erro desconhecido')
                return False, f"Erro ao registrar: {error_data}"
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao registrar viatura: {str(e)}")
            return False, "Erro de conexão. Verifique sua internet."
        except Exception as e:
            self.logger.error(f"Erro inesperado: {str(e)}")
            return False, f"Erro inesperado: {str(e)}"

    # ============ MÉTODOS AUXILIARES ============
    
    def _extract_error_message(self, error: HTTPError) -> str:
        """Extrai mensagem de erro da resposta HTTP."""
        try:
            if error.response is not None:
                return error.response.json().get('error', {}).get('message', str(error))
            else:
                # Fallback: tenta extrair do texto da exceção
                error_text = str(error)
                if '"message"' in error_text:
                    import json
                    try:
                        # Tenta parsear o JSON do texto da exceção
                        start = error_text.find('{')
                        end = error_text.rfind('}') + 1
                        if start != -1 and end > start:
                            json_part = error_text[start:end]
                            error_data = json.loads(json_part)
                            return error_data.get('error', {}).get('message', error_text)
                    except (json.JSONDecodeError, KeyError):
                        pass
                return error_text
        except (ValueError, AttributeError):
            return str(error)

    def check_user_exists(self, email: str) -> Tuple[bool, Optional[str]]:
        """Verifica se um usuário existe no Firebase."""
        try:
            # Método para buscar usuário por email (usando Admin SDK ou API)
            # Como alternativa, podemos tentar um reset de senha para verificar
            if self.offline_mode:
                return email in self.mock_users, None
                
            # Tenta enviar email de reset (não envia realmente se não autorizado)
            self.auth.send_password_reset_email(email)
            return True, None
            
        except HTTPError as e:
            error_msg = self._extract_error_message(e)
            if "EMAIL_NOT_FOUND" in error_msg:
                return False, "Email não cadastrado"
            return False, error_msg
        except Exception as e:
            return False, f"Erro ao verificar usuário: {str(e)}"
    

    def _translate_error(self, error_msg: str) -> str:
        """Traduz mensagens de erro do Firebase."""
        translations = {
            "INVALID_EMAIL": "Email inválido",
            "EMAIL_NOT_FOUND": "Email não cadastrado",
            "INVALID_PASSWORD": "Senha incorreta",
            "INVALID_LOGIN_CREDENTIALS": "Email ou senha incorretos",
            "USER_DISABLED": "Conta desativada",
            "TOKEN_EXPIRED": "Sessão expirada",
            "TOO_MANY_ATTEMPTS_TRY_LATER": "Muitas tentativas. Tente novamente mais tarde.",
            "OPERATION_NOT_ALLOWED": "Operação não permitida",
            "WEAK_PASSWORD": "Senha muito fraca",
            "EMAIL_EXISTS": "Email já cadastrado"
        }
        return translations.get(error_msg, f"Erro: {error_msg}")

    def send_password_reset_notification(self, email: str) -> Tuple[bool, str]:
        """Envia notificação de redefinição de senha para o admin."""
        if not email:
            return False, "Email é obrigatório"

        if self.offline_mode:
            return False, "Funcionalidade indisponível em modo offline"

        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            return False, f"Erro de autenticação: {error}"

        try:
            # Dados da notificação
            notification_data = {
                'email': email,
                'tipo': 'redefinicao_senha',
                'timestamp': datetime.now().isoformat(),
                'data_hora': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'pendente'
            }

            # Envia para /Notificacoes
            url = f"{self.config['databaseURL']}/Notificacoes.json"
            params = {'auth': self.id_token}

            response = requests.post(url, params=params, json=notification_data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Notificação de redefinição enviada para {email}")
                return True, "Solicitação enviada com sucesso. O administrador será notificado."
            else:
                error_msg = f"Erro ao enviar notificação ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                return False, error_msg

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao enviar notificação: {str(e)}")
            return False, "Erro de conexão. Verifique sua internet."
        except Exception as e:
            self.logger.error(f"Erro inesperado ao enviar notificação: {str(e)}")
            return False, f"Erro inesperado: {str(e)}"

    def _validate_plate(self, plate: str) -> bool:
        """Valida o formato da matrícula (Moçambique)."""
        if not plate or len(plate) < 6:
            return False

        # Remove espaços e converte para maiúsculo
        plate = plate.replace(' ', '').upper()

        patterns = [
            r'^[A-Z]{3}-\d{3}-[A-Z]{2}$',     # ABC-123-CD
            r'^[A-Z]{3}-\d{2}-\d{2}$',         # ABC-12-34
            r'^[A-Z]{2}-\d{2}-[A-Z]{2}$',     # AA-12-BB
            r'^[A-Z]{3}-\d{4}$',               # ABC-1234
            r'^[A-Z]{2}\d{3}[A-Z]{2}$',       # AA123BB
            r'^[A-Z]{3}\d{3}[A-Z]{2}$',       # ANE756MC
            r'^[A-Z]{3}-\d{4}-[A-Z]{2}$',     # ANE-1234-MC
            r'^TEST-\d{3}-[A-Z]{2}$',         # TEST-456-MC (placas de teste)
            r'^[A-Z]{3}-\d{3}[A-Z]{2}$',      # ANE123MC
            r'^[A-Z]{3}\d{4}[A-Z]{2}$',       # ANE1234MC
            r'^[A-Z]{3}\d{4}$',               # ANE1234
            r'^[A-Z]{2}\d{4}[A-Z]{2}$',       # AA1234BB
            r'^[A-Z]{4}-\d{3}-[A-Z]{2}$',     # ABCD-123-CD (placas especiais)
        ]

        return any(re.match(p, plate) for p in patterns)

    # ============ OPERAÇÕES COM ESTATÍSTICAS ============

    def save_estatisticas(self, user_id: str, stats: dict) -> Tuple[bool, str]:
        """Salva estatísticas do usuário no Firebase baseado no mês atual."""
        if self.offline_mode:
            self.offline_cache.cache_statistics_update(user_id, stats)
            return self._save_estatisticas_offline(user_id, stats)

        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            # Armazena no cache offline para sincronização posterior
            self.logger.warning(f"Token inválido, armazenando estatísticas offline: {error}")
            self.offline_cache.cache_statistics_update(user_id, stats)
            return False, f"Erro de autenticação. Estatísticas salvas offline para sincronização posterior."

        try:
            # Obtém o mês atual no formato YYYY-MM
            current_month = datetime.now().strftime('%Y-%m')

            # Estrutura dos dados das estatísticas
            estatisticas_data = {
                'user_id': user_id,
                'pesquisas': stats.get('pesquisas', 0),
                'registros': stats.get('registros', 0),
                'ultimas_viaturas': stats.get('ultimas_viaturas', []),
                'ultimas_verificacoes': stats.get('ultimas_verificacoes', []),
                'meta_diaria': stats.get('meta_diaria', 10),
                'data_atualizacao': datetime.now().isoformat(),
                'timestamp': datetime.now().timestamp()
            }

            # Salva no nó /estatisticas/{ano-mes}/{user_id}
            url = f"{self.config['databaseURL']}/estatisticas/{current_month}/{user_id}.json"
            params = {'auth': self.id_token}

            response = requests.put(url, params=params, json=estatisticas_data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Estatísticas salvas com sucesso para {user_id} no mês {current_month}")
                # Remove do cache se estava pendente
                self.offline_cache.mark_statistics_synced(user_id)
                return True, "Estatísticas salvas com sucesso"
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                # Armazena no cache offline para tentar novamente depois
                self.offline_cache.cache_statistics_update(user_id, stats)
                return False, f"{error_msg}. Estatísticas salvas offline para sincronização posterior."

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao salvar estatísticas: {str(e)}")
            # Armazena no cache offline
            self.offline_cache.cache_statistics_update(user_id, stats)
            return False, "Erro de conexão. Estatísticas salvas offline para sincronização posterior."
        except Exception as e:
            self.logger.error(f"Erro inesperado ao salvar estatísticas: {str(e)}")
            # Armazena no cache offline
            self.offline_cache.cache_statistics_update(user_id, stats)
            return False, f"Erro inesperado: {str(e)}. Estatísticas salvas offline para sincronização posterior."

    def _save_estatisticas_offline(self, user_id: str, stats: dict) -> Tuple[bool, str]:
        """Salva estatísticas em modo offline (simulado)."""
        try:
            current_month = datetime.now().strftime('%Y-%m')

            # Simula salvamento offline
            if not hasattr(self, 'offline_estatisticas'):
                self.offline_estatisticas = {}

            if current_month not in self.offline_estatisticas:
                self.offline_estatisticas[current_month] = {}

            self.offline_estatisticas[current_month][user_id] = {
                'user_id': user_id,
                'pesquisas': stats.get('pesquisas', 0),
                'registros': stats.get('registros', 0),
                'ultimas_viaturas': stats.get('ultimas_viaturas', []),
                'ultimas_verificacoes': stats.get('ultimas_verificacoes', []),
                'meta_diaria': stats.get('meta_diaria', 10),
                'data_atualizacao': datetime.now().isoformat(),
                'timestamp': datetime.now().timestamp()
            }

            self.logger.info(f"Estatísticas salvas offline para {user_id} no mês {current_month}")
            return True, "Estatísticas salvas offline com sucesso"

        except Exception as e:
            self.logger.error(f"Erro ao salvar estatísticas offline: {str(e)}")
            return False, f"Erro offline: {str(e)}"

    def get_estatisticas_mes(self, user_id: str, ano_mes: str = None) -> Optional[dict]:
        """Busca estatísticas do usuário para um mês específico."""
        if self.offline_mode:
            return self._get_estatisticas_mes_offline(user_id, ano_mes)

        # Garante token válido
        valid, error = self.ensure_valid_token()
        if not valid:
            self.logger.error(f"Token inválido para buscar estatísticas: {error}")
            return None

        try:
            # Se não especificado, usa o mês atual
            if not ano_mes:
                ano_mes = datetime.now().strftime('%Y-%m')

            # Busca no nó /estatisticas/{ano-mes}/{user_id}
            url = f"{self.config['databaseURL']}/estatisticas/{ano_mes}/{user_id}.json"
            params = {'auth': self.id_token}

            response = requests.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                if data:
                    self.logger.info(f"Estatísticas encontradas para {user_id} no mês {ano_mes}")
                    return data
                else:
                    self.logger.info(f"Nenhuma estatística encontrada para {user_id} no mês {ano_mes}")
                    return None
            else:
                self.logger.error(f"Erro HTTP ao buscar estatísticas: {response.status_code}")
                return None

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao buscar estatísticas: {str(e)}")
            return None
        except Exception as e:
            self.logger.error(f"Erro inesperado ao buscar estatísticas: {str(e)}")
            return None

    def _get_estatisticas_mes_offline(self, user_id: str, ano_mes: str = None) -> Optional[dict]:
        """Busca estatísticas offline."""
        try:
            if not ano_mes:
                ano_mes = datetime.now().strftime('%Y-%m')

            if hasattr(self, 'offline_estatisticas') and ano_mes in self.offline_estatisticas:
                stats = self.offline_estatisticas[ano_mes].get(user_id)
                if stats:
                    self.logger.info(f"Estatísticas offline encontradas para {user_id} no mês {ano_mes}")
                    return stats

            self.logger.info(f"Nenhuma estatística offline encontrada para {user_id} no mês {ano_mes}")
            return None

        except Exception as e:
            self.logger.error(f"Erro ao buscar estatísticas offline: {str(e)}")
            return None

    def get_db_data(self, path):
        """Busca dados do Firebase Realtime Database"""
        try:
            # Garante que temos um token válido
            valid, error = self.ensure_valid_token()
            if not valid:
                self.logger.error(f"Token inválido para buscar dados: {error}")
                return None
            
            # Remove barras extras no início do path
            if path.startswith('/'):
                path = path[1:]
                
            url = f"{self.config['databaseURL']}/{path}.json"
            params = {'auth': self.id_token}
            
            response = requests.get(url, params=params, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.logger.info(f"Dados encontrados no caminho: {path}")
                return data
            elif response.status_code == 404:
                self.logger.info(f"Caminho não encontrado: {path}")
                return None
            else:
                self.logger.error(f"Erro ao buscar dados ({response.status_code}): {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Exception ao buscar dados: {str(e)}")
            return None

    def save_funcionario_data(self, user_id: str, funcionario_data: dict) -> Tuple[bool, str]:
        """Salva dados do funcionário no Firebase."""
        try:
            # Garante token válido
            valid, error = self.ensure_valid_token()
            if not valid:
                return False, f"Erro de autenticação: {error}"

            # Salva no caminho /Funcionarios/{user_id}
            url = f"{self.config['databaseURL']}/Funcionarios/{user_id}.json"
            params = {'auth': self.id_token}

            response = requests.put(url, params=params, json=funcionario_data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Dados do funcionário salvos com sucesso para {user_id}")
                return True, "Dados salvos com sucesso"
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                return False, error_msg

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao salvar funcionário: {str(e)}")
            return False, "Erro de conexão"
        except Exception as e:
            self.logger.error(f"Erro inesperado ao salvar funcionário: {str(e)}")
            return False, f"Erro inesperado: {str(e)}"

    def set_db_data(self, path: str, data: dict) -> Tuple[bool, str]:
        """Define dados em um caminho específico do Firebase."""
        try:
            # Garante token válido
            valid, error = self.ensure_valid_token()
            if not valid:
                return False, f"Erro de autenticação: {error}"

            # Remove barras extras no início do path
            if path.startswith('/'):
                path = path[1:]

            url = f"{self.config['databaseURL']}/{path}.json"
            params = {'auth': self.id_token}

            response = requests.put(url, params=params, json=data, timeout=10)

            if response.status_code == 200:
                self.logger.info(f"Dados salvos com sucesso no caminho: {path}")
                return True, "Dados salvos com sucesso"
            else:
                error_msg = f"Erro Firebase ({response.status_code}): {response.text}"
                self.logger.error(error_msg)
                return False, error_msg

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro de conexão ao salvar dados: {str(e)}")
            return False, "Erro de conexão"
        except Exception as e:
            self.logger.error(f"Erro inesperado ao salvar dados: {str(e)}")
            return False, f"Erro inesperado: {str(e)}"
