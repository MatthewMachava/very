import logging
from kivy.utils import platform
from kivy.metrics import dp
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivy.uix.boxlayout import BoxLayout
from kivymd.uix.label import MDLabel

class PermissionsManager:
    """Gerenciador de permissões para Android"""

    def __init__(self):
        self.permissions_status = {
            'camera': False,
            'location': False,
            'storage': False
        }

    def check_all_permissions(self, callback=None):
        """Verifica todas as permissões necessárias"""
        if platform != 'android':
            # Em desenvolvimento (Linux/Windows), simular permissões concedidas
            self.permissions_status = {
                'camera': True,
                'location': True,
                'storage': True
            }
            if callback:
                callback(True)
            return

        # Para Android, verificar permissões reais
        self._check_android_permissions(callback)

    def _check_android_permissions(self, callback):
        """Verifica permissões no Android"""
        try:
            # Importações condicionais para Android
            if platform == 'android':
                from android.permissions import request_permissions, Permission
                from android import api_version

                permissions = [
                    Permission.CAMERA,
                    Permission.ACCESS_FINE_LOCATION,
                    Permission.ACCESS_COARSE_LOCATION,
                    Permission.WRITE_EXTERNAL_STORAGE,
                    Permission.READ_EXTERNAL_STORAGE
                ]

                def on_permissions_result(permissions_list, grant_results):
                    """Callback quando permissões são respondidas"""
                    all_granted = all(result for result in grant_results)

                    self.permissions_status['camera'] = grant_results[0]
                    self.permissions_status['location'] = grant_results[1] and grant_results[2]
                    self.permissions_status['storage'] = grant_results[3] and grant_results[4]

                    if callback:
                        callback(all_granted)

                    if not all_granted:
                        self._show_permissions_dialog()

                request_permissions(permissions, on_permissions_result)
            else:
                # Ambiente de desenvolvimento - simular permissões concedidas
                logging.info("Ambiente de desenvolvimento - simulando permissões concedidas")
                self.permissions_status = {
                    'camera': True,
                    'location': True,
                    'storage': True
                }
                if callback:
                    callback(True)

        except Exception as e:
            logging.warning(f"Erro ao verificar permissões Android: {e}")
            # Fallback para desenvolvimento
            self.permissions_status = {
                'camera': True,
                'location': True,
                'storage': True
            }
            if callback:
                callback(True)

    def _show_permissions_dialog(self):
        """Mostra diálogo explicando necessidade das permissões"""
        content = BoxLayout(
            orientation='vertical',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(120)
        )

        content.add_widget(MDLabel(
            text="Para funcionar corretamente, o aplicativo precisa das seguintes permissões:",
            theme_text_color="Secondary"
        ))

        permissions_text = []
        if not self.permissions_status['camera']:
            permissions_text.append("• Câmera: Para escanear matrículas")
        if not self.permissions_status['location']:
            permissions_text.append("• Localização: Para registrar localização das viaturas")
        if not self.permissions_status['storage']:
            permissions_text.append("• Armazenamento: Para salvar dados localmente")

        content.add_widget(MDLabel(
            text="\n".join(permissions_text),
            theme_text_color="Primary"
        ))

        dialog = MDDialog(
            title="Permissões Necessárias",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="CONFIGURAR",
                    on_release=lambda x: self._open_app_settings()
                ),
                MDRaisedButton(
                    text="TENTAR NOVAMENTE",
                    on_release=lambda x: self._retry_permissions()
                )
            ]
        )
        dialog.open()

    def _open_app_settings(self):
        """Abre configurações do aplicativo"""
        try:
            if platform == 'android':
                from android import api_version
                if api_version >= 23:
                    from android.intent import Intent
                    from android.content import Context

                    intent = Intent()
                    intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS")
                    intent.setData("package:" + Context.getPackageName())
                    Context.startActivity(intent)
            else:
                logging.info("Abrir configurações - apenas disponível em Android")
        except Exception as e:
            logging.error(f"Não foi possível abrir configurações: {e}")

    def _retry_permissions(self):
        """Tenta solicitar permissões novamente"""
        self.check_all_permissions()

    def has_camera_permission(self):
        """Verifica se tem permissão da câmera"""
        return self.permissions_status['camera']

    def has_location_permission(self):
        """Verifica se tem permissão de localização"""
        return self.permissions_status['location']

    def has_storage_permission(self):
        """Verifica se tem permissão de armazenamento"""
        return self.permissions_status['storage']

    def request_camera_permission(self, callback=None):
        """Solicita permissão da câmera especificamente"""
        if platform != 'android':
            if callback:
                callback(True)
            return

        try:
            from android.permissions import request_permissions, Permission

            def on_result(permissions_list, grant_results):
                granted = grant_results[0] if grant_results else False
                self.permissions_status['camera'] = granted
                if callback:
                    callback(granted)

            request_permissions([Permission.CAMERA], on_result)
        except:
            if callback:
                callback(True)  # Simular permissão concedida em desenvolvimento

    def request_location_permission(self, callback=None):
        """Solicita permissão de localização especificamente"""
        if platform != 'android':
            if callback:
                callback(True)
            return

        try:
            from android.permissions import request_permissions, Permission

            def on_result(permissions_list, grant_results):
                granted = all(result for result in grant_results)
                self.permissions_status['location'] = granted
                if callback:
                    callback(granted)

            request_permissions([
                Permission.ACCESS_FINE_LOCATION,
                Permission.ACCESS_COARSE_LOCATION
            ], on_result)
        except:
            if callback:
                callback(True)  # Simular permissão concedida em desenvolvimento

# Instância global
permissions_manager = PermissionsManager()
