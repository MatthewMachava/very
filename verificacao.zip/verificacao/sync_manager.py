import threading
import time
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

class SyncManager:
    def __init__(self, db_manager, firebase_manager, session_manager):
        self.db_manager = db_manager
        self.firebase = firebase_manager
        self.session_manager = session_manager
        self.logger = logging.getLogger(__name__)
        self.sync_interval = 300  # 5 minutos

        # INICIALIZAR TODOS OS ATRIBUTOS
        self.sync_thread = None
        self.stop_sync = False
        self.is_syncing = False
        self.last_sync = None
        self.offline_cache = firebase_manager.offline_cache

    def start_sync_service(self):
        """Inicia o serviço de sincronização em background - CORRIGIDO"""
        # Verifica se já existe uma thread ativa
        if self.sync_thread is not None and self.sync_thread.is_alive():
            self.logger.warning("Serviço de sincronização já está rodando")
            return

        self.stop_sync = False
        self.sync_thread = threading.Thread(target=self._sync_loop, daemon=True)
        self.sync_thread.start()
        self.logger.info("Serviço de sincronização iniciado")

    def stop_sync_service(self):
        """Para o serviço de sincronização - CORRIGIDO"""
        self.stop_sync = True
        if self.sync_thread and self.sync_thread.is_alive():
            self.sync_thread.join(timeout=5)
            self.logger.info("Thread de sincronização parada")
        self.sync_thread = None
        self.logger.info("Serviço de sincronização parado")

    def _sync_loop(self):
        """Loop principal de sincronização - CORRIGIDO"""
        self.logger.info("Loop de sincronização iniciado")
        
        while not self.stop_sync:
            try:
                if not self.is_syncing:
                    self.sync_all_data()
                
                # Aguarda o intervalo antes da próxima sincronização
                for i in range(self.sync_interval):
                    if self.stop_sync:
                        break
                    time.sleep(1)
                    
            except Exception as e:
                self.logger.error(f"Erro no loop de sincronização: {e}")
                time.sleep(60)  # Espera 1 minuto antes de tentar novamente em caso de erro

        self.logger.info("Loop de sincronização encerrado")

    def sync_all_data(self):
        """Sincroniza todos os dados pendentes - CORRIGIDO"""
        if self.is_syncing:
            self.logger.debug("Sincronização já em andamento, ignorando...")
            return

        self.is_syncing = True
        try:
            self.logger.info("Iniciando sincronização completa...")

            # Verificar se a sessão é válida antes de sincronizar
            if not self.session_manager.refresh_session_if_needed():
                self.logger.warning("Sessão inválida, pulando sincronização")
                return

            # 1. Sincronizar dados do cache offline
            cache_synced_count = self.sync_offline_cache()

            # 2. Upload de viaturas pendentes
            uploaded_count = self.upload_pending_viaturas()

            # 3. Download de dados do Firebase
            current_user_email = self.session_manager.get_current_user_email()
            if current_user_email:
                downloaded_count = self.download_firebase_data(current_user_email)
            else:
                downloaded_count = 0

            self.last_sync = datetime.now()
            self.logger.info(f"Sincronização concluída: {cache_synced_count} do cache, {uploaded_count} enviados, {downloaded_count} baixados")

        except Exception as e:
            self.logger.error(f"Erro durante sincronização: {e}")
        finally:
            self.is_syncing = False

    def upload_pending_viaturas(self) -> int:
        """Faz upload de viaturas pendentes para o Firebase - CORRIGIDO"""
        uploaded_count = 0
        try:
            # Usar o método correto do db_manager
            pending_viaturas = self.db_manager.get_unsynced_viaturas()
            self.logger.info(f"Encontradas {len(pending_viaturas)} viaturas pendentes")
            
            for viatura in pending_viaturas:
                # Verifica se deve parar
                if self.stop_sync:
                    break
                    
                # Verifica se a sessão ainda é válida
                if not self.session_manager.refresh_session_if_needed():
                    self.logger.error("Sessão expirada durante sincronização")
                    break
                
                success, message = self.firebase.add_viatura(
                    viatura['matricula'],
                    viatura['local'],
                    viatura['usuario_email']
                )
                
                if success:
                    # Marca como sincronizado no banco local
                    self.db_manager.update_sync_status(viatura['matricula'], True)
                    uploaded_count += 1
                    self.logger.info(f"Viatura {viatura['matricula']} sincronizada")
                else:
                    self.logger.warning(f"Falha ao sincronizar {viatura['matricula']}: {message}")
                    # Se for erro de autenticação, para a sincronização
                    if any(keyword in message.lower() for keyword in ['sessão', 'token', 'auth', '401', 'unauthorized']):
                        self.logger.error("Erro de autenticação, parando sincronização")
                        break
                        
        except Exception as e:
            self.logger.error(f"Erro no upload de viaturas: {e}")
        
        return uploaded_count

    def download_firebase_data(self, user_email: str) -> int:
        """Baixa dados do Firebase para sincronizar localmente - CORRIGIDO"""
        downloaded_count = 0
        try:
            self.logger.info(f"Baixando dados do Firebase para: {user_email}")
            
            # Verificar token primeiro
            valid, error = self.firebase.ensure_valid_token()
            if not valid:
                self.logger.warning(f"Token inválido para download: {error}")
                return 0

            # Busca viaturas do usuário no Firebase
            viaturas_firebase = self.firebase.get_user_viaturas(user_email)
            
            if not viaturas_firebase:
                self.logger.info("Nenhuma viatura encontrada no Firebase")
                return 0

            for viatura_data in viaturas_firebase:
                # Verifica se deve parar
                if self.stop_sync:
                    break
                    
                matricula = viatura_data.get('matricula')
                if not matricula:
                    continue

                # Verifica se já existe localmente
                local_viatura = self.db_manager.get_viatura(matricula)
                if not local_viatura:
                    # Adiciona localmente se não existir
                    success = self.db_manager.save_viatura(
                        matricula=matricula,
                        local=viatura_data.get('local', 'Sincronizado do Firebase'),
                        usuario_email=user_email,
                        latitude=viatura_data.get('latitude'),
                        longitude=viatura_data.get('longitude'),
                        firebase_synced=True
                    )
                    if success:
                        downloaded_count += 1
                        self.logger.info(f"Viatura baixada do Firebase: {matricula}")

            self.logger.info(f"Download concluído: {downloaded_count} viaturas baixadas")

        except Exception as e:
            self.logger.error(f"Erro ao baixar dados do Firebase: {e}")
        
        return downloaded_count

    def force_sync_now(self):
        """Força sincronização imediata - CORRIGIDO"""
        if not self.is_syncing:
            self.logger.info("Forçando sincronização imediata...")
            threading.Thread(target=self.sync_all_data, daemon=True).start()
        else:
            self.logger.warning("Sincronização já em andamento")

    def get_sync_status(self) -> Dict[str, Any]:
        """Obtém status da sincronização - CORRIGIDO"""
        try:
            # Obter estatísticas do banco de dados
            stats = self.db_manager.get_database_stats()
            cache_status = self.offline_cache.get_cache_status()

            return {
                'is_syncing': self.is_syncing,
                'last_sync': self.last_sync.isoformat() if self.last_sync else None,
                'unsynced_viaturas': stats.get('unsynced_viaturas', 0),
                'total_viaturas': stats.get('total_viaturas', 0),
                'sync_thread_alive': self.sync_thread.is_alive() if self.sync_thread else False,
                'stop_sync': self.stop_sync,
                'cache_valid': cache_status.get('cache_valid', False),
                'pending_offline_registrations': cache_status.get('pending_registrations', 0),
                'pending_offline_statistics': cache_status.get('pending_statistics', 0),
                'cache_expiry': cache_status.get('expiry_time')
            }
        except Exception as e:
            self.logger.error(f"Erro ao obter status de sincronização: {e}")
            return {
                'is_syncing': self.is_syncing,
                'error': str(e)
            }

    def sync_offline_cache(self) -> int:
        """Sincroniza dados pendentes do cache offline"""
        synced_count = 0

        try:
            # Limpa cache expirado primeiro
            self.offline_cache.cleanup_expired_cache()

            # Obtém dados pendentes do cache
            pending_data = self.offline_cache.force_sync_all_pending()

            # Sincroniza registros de matrículas pendentes
            for registration in pending_data.get('pending_registrations', []):
                try:
                    success, message = self.firebase.add_viatura(registration['dados'])
                    if success:
                        self.offline_cache.mark_registration_synced(registration['matricula'])
                        synced_count += 1
                        self.logger.info(f"Registro offline sincronizado: {registration['matricula']}")
                    else:
                        self.logger.warning(f"Falha ao sincronizar registro offline {registration['matricula']}: {message}")
                except Exception as e:
                    self.logger.error(f"Erro ao sincronizar registro offline {registration['matricula']}: {e}")

            # Sincroniza estatísticas pendentes
            for stats_data in pending_data.get('pending_statistics', []):
                try:
                    success, message = self.firebase.save_estatisticas(
                        stats_data['user_id'],
                        stats_data['stats']
                    )
                    if success:
                        self.offline_cache.mark_statistics_synced(stats_data['user_id'])
                        synced_count += 1
                        self.logger.info(f"Estatísticas offline sincronizadas para: {stats_data['user_id']}")
                    else:
                        self.logger.warning(f"Falha ao sincronizar estatísticas offline para {stats_data['user_id']}: {message}")
                except Exception as e:
                    self.logger.error(f"Erro ao sincronizar estatísticas offline para {stats_data['user_id']}: {e}")

            # Se todos os itens foram sincronizados com sucesso, remove o arquivo de cache
            if synced_count > 0:
                total_pending = len(pending_data.get('pending_registrations', [])) + len(pending_data.get('pending_statistics', []))
                if synced_count == total_pending:
                    self.offline_cache.delete_cache_file()
                    self.logger.info("Arquivo de cache offline removido após sincronização completa")

            self.logger.info(f"Sincronização do cache offline concluída: {synced_count} itens sincronizados")

        except Exception as e:
            self.logger.error(f"Erro na sincronização do cache offline: {e}")

        return synced_count

    def get_unsynced_count(self) -> int:
        """Retorna quantidade de registros não sincronizados"""
        try:
            stats = self.db_manager.get_database_stats()
            cache_status = self.offline_cache.get_cache_status()
            return stats.get('unsynced_viaturas', 0) + cache_status.get('pending_registrations', 0)
        except:
            return 0
