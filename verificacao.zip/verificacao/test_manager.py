import logging
from datetime import datetime

class TestManager:
    def __init__(self, app):
        self.app = app
        self.logger = logging.getLogger(__name__)
        self.test_results = []
    
    def run_all_tests(self, callback):
        """Executa todos os testes"""
        self.logger.info("Iniciando testes...")
        
        # Testes básicos
        tests = [
            self.test_database_connection,
            self.test_firebase_connection,
            self.test_ui_components,
        ]
        
        results = []
        for test in tests:
            try:
                result = test()
                results.append(result)
            except Exception as e:
                results.append({
                    'test_name': test.__name__,
                    'result': 'FALHOU',
                    'error': str(e)
                })
        
        self.test_results = results
        
        if callback:
            callback(results)
    
    def test_database_connection(self):
        """Testa conexão com banco de dados"""
        try:
            if self.app.db_manager.connect():
                return {
                    'test_name': 'Conexão com Banco de Dados',
                    'result': 'PASSOU',
                    'details': 'Conexão estabelecida com sucesso'
                }
            else:
                return {
                    'test_name': 'Conexão com Banco de Dados',
                    'result': 'FALHOU',
                    'error': 'Não foi possível conectar ao banco'
                }
        except Exception as e:
            return {
                'test_name': 'Conexão com Banco de Dados',
                'result': 'FALHOU',
                'error': str(e)
            }
    
    def test_firebase_connection(self):
        """Testa conexão com Firebase"""
        try:
            # Teste básico de configuração
            if hasattr(self.app.firebase, 'config'):
                return {
                    'test_name': 'Configuração do Firebase',
                    'result': 'PASSOU',
                    'details': 'Configuração carregada com sucesso'
                }
            else:
                return {
                    'test_name': 'Configuração do Firebase',
                    'result': 'FALHOU',
                    'error': 'Configuração não encontrada'
                }
        except Exception as e:
            return {
                'test_name': 'Configuração do Firebase',
                'result': 'FALHOU',
                'error': str(e)
            }
    
    def test_ui_components(self):
        """Testa componentes de UI básicos"""
        try:
            # Teste se o app foi construído
            if hasattr(self.app, 'root'):
                return {
                    'test_name': 'Interface do Usuário',
                    'result': 'PASSOU',
                    'details': 'UI carregada com sucesso'
                }
            else:
                return {
                    'test_name': 'Interface do Usuário',
                    'result': 'FALHOU',
                    'error': 'UI não carregada'
                }
        except Exception as e:
            return {
                'test_name': 'Interface do Usuário',
                'result': 'FALHOU',
                'error': str(e)
            }
    
    def get_test_summary(self):
        """Retorna resumo dos testes"""
        total = len(self.test_results)
        passed = sum(1 for r in self.test_results if r['result'] == 'PASSOU')
        failed = total - passed
        success_rate = (passed / total * 100) if total > 0 else 0
        
        return {
            'total_tests': total,
            'passed_tests': passed,
            'failed_tests': failed,
            'success_rate': success_rate,
            'results': self.test_results[-5:] if self.test_results else []
        }
