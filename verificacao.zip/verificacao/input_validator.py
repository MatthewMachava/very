import re

class input_validator:
    @staticmethod
    def validate_email(email):
        """Valida formato de email"""
        if not email:
            return False
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_plate(plate):
        """Valida formato de matrícula"""
        if not plate:
            return False
        
        plate_clean = re.sub(r'[-\s]', '', plate.upper())
        
        patterns = [
            r'^[A-Z]{2}\d{3}[A-Z]{2}$',
            r'^[A-Z]{3}\d{3}[A-Z]{2}$',
            r'^[A-Z]{3}\d{4}$',
            r'^[A-Z]{2}\d{4}[A-Z]{2}$',
        ]
        
        return any(re.match(p, plate_clean) for p in patterns)
    
    @staticmethod
    def validate_password(password):
        """Valida força da senha"""
        return len(password) >= 6 if password else False
