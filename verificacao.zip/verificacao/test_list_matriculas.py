#!/usr/bin/env python3
"""
Test script for listing matriculas from database
"""
import sys
import os
sys.path.append(os.path.dirname(__file__))

from database_manager import db_manager
from firebase_manager import FirebaseManager
import json

def test_list_local_matriculas():
    """Test listing matriculas from local database"""
    print("=== Testing Local Database Matriculas Listing ===")

    try:
        # Buscar TODAS as matrículas da base de dados
        matriculas = db_manager.get_all_viaturas(limit=100)
        print(f"Found {len(matriculas)} matriculas in total database:")

        for i, mat in enumerate(matriculas, 1):
            print(f"{i}. Matricula: {mat['matricula']}")
            print(f"   Local: {mat['local']}")
            print(f"   Usuario: {mat['usuario_email']}")
            print(f"   Sincronizado: {'Sim' if mat['firebase_synced'] else 'Não'}")
            print(f"   Data: {mat['created_at']}")
            print()

        return True

    except Exception as e:
        print(f"Error listing local matriculas: {e}")
        return False

def test_database_stats():
    """Test database statistics"""
    print("=== Testing Database Statistics ===")

    try:
        stats = db_manager.get_database_stats()
        print("Database Statistics:")
        print(f"Total Users: {stats['total_users']}")
        print(f"Total Viaturas: {stats['total_viaturas']}")
        print(f"Total Historico: {stats['total_historico']}")
        print(f"Unsynced Viaturas: {stats['unsynced_viaturas']}")
        print(f"Unsynced Historico: {stats['unsynced_historico']}")

        return True

    except Exception as e:
        print(f"Error getting database stats: {e}")
        return False

def test_firebase_list():
    """Test listing from Firebase"""
    print("\n=== Testing Firebase Matriculas Listing ===")

    try:
        firebase = FirebaseManager()

        # Try to get some data from Firebase
        # Since we don't have a specific matricula, we'll try a few test ones
        test_matriculas = ["ABC-123-MC", "ANE756MC", "AEF314MC"]

        firebase_data = []
        for matricula in test_matriculas:
            result = firebase.check_viatura(matricula)
            if result:
                firebase_data.append(result)
                print(f"Found in Firebase: {matricula}")
            else:
                print(f"Not found in Firebase: {matricula}")

        print(f"Total Firebase results: {len(firebase_data)}")
        return True

    except Exception as e:
        print(f"Error testing Firebase: {e}")
        return False

def main():
    """Main test function"""
    print("Starting Matriculas Listing Tests\n")

    # Test local database listing
    local_success = test_list_local_matriculas()

    # Test database stats
    stats_success = test_database_stats()

    # Test Firebase listing
    firebase_success = test_firebase_list()

    # Summary
    print("\n=== Test Summary ===")
    print(f"Local Database Listing: {'PASS' if local_success else 'FAIL'}")
    print(f"Database Stats: {'PASS' if stats_success else 'FAIL'}")
    print(f"Firebase Listing: {'PASS' if firebase_success else 'FAIL'}")

    overall_success = local_success and stats_success
    print(f"\nOverall Result: {'ALL TESTS PASSED' if overall_success else 'SOME TESTS FAILED'}")

    return overall_success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
