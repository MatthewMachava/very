import sqlite3
import logging
import os
import sys
import threading
import json
from datetime import datetime
from typing import List, Dict, Optional, Tuple

class DatabaseManager:
    def __init__(self):
        self.logger = self._setup_logging()
        self.db_path = self._get_db_path()
        self.conn = None
        self.db_lock = threading.RLock()
        self.create_tables()
        
    def _setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    def _get_db_path(self):
        if hasattr(sys, '_MEIPASS'):
            base_path = os.path.join(sys._MEIPASS, 'database')
        else:
            base_path = os.path.join(os.path.dirname(__file__), 'database')
        
        os.makedirs(base_path, exist_ok=True)
        return os.path.join(base_path, 'viaturas.db')
    
    def connect(self):
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self.conn.execute('PRAGMA foreign_keys = ON')
            self.conn.row_factory = sqlite3.Row
            self.logger.info(f"Conectado ao banco de dados: {self.db_path}")
            return True
        except sqlite3.Error as e:
            self.logger.error(f"Erro ao conectar com o banco: {str(e)}")
            return False
    
    def disconnect(self):
        if self.conn:
            self.conn.close()
            self.conn = None
            self.logger.info("Conexão com banco fechada")

    def create_tables(self):
        with self.db_lock:
            if not self.connect():
                self.logger.error("Não foi possível conectar ao banco para criar tabelas")
                return False
            
            try:
                cursor = self.conn.cursor()
                
                # Tabela viaturas com todas as colunas necessárias
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS viaturas (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        matricula TEXT UNIQUE NOT NULL,
                        local TEXT NOT NULL,
                        data_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
                        usuario_email TEXT NOT NULL,
                        latitude REAL NULL,
                        longitude REAL NULL,
                        sincronizada BOOLEAN DEFAULT 0,
                        data_sincronizacao DATETIME NULL,
                        status TEXT DEFAULT 'pendente',
                        firebase_synced BOOLEAN DEFAULT 0,
                        estado_pagamento TEXT DEFAULT 'pendente'
                    )
                ''')

                # Ensure all columns exist (for schema migration)
                try:
                    cursor.execute("ALTER TABLE viaturas ADD COLUMN firebase_synced BOOLEAN DEFAULT 0")
                except sqlite3.OperationalError:
                    pass
                try:
                    cursor.execute("ALTER TABLE viaturas ADD COLUMN estado_pagamento TEXT DEFAULT 'pendente'")
                except sqlite3.OperationalError:
                    pass
                # Rename usuario to usuario_email if exists (legacy migration)
                try:
                    cursor.execute("ALTER TABLE viaturas RENAME COLUMN usuario TO usuario_email")
                except sqlite3.OperationalError:
                    pass
                # Ensure usuario_email column exists
                try:
                    cursor.execute("ALTER TABLE viaturas ADD COLUMN usuario_email TEXT NOT NULL DEFAULT ''")
                except sqlite3.OperationalError:
                    pass

                # Tabela usuarios
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS usuarios (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        email TEXT UNIQUE NOT NULL,
                        password_hash TEXT NOT NULL,
                        data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
                        ultimo_login DATETIME NULL,
                        refresh_token TEXT NULL,
                        id_token TEXT NULL,
                        token_expiration DATETIME NULL,
                        firebase_uid TEXT NULL,
                        stats TEXT NULL
                    )
                ''')

                # Tabela historico
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS historico (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        email TEXT NOT NULL,
                        acao TEXT NOT NULL,
                        matricula TEXT NULL,
                        detalhes TEXT NULL,
                        data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')

                self.conn.commit()
                self.logger.info("Tabelas criadas/verificadas com sucesso")
                return True
                
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao criar tabelas: {str(e)}")
                return False
            finally:
                self.disconnect()
    
    def save_user(self, email: str, password_hash: str, refresh_token: str = None, 
                 id_token: str = None, token_expiration: datetime = None, 
                 firebase_uid: str = None, stats: dict = None) -> bool:
        with self.db_lock:
            if not self.connect():
                return False
            
            try:
                cursor = self.conn.cursor()
                
                cursor.execute('SELECT id FROM usuarios WHERE email = ?', (email,))
                existing_user = cursor.fetchone()
                
                # Converter stats para JSON string
                stats_json = json.dumps(stats) if stats else None
                
                if existing_user:
                    cursor.execute('''
                        UPDATE usuarios 
                        SET password_hash = ?, refresh_token = ?, id_token = ?, 
                            token_expiration = ?, firebase_uid = ?, stats = ?, ultimo_login = CURRENT_TIMESTAMP
                        WHERE email = ?
                    ''', (password_hash, refresh_token, id_token, 
                          token_expiration.isoformat() if token_expiration else None, 
                          firebase_uid, stats_json, email))
                else:
                    cursor.execute('''
                        INSERT INTO usuarios (email, password_hash, refresh_token, 
                                           id_token, token_expiration, firebase_uid, stats, ultimo_login)
                        VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ''', (email, password_hash, refresh_token, id_token, 
                          token_expiration.isoformat() if token_expiration else None, 
                          firebase_uid, stats_json))
                
                self.conn.commit()
                self.logger.info(f"Usuário {email} salvo/atualizado no banco local")
                return True
                
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao salvar usuário: {str(e)}")
                return False
            finally:
                self.disconnect()
    
    def get_user(self, email: str) -> Optional[Dict]:
        with self.db_lock:
            if not self.connect():
                return None
            
            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT email, password_hash, refresh_token, id_token, 
                           token_expiration, firebase_uid, stats
                    FROM usuarios WHERE email = ?
                ''', (email,))
                
                row = cursor.fetchone()
                if row:
                    # Converter JSON string de volta para dict
                    stats = json.loads(row[6]) if row[6] else {}
                    
                    return {
                        'email': row[0],
                        'password_hash': row[1],
                        'refresh_token': row[2],
                        'id_token': row[3],
                        'token_expiration': datetime.fromisoformat(row[4]) if row[4] else None,
                        'firebase_uid': row[5],
                        'stats': stats
                    }
                return None
                
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao buscar usuário: {str(e)}")
                return None
            finally:
                self.disconnect()

    def update_user_stats(self, email: str, stats: dict) -> bool:
        """Atualiza apenas as estatísticas do usuário"""
        with self.db_lock:
            if not self.connect():
                return False
            
            try:
                cursor = self.conn.cursor()
                
                # Converter stats para JSON string
                stats_json = json.dumps(stats) if stats else None
                
                cursor.execute('''
                    UPDATE usuarios 
                    SET stats = ?
                    WHERE email = ?
                ''', (stats_json, email))
                
                self.conn.commit()
                self.logger.info(f"Estatísticas do usuário {email} atualizadas")
                return cursor.rowcount > 0
                
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao atualizar estatísticas: {str(e)}")
                return False
            finally:
                self.disconnect()

    def add_historico(self, email: str, acao: str, matricula: str = None, detalhes: str = None) -> bool:
        with self.db_lock:
            if not self.connect():
                return False
            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    INSERT INTO historico (email, acao, matricula, detalhes)
                    VALUES (?, ?, ?, ?)
                ''', (email, acao, matricula, detalhes))
                self.conn.commit()
                self.logger.info(f"Histórico adicionado para usuário {email}")
                return True
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao adicionar histórico: {str(e)}")
                return False
            finally:
                self.disconnect()

    def get_today_viaturas(self):
        """Obtém todas as viaturas registradas hoje"""
        with self.db_lock:
            if not self.connect():
                return []

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT matricula, local, data_registro as created_at, estado_pagamento, usuario_email
                    FROM viaturas
                    WHERE date(data_registro) = date('now', 'localtime')
                    ORDER BY data_registro DESC
                ''')
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao buscar viaturas de hoje: {str(e)}")
                return []
            finally:
                self.disconnect()

    def get_viatura(self, matricula: str) -> Optional[Dict]:
        """Busca uma viatura específica"""
        with self.db_lock:
            if not self.connect():
                return None

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT matricula, local, data_registro, usuario_email,
                           latitude, longitude, sincronizada, status, estado_pagamento
                    FROM viaturas
                    WHERE matricula = ?
                    ORDER BY data_registro DESC
                    LIMIT 1
                ''', (matricula.upper(),))

                row = cursor.fetchone()
                if row:
                    return dict(row)
                return None

            except sqlite3.Error as e:
                self.logger.error(f"Erro ao buscar viatura: {str(e)}")
                return None
            finally:
                self.disconnect()

    def get_viaturas_by_matricula(self, matricula: str) -> List[Dict]:
        """Busca todas as ocorrências de uma matrícula específica"""
        with self.db_lock:
            if not self.connect():
                return []

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT matricula, local, data_registro as created_at, usuario_email,
                           latitude, longitude, sincronizada, status, estado_pagamento
                    FROM viaturas
                    WHERE matricula = ?
                    ORDER BY data_registro DESC
                ''', (matricula.upper(),))

                rows = cursor.fetchall()
                return [dict(row) for row in rows]

            except sqlite3.Error as e:
                self.logger.error(f"Erro ao buscar viaturas por matrícula: {str(e)}")
                return []
            finally:
                self.disconnect()

    def get_connection(self):
        """Retorna a conexão atual se estiver conectada"""
        if self.conn:
            return self.conn
        return None

    def save_viatura(self, matricula, local, usuario_email, data_registro,
                 hora_registro, status, estado_pagamento,
                 latitude=None, longitude=None, firebase_synced=False):
        with self.db_lock:
            if not self.connect():
                return False

            try:
                cursor = self.conn.cursor()

                # Combine data_registro and hora_registro into a single datetime if both are provided
                if data_registro and hora_registro:
                    try:
                        # Assuming data_registro is YYYY-MM-DD and hora_registro is HH:MM:SS
                        datetime_str = f"{data_registro} {hora_registro}"
                        data_registro = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
                    except ValueError:
                        # If parsing fails, use data_registro as is
                        pass

                cursor.execute('''
                    INSERT OR REPLACE INTO viaturas
                    (matricula, local, data_registro, usuario, usuario_email,
                    latitude, longitude, sincronizada, status, firebase_synced, estado_pagamento)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (matricula.upper(), local, data_registro, usuario_email, usuario_email,
                    latitude, longitude, firebase_synced, status, firebase_synced, estado_pagamento))

                self.conn.commit()
                self.logger.info(f"Viatura {matricula} salva com sucesso no banco local")
                return True

            except sqlite3.Error as e:
                self.logger.error(f"Erro ao salvar viatura: {str(e)}")
                return False
            finally:
                self.disconnect()

    def update_sync_status(self, matricula: str, synced: bool) -> bool:
        """Atualiza o status de sincronização de uma viatura"""
        with self.db_lock:
            if not self.connect():
                return False

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    UPDATE viaturas
                    SET sincronizada = ?, data_sincronizacao = CURRENT_TIMESTAMP
                    WHERE matricula = ?
                ''', (synced, matricula.upper()))

                self.conn.commit()
                success = cursor.rowcount > 0
                if success:
                    self.logger.info(f"Status de sincronização atualizado para viatura {matricula}")
                return success

            except sqlite3.Error as e:
                self.logger.error(f"Erro ao atualizar status de sincronização: {str(e)}")
                return False
            finally:
                self.disconnect()

    def update_payment_status(self, matricula: str, estado_pagamento: str) -> bool:
        """Atualiza o estado de pagamento de uma viatura"""
        with self.db_lock:
            if not self.connect():
                return False

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    UPDATE viaturas
                    SET estado_pagamento = ?
                    WHERE matricula = ?
                ''', (estado_pagamento, matricula.upper()))

                self.conn.commit()
                success = cursor.rowcount > 0
                if success:
                    self.logger.info(f"Estado de pagamento atualizado para viatura {matricula}: {estado_pagamento}")
                return success

            except sqlite3.Error as e:
                self.logger.error(f"Erro ao atualizar estado de pagamento: {str(e)}")
                return False
            finally:
                self.disconnect()

    def get_unsynced_viaturas(self) -> List[Dict]:
        """Obtém todas as viaturas não sincronizadas com o Firebase"""
        with self.db_lock:
            if not self.connect():
                return []

            try:
                cursor = self.conn.cursor()
                cursor.execute('''
                    SELECT matricula, local, data_registro, usuario, latitude, longitude
                    FROM viaturas
                    WHERE sincronizada = 0
                    ORDER BY data_registro ASC
                ''')
                rows = cursor.fetchall()
                return [dict(row) for row in rows]
            except sqlite3.Error as e:
                self.logger.error(f"Erro ao buscar viaturas não sincronizadas: {str(e)}")
                return []
            finally:
                self.disconnect()
