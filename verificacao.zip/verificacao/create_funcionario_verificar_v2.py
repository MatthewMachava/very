#!/usr/bin/env python3
"""
Script para criar um funcionário do tipo "verificar" no sistema Emme Verificação
"""

import sys
import os
import hashlib
import json
import requests
from datetime import datetime

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from firebase_manager import FirebaseManager
from database_manager import DatabaseManager

def criar_usuario_firebase_auth(email, senha, api_key):
    """Cria um usuário no Firebase Authentication"""
    try:
        # URL para criar usuário no Firebase Auth
        create_url = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={api_key}"

        payload = {
            "email": email,
            "password": senha,
            "returnSecureToken": True
        }

        response = requests.post(create_url, json=payload)
        result = response.json()

        if response.status_code == 200:
            print(f"✅ Usuário {email} criado no Firebase Auth")
            return {
                'idToken': result['idToken'],
                'refreshToken': result['refreshToken'],
                'localId': result['localId'],
                'email': result['email']
            }, None
        else:
            error_msg = result.get('error', {}).get('message', 'Erro desconhecido')
            if 'EMAIL_EXISTS' in error_msg:
                print("⚠️  Usuário já existe no Firebase Auth, tentando fazer login...")
                # Tentar fazer login se já existe
                login_url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={api_key}"
                response = requests.post(login_url, json=payload)
                if response.status_code == 200:
                    result = response.json()
                    print("✅ Login realizado com sucesso no usuário existente")
                    return {
                        'idToken': result['idToken'],
                        'refreshToken': result['refreshToken'],
                        'localId': result['localId'],
                        'email': result['email']
                    }, None
                else:
                    return None, f"Erro ao fazer login: {response.json()}"
            else:
                return None, error_msg

    except Exception as e:
        return None, f"Erro de conexão: {str(e)}"

def criar_funcionario_verificar():
    """Cria um funcionário do tipo verificar"""

    # Dados do funcionário
    funcionario_data = {
        'nome': 'João Verificador',
        'codigo': 'VER001',
        'email': 'verificar@emme.com',
        'tipo': 'verificar',
        'status': 'ativo',
        'meta_diaria': 250,
        'data_criacao': datetime.now().isoformat(),
        'permissoes': {
            'verificar_matriculas': True,
            'registrar_viaturas': True,
            'visualizar_relatorios': False,
            'gerir_usuarios': False,
            'gerir_senhas': False
        }
    }

    # Senha inicial
    senha = 'Verificar123!'
    password_hash = hashlib.sha256(senha.encode()).hexdigest()

    print("🔧 Iniciando criação do funcionário...")
    print(f"📧 Email: {funcionario_data['email']}")
    print(f"👤 Nome: {funcionario_data['nome']}")
    print(f"🏷️  Tipo: {funcionario_data['tipo']}")
    print(f"📊 Meta diária: {funcionario_data['meta_diaria']}")

    # Inicializar gerenciadores
    firebase = FirebaseManager()
    db_manager = DatabaseManager()

    try:
        # Primeiro, criar usuário no Firebase Auth
        print("\n🔐 Criando usuário no Firebase Auth...")
        user, error = criar_usuario_firebase_auth(
            funcionario_data['email'],
            senha,
            firebase.config['apiKey']
        )

        if error:
            print(f"❌ Erro ao criar/autenticar usuário no Firebase Auth: {error}")
            return False

        user_id = user['localId']
        print(f"✅ User ID obtido: {user_id}")

        # Atualizar tokens no firebase manager
        firebase.id_token = user['idToken']
        firebase.refresh_token = user['refreshToken']
        firebase.user_id = user_id
        firebase.token_expiration = datetime.now() + datetime.timedelta(seconds=3500)

        # Salvar dados do funcionário no Firebase (/Funcionarios/{user_id})
        print("\n💾 Salvando dados do funcionário no Firebase...")
        path = f"Funcionarios/{user_id}"

        # Verificar se já existe
        check_url = f"{firebase.config['databaseURL']}/{path}.json"
        params = {'auth': firebase.id_token}

        response = requests.get(check_url, params=params, timeout=10)
        exists = response.status_code == 200 and response.json() is not None

        if exists:
            print("⚠️  Funcionário já existe no Firebase, atualizando dados...")
            # Atualizar dados existentes
            response = requests.patch(check_url, params=params, json=funcionario_data, timeout=10)
        else:
            print("📝 Criando novo funcionário no Firebase...")
            # Criar novo
            response = requests.put(check_url, params=params, json=funcionario_data, timeout=10)

        if response.status_code == 200:
            print("✅ Dados do funcionário salvos no Firebase com sucesso")
        else:
            print(f"❌ Erro ao salvar no Firebase: {response.status_code} - {response.text}")
            return False

        # Salvar no banco local
        print("\n💽 Salvando no banco de dados local...")
        stats_iniciais = {
            'pesquisas': 0,
            'registros': 0,
            'ultimas_viaturas': [],
            'ultimas_verificacoes': [],
            'meta_diaria': funcionario_data['meta_diaria']
        }

        success = db_manager.save_user(
            email=funcionario_data['email'],
            password_hash=password_hash,
            firebase_uid=user_id,
            stats=stats_iniciais
        )

        if success:
            print("✅ Funcionário salvo no banco local com sucesso")

            # Adicionar ao histórico
            db_manager.add_historico(
                funcionario_data['email'],
                'criacao_funcionario',
                None,
                f'Funcionário {funcionario_data["tipo"]} criado: {funcionario_data["nome"]}'
            )
            print("✅ Histórico de criação adicionado")
        else:
            print("❌ Erro ao salvar no banco local")
            return False

        print("\n🎉 Funcionário criado com sucesso!")
        print("\n" + "="*50)
        print("DADOS DO FUNCIONÁRIO CRIADO:")
        print("="*50)
        print(f"Nome: {funcionario_data['nome']}")
        print(f"Email: {funcionario_data['email']}")
        print(f"Tipo: {funcionario_data['tipo']}")
        print(f"Código: {funcionario_data['codigo']}")
        print(f"Status: {funcionario_data['status']}")
        print(f"Meta diária: {funcionario_data['meta_diaria']}")
        print(f"Senha inicial: {senha}")
        print("="*50)
        print("\n⚠️  IMPORTANTE: Anote a senha inicial e forneça ao funcionário!")
        print("   O funcionário deve alterar a senha no primeiro login.")

        return True

    except Exception as e:
        print(f"❌ Erro inesperado: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🚀 Criando funcionário do tipo 'verificar'...")
    sucesso = criar_funcionario_verificar()

    if sucesso:
        print("\n✅ Processo concluído com sucesso!")
        sys.exit(0)
    else:
        print("\n❌ Falha na criação do funcionário!")
        sys.exit(1)
