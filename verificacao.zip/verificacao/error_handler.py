import logging
import traceback

class error_handler:
    @staticmethod
    def handle_error(error, context=""):
        """Manipula e registra erros"""
        error_msg = f"ERRO {context}: {str(error)}"
        logging.error(error_msg)
        logging.debug(traceback.format_exc())
        return error_msg
    
    @staticmethod
    def show_user_error(message):
        """Prepara mensagem de erro para usuário"""
        user_friendly_errors = {
            "INVALID_LOGIN_CREDENTIALS": "Email ou senha incorretos",
            "EMAIL_NOT_FOUND": "Email não cadastrado",
            "TOO_MANY_ATTEMPTS_TRY_LATER": "Muitas tentativas. Tente novamente mais tarde.",
            "NETWORK_ERROR": "Erro de conexão. Verifique sua internet.",
        }
        
        return user_friendly_errors.get(message, f"Erro: {message}")
