#!/usr/bin/env python3
"""
Test script for matricula search and save functionality
"""
import sys
import os
sys.path.append(os.path.dirname(__file__))

from database_manager import DatabaseManager

db_manager = DatabaseManager()
from firebase_manager import FirebaseManager
import json

def test_local_database_operations():
    """Test local database operations"""
    print("=== Testing Local Database Operations ===")

    # Test saving a new matricula
    test_matricula = "ABC-123-MC"
    print(f"1. Testing save of matricula: {test_matricula}")

    try:
        db_manager.save_viatura(
            matricula=test_matricula,
            local="Test Location",
            usuario_email="test@example.com",
            data_registro="2024-01-15",
            hora_registro="10:30:00",
            status="Ativa",
            estado_pagamento="pendente",
            latitude=-25.9692,
            longitude=32.5732,
            firebase_synced=False
        )
        print("   ✓ Matricula saved successfully to local database")
    except Exception as e:
        print(f"   ✗ Error saving matricula: {e}")
        return False

    # Test retrieving the matricula
    print(f"2. Testing retrieval of matricula: {test_matricula}")
    try:
        viatura = db_manager.get_viatura(test_matricula)
        if viatura:
            print(f"   ✓ Matricula found: {viatura['matricula']} at {viatura['local']}")
        else:
            print("   ✗ Matricula not found")
            return False
    except Exception as e:
        print(f"   ✗ Error retrieving matricula: {e}")
        return False

    # Test searching for non-existent matricula
    test_matricula2 = "XYZ-999-MC"
    print(f"3. Testing search for non-existent matricula: {test_matricula2}")
    try:
        viatura = db_manager.get_viatura(test_matricula2)
        if viatura is None:
            print("   ✓ Non-existent matricula correctly returned None")
        else:
            print(f"   ✗ Unexpected result for non-existent matricula: {viatura}")
            return False
    except Exception as e:
        print(f"   ✗ Error searching for non-existent matricula: {e}")
        return False

    # Test update sync status
    print(f"4. Testing sync status update for matricula: {test_matricula}")
    try:
        db_manager.update_sync_status(test_matricula, True)
        viatura = db_manager.get_viatura(test_matricula)
        if viatura and viatura['sincronizada']:
            print("   ✓ Sync status updated successfully")
        else:
            print("   ✗ Sync status not updated correctly")
            return False
    except Exception as e:
        print(f"   ✗ Error updating sync status: {e}")
        return False

    return True

def test_firebase_operations():
    """Test Firebase operations"""
    print("\n=== Testing Firebase Operations ===")

    try:
        firebase = FirebaseManager()
        print("1. Firebase manager initialized")

        # Test checking a matricula (this will depend on Firebase data)
        test_matricula = "ABC-123-MC"
        print(f"2. Testing Firebase check for matricula: {test_matricula}")

        registro = firebase.check_viatura(test_matricula)
        if registro:
            print(f"   ✓ Matricula found in Firebase: {registro}")
        else:
            print("   ✓ Matricula not found in Firebase (expected for test data)")

        return True

    except Exception as e:
        print(f"   ✗ Error testing Firebase operations: {e}")
        return False

def test_integration_scenario():
    """Test the complete integration scenario"""
    print("\n=== Testing Integration Scenario ===")

    # Simulate the search and save process
    test_matricula = "TEST-456-MC"
    user_email = "test@example.com"

    print(f"1. Simulating search for matricula: {test_matricula}")

    # Check local database first
    viatura = db_manager.get_viatura(test_matricula)
    if viatura:
        print(f"   ✓ Matricula found locally: {viatura['matricula']}")
        return True
    else:
        print("   ✓ Matricula not found locally, proceeding with save...")

    # Save to local database
    try:
        db_manager.save_viatura(
            matricula=test_matricula,
            local="Integration Test Location",
            usuario_email=user_email,
            data_registro="2024-01-15",
            hora_registro="10:30:00",
            status="Ativa",
            estado_pagamento="pendente",
            latitude=-25.9692,
            longitude=32.5732,
            firebase_synced=False
        )
        print("   ✓ Matricula saved to local database")
    except Exception as e:
        print(f"   ✗ Error saving to local database: {e}")
        return False

    # Verify save
    viatura = db_manager.get_viatura(test_matricula)
    if viatura:
        print(f"   ✓ Save verified: {viatura['matricula']} saved successfully")
    else:
        print("   ✗ Save verification failed")
        return False

    return True

def main():
    """Main test function"""
    print("Starting Matricula Search and Save Tests\n")

    # Test local database operations
    local_success = test_local_database_operations()

    # Test Firebase operations
    firebase_success = test_firebase_operations()

    # Test integration scenario
    integration_success = test_integration_scenario()

    # Summary
    print("\n=== Test Summary ===")
    print(f"Local Database Tests: {'PASS' if local_success else 'FAIL'}")
    print(f"Firebase Tests: {'PASS' if firebase_success else 'FAIL'}")
    print(f"Integration Tests: {'PASS' if integration_success else 'FAIL'}")

    overall_success = local_success and firebase_success and integration_success
    print(f"\nOverall Result: {'ALL TESTS PASSED' if overall_success else 'SOME TESTS FAILED'}")

    return overall_success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
