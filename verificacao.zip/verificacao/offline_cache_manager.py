import json
import os
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class OfflineCacheManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.cache_file = 'offline_cache.json'
        self.cache_expiry_hours = 24  # Cache expira em 24 horas
    
    def get_cache_status(self):
        """Retorna status do cache"""
        try:
            if not os.path.exists(self.cache_file):
                return {
                    'cache_valid': False,
                    'pending_registrations': 0,
                    'pending_statistics': 0,
                    'expiry_time': None
                }
            
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # Verificar se o cache expirou
            cache_time_str = cache_data.get('cache_timestamp')
            if cache_time_str:
                cache_time = datetime.fromisoformat(cache_time_str)
                if datetime.now() - cache_time > timedelta(hours=self.cache_expiry_hours):
                    self.cleanup_expired_cache()
                    return {
                        'cache_valid': False,
                        'pending_registrations': 0,
                        'pending_statistics': 0,
                        'expiry_time': None
                    }
            
            pending_registrations = len(cache_data.get('pending_registrations', []))
            pending_statistics = len(cache_data.get('pending_statistics', []))
            
            return {
                'cache_valid': True,
                'pending_registrations': pending_registrations,
                'pending_statistics': pending_statistics,
                'expiry_time': cache_time_str
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao verificar status do cache: {e}")
            return {
                'cache_valid': False,
                'pending_registrations': 0,
                'pending_statistics': 0,
                'expiry_time': None
            }
    
    def cache_matricula_registration(self, matricula: str, data: dict):
        """Armazena registro de matrícula no cache"""
        try:
            cache_data = self._load_cache()
            
            # Adicionar timestamp
            data['cache_timestamp'] = datetime.now().isoformat()
            
            # Verificar se já existe e atualizar
            existing_index = None
            for i, reg in enumerate(cache_data.get('pending_registrations', [])):
                if reg.get('matricula') == matricula:
                    existing_index = i
                    break
            
            if existing_index is not None:
                cache_data['pending_registrations'][existing_index] = {
                    'matricula': matricula,
                    'dados': data,
                    'timestamp': datetime.now().isoformat()
                }
            else:
                cache_data.setdefault('pending_registrations', []).append({
                    'matricula': matricula,
                    'dados': data,
                    'timestamp': datetime.now().isoformat()
                })
            
            self._save_cache(cache_data)
            self.logger.info(f"Registro {matricula} armazenado no cache offline")
            
        except Exception as e:
            self.logger.error(f"Erro ao armazenar no cache: {e}")
    
    def cache_matricula_verification(self, matricula: str, result: dict):
        """Armazena verificação de matrícula no cache"""
        try:
            cache_data = self._load_cache()
            
            cache_data.setdefault('verification_cache', {})[matricula] = {
                'result': result,
                'timestamp': datetime.now().isoformat()
            }
            
            self._save_cache(cache_data)
            self.logger.info(f"Verificação {matricula} armazenada no cache")
            
        except Exception as e:
            self.logger.error(f"Erro ao armazenar verificação no cache: {e}")
    
    def get_cached_verification(self, matricula: str) -> Optional[dict]:
        """Obtém verificação em cache se ainda for válida"""
        try:
            cache_data = self._load_cache()
            verification_cache = cache_data.get('verification_cache', {})
            
            if matricula in verification_cache:
                cache_entry = verification_cache[matricula]
                cache_time = datetime.fromisoformat(cache_entry['timestamp'])
                
                # Verificar se o cache ainda é válido (1 hora)
                if datetime.now() - cache_time < timedelta(hours=1):
                    self.logger.info(f"Usando cache para verificação: {matricula}")
                    return cache_entry['result']
                else:
                    # Remover cache expirado
                    del verification_cache[matricula]
                    self._save_cache(cache_data)
            
            return None
            
        except Exception as e:
            self.logger.error(f"Erro ao obter verificação em cache: {e}")
            return None
    
    def cache_statistics_update(self, user_id: str, stats: dict):
        """Armazena atualização de estatísticas no cache"""
        try:
            cache_data = self._load_cache()
            
            # Verificar se já existe e atualizar
            existing_index = None
            for i, stat in enumerate(cache_data.get('pending_statistics', [])):
                if stat.get('user_id') == user_id:
                    existing_index = i
                    break
            
            if existing_index is not None:
                cache_data['pending_statistics'][existing_index] = {
                    'user_id': user_id,
                    'stats': stats,
                    'timestamp': datetime.now().isoformat()
                }
            else:
                cache_data.setdefault('pending_statistics', []).append({
                    'user_id': user_id,
                    'stats': stats,
                    'timestamp': datetime.now().isoformat()
                })
            
            self._save_cache(cache_data)
            self.logger.info(f"Estatísticas para {user_id} armazenadas no cache")
            
        except Exception as e:
            self.logger.error(f"Erro ao armazenar estatísticas no cache: {e}")
    
    def get_pending_registrations(self) -> List[dict]:
        """Obtém registros pendentes do cache"""
        try:
            cache_data = self._load_cache()
            return cache_data.get('pending_registrations', [])
        except Exception as e:
            self.logger.error(f"Erro ao obter registros pendentes: {e}")
            return []
    
    def mark_registration_synced(self, matricula: str):
        """Marca registro como sincronizado"""
        try:
            cache_data = self._load_cache()
            cache_data['pending_registrations'] = [
                reg for reg in cache_data.get('pending_registrations', [])
                if reg.get('matricula') != matricula
            ]
            self._save_cache(cache_data)
            self.logger.info(f"Registro {matricula} marcado como sincronizado")
        except Exception as e:
            self.logger.error(f"Erro ao marcar registro como sincronizado: {e}")
    
    def mark_statistics_synced(self, user_id: str):
        """Marca estatísticas como sincronizadas"""
        try:
            cache_data = self._load_cache()
            cache_data['pending_statistics'] = [
                stat for stat in cache_data.get('pending_statistics', [])
                if stat.get('user_id') != user_id
            ]
            self._save_cache(cache_data)
            self.logger.info(f"Estatísticas {user_id} marcadas como sincronizadas")
        except Exception as e:
            self.logger.error(f"Erro ao marcar estatísticas como sincronizadas: {e}")
    
    def cleanup_expired_cache(self):
        """Limpa cache expirado"""
        try:
            if os.path.exists(self.cache_file):
                os.remove(self.cache_file)
                self.logger.info("Cache expirado removido")
        except Exception as e:
            self.logger.error(f"Erro ao limpar cache expirado: {e}")
    
    def force_sync_all_pending(self) -> dict:
        """Força sincronização de todos os dados pendentes"""
        try:
            cache_data = self._load_cache()
            return {
                'pending_registrations': cache_data.get('pending_registrations', []),
                'pending_statistics': cache_data.get('pending_statistics', [])
            }
        except Exception as e:
            self.logger.error(f"Erro ao forçar sincronização: {e}")
            return {'pending_registrations': [], 'pending_statistics': []}
    
    def delete_cache_file(self):
        """Remove arquivo de cache"""
        try:
            if os.path.exists(self.cache_file):
                os.remove(self.cache_file)
                self.logger.info("Arquivo de cache removido")
        except Exception as e:
            self.logger.error(f"Erro ao remover arquivo de cache: {e}")
    
    def _load_cache(self) -> dict:
        """Carrega dados do cache"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            return {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar cache: {e}")
            return {}
    
    def _save_cache(self, cache_data: dict):
        """Salva dados no cache"""
        try:
            cache_data['cache_timestamp'] = datetime.now().isoformat()
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error(f"Erro ao salvar cache: {e}")
