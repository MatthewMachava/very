from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.textfield import MDTextField
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.label import MDLabel  
from kivymd.uix.spinner import MDSpinner
from kivymd.uix.card import MDCard
from kivymd.uix.list import MDList, OneLineListItem, TwoLineListItem, ThreeLineListItem
from kivymd.uix.segmentedcontrol import MDSegmentedControl, MDSegmentedControlItem
from kivymd.uix.chip import MDChip
from kivymd.uix.taptargetview import MDTapTargetView
from kivymd.uix.snackbar import MDSnackbar
from kivymd.uix.tab import MDTabsBase
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.behaviors import RoundedRectangularElevationBehavior
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.pickers import MDDatePicker, MDTimePicker
from kivymd.uix.filemanager import MDFileManager

from kivymd.uix.relativelayout import MDRelativeLayout
from kivymd.uix.anchorlayout import MDAnchorLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.stacklayout import MDStackLayout

from kivymd.uix.hero import MDHeroFrom, MDHeroTo
from kivymd.uix.transition import MDSwapTransition, MDSlideTransition, MDFadeSlideTransition
from kivymd.uix.banner import MDBanner
from kivymd.uix.tooltip import MDTooltip

from kivymd.uix.controllers import WindowController
from kivymd.uix.behaviors import HoverBehavior
from kivy.uix.behaviors import FocusBehavior
from kivymd.uix.expansionpanel import MDExpansionPanel, MDExpansionPanelOneLine, MDExpansionPanelTwoLine, MDExpansionPanelThreeLine
from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationLayout
from kivymd.uix.navigationrail import MDNavigationRail, MDNavigationRailItem
from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem
from kivymd.uix.backdrop import MDBackdrop
from kivymd.uix.slider import MDSlider

from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, Rotate
from kivy.animation import Animation
from kivy.properties import NumericProperty, StringProperty
from kivy.lang import Builder
from kivy.clock import Clock
from datetime import datetime, timedelta
from kivy.graphics import PushMatrix, PopMatrix, Scale
from kivy.uix.camera import Camera
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.metrics import dp
from kivy.utils import platform as kivy_platform

from typing import Optional, List, Dict
from kivy.uix.image import Image
import cv2
import numpy as np
from firebase_manager import *
from database_manager import DatabaseManager
from sync_manager import SyncManager
from permissions_manager import permissions_manager
from session_manager import SessionManager
from input_validator import input_validator
from error_handler import error_handler
from test_manager import TestManager
from offline_cache_manager import OfflineCacheManager
import logging
import re
import hashlib
import json
import time

# Determina o diretório de escrita (gravável)
if kivy_platform == 'android':
    from android.storage import app_storage_path
    log_dir = app_storage_path()
else:
    log_dir = os.path.dirname(os.path.abspath(__file__))

log_path = os.path.join(log_dir, 'app.log')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_path, encoding='utf-8'),  # ✅ Agora é gravável
        logging.StreamHandler()
    ]
)

logging.getLogger('kivy').setLevel(logging.WARNING)
logging.getLogger('PIL').setLevel(logging.WARNING)

class PlateValidator:
    """Validador de matrículas para países da África Austral"""
    
    # Padrões de matrículas por país
    PATTERNS = {
        # MOÇAMBIQUE - Formatos oficiais
        'MZ': [
            r'^[A-Z]{3}\d{4}$',                    # ABC1234
            r'^[A-Z]{3}\d{3}[A-Z]{2}$',           # ABC123MC
            r'^[A-Z]{3}\d{3}MC$',                 # ABC123MC
            r'^[A-Z]{3}-\d{4}$',                  # ABC-1234
            r'^[A-Z]{3}-\d{3}-[A-Z]{2}$',         # ABC-123-MC
            r'^[A-Z]{3}-\d{3}-MC$',               # ABC-123-MC
        ],
        
        # ÁFRICA DO SUL - Formatos oficiais
        'ZA': [
            r'^[A-Z]{2}\d{2}[A-Z]{2}\d{2}$',      # CA123BC12 (formato atual)
            r'^[A-Z]{2}\d{2}-[A-Z]{2}\d{2}$',     # CA-123-BC-12
            r'^[A-Z]{3}\d{3}GP$',                 # ABC123GP (Gauteng)
            r'^[A-Z]{3}\d{3}EC$',                 # ABC123EC (Eastern Cape)
            r'^[A-Z]{3}\d{3}FS$',                 # ABC123FS (Free State)
            r'^[A-Z]{3}\d{3}KZN$',                # ABC123KZN (KwaZulu-Natal)
            r'^[A-Z]{3}\d{3}L$',                  # ABC123L (Limpopo)
            r'^[A-Z]{3}\d{3}MP$',                 # ABC123MP (Mpumalanga)
            r'^[A-Z]{3}\d{3}NC$',                 # ABC123NC (Northern Cape)
            r'^[A-Z]{3}\d{3}NW$',                 # ABC123NW (North West)
            r'^[A-Z]{3}\d{3}WC$',                 # ABC123WC (Western Cape)
        ],
        
        # TANZÂNIA - Formatos oficiais
        'TZ': [
            r'^T\d{3}[A-Z]{3}$',                  # T123ABC
            r'^T\d{3}-[A-Z]{3}$',                 # T-123-ABC
            r'^[A-Z]{1,2}\d{4}[A-Z]{1,3}$',       # AB12345CD
            r'^[A-Z]{2}\d{5}$',                   # AB12345
            r'^[A-Z]{3}\d{3}$',                   # ABC123
        ],
        
        # SUAZILÂNDIA (ESWATINI) - Formatos oficiais
        'SZ': [
            r'^[A-Z]{2}\d{5}$',                   # SD12345
            r'^[A-Z]{2}\d{4}[A-Z]{1}$',           # SD1234A
            r'^[A-Z]{3}\d{4}$',                   # ABC1234
            r'^[A-Z]{2}\d{3}[A-Z]{2}$',           # SD123AB
        ],
        
        # ZÂMBIA - Formatos oficiais
        'ZM': [
            r'^[A-Z]{2}\d{5}$',                   # BA12345
            r'^[A-Z]{2}\d{4}[A-Z]{1}$',           # BA1234A
            r'^[A-Z]{3}\d{3}$',                   # ABC123
        ],
        
        # ZIMBÁBUE - Formatos oficiais
        'ZW': [
            r'^[A-Z]{3}\d{4}$',                   # ABC1234
            r'^[A-Z]{2}\d{5}$',                   # AB12345
            r'^[A-Z]{3}\d{3}[A-Z]{1}$',           # ABC123D
        ],
        
        # Formatos antigos (para compatibilidade)
        'MZ_OLD': [
            r'^[A-Z]{2}-\d{2}-[A-Z]{2}$',         # AA-00-AA
            r'^[A-Z]{3}-\d{3}$',                  # AAA-000
            r'^\d{3}-[A-Z]{3}$',                  # 000-AAA
        ]
    }
    
    # Países suportados
    ALLOWED_COUNTRIES = ['MZ', 'ZA', 'TZ', 'SZ', 'ZM', 'ZW']
    
    # Nomes dos países
    COUNTRY_NAMES = {
        'MZ': 'Moçambique',
        'ZA': 'África do Sul', 
        'TZ': 'Tanzânia',
        'SZ': 'Suazilândia',
        'ZM': 'Zâmbia',
        'ZW': 'Zimbábue'
    }
    
    @classmethod
    def validate_plate(cls, plate):
        """
        Valida uma matrícula contra os padrões dos países
        Retorna (is_valid, country, normalized_plate, message)
        """
        if not plate or not isinstance(plate, str):
            return False, None, None, "Matrícula vazia ou inválida"
        
        # Limpar espaços e converter para maiúsculas
        clean_plate = plate.strip().upper()
        
        # Remover todos os espaços e hífens para validação básica
        clean_plate_no_separators = re.sub(r'[-\s]', '', clean_plate)
        
        # Verificar comprimento
        if len(clean_plate_no_separators) < 4:
            return False, None, None, "Matrícula muito curta"
        if len(clean_plate_no_separators) > 10:
            return False, None, None, "Matrícula muito longa"
        
        # Tentar identificar o formato e validar por país
        for country, patterns in cls.PATTERNS.items():
            country_code = country if country != 'MZ_OLD' else 'MZ'
            
            for pattern in patterns:
                if re.match(pattern, clean_plate):
                    # Formatar para padrão consistente (sem hífens)
                    formatted_plate = cls.format_plate(clean_plate)
                    country_name = cls.COUNTRY_NAMES.get(country_code, country_code)
                    return True, country_code, formatted_plate, f"Matrícula válida - {country_name}"
        
        # Se não encontrou com hífens, tentar sem hífens
        for country, patterns in cls.PATTERNS.items():
            country_code = country if country != 'MZ_OLD' else 'MZ'
            
            # Criar padrões sem hífens para comparação
            for pattern in patterns:
                pattern_no_hyphen = pattern.replace('-', '')
                if re.match(pattern_no_hyphen, clean_plate_no_separators):
                    formatted_plate = cls.format_plate(clean_plate_no_separators)
                    country_name = cls.COUNTRY_NAMES.get(country_code, country_code)
                    return True, country_code, formatted_plate, f"Matrícula válida - {country_name}"
        
        # Validação flexível para formatos comuns
        flexible_valid, flexible_plate, detected_country = cls.flexible_validation(clean_plate_no_separators)
        if flexible_valid:
            country_name = cls.COUNTRY_NAMES.get(detected_country, detected_country)
            return True, detected_country, flexible_plate, f"Matrícula válida (formato flexível) - {country_name}"
        
        return False, None, None, "Formato de matrícula não reconhecido"
    
    @classmethod
    def flexible_validation(cls, plate):
        """Validação flexível para formatos comuns"""
        # Remover todos os caracteres não alfanuméricos
        alphanumeric = re.sub(r'[^A-Z0-9]', '', plate)
        
        # Verificar comprimento
        if len(alphanumeric) < 4 or len(alphanumeric) > 10:
            return False, None, None
        
        # MOÇAMBIQUE: 3 letras + 3-4 números
        if re.match(r'^[A-Z]{3}\d{3,4}$', alphanumeric):
            return True, alphanumeric, 'MZ'
        
        # MOÇAMBIQUE: 3 letras + 3 números + 2 letras
        if re.match(r'^[A-Z]{3}\d{3}[A-Z]{2}$', alphanumeric):
            return True, alphanumeric, 'MZ'
        
        # MOÇAMBIQUE: 3 letras + 3 números + MC
        if re.match(r'^[A-Z]{3}\d{3}MC$', alphanumeric):
            return True, alphanumeric, 'MZ'
        
        # ÁFRICA DO SUL: 2 letras + 2 números + 2 letras + 2 números
        if re.match(r'^[A-Z]{2}\d{2}[A-Z]{2}\d{2}$', alphanumeric):
            return True, alphanumeric, 'ZA'
        
        # ÁFRICA DO SUL: 3 letras + 3 números + província
        if re.match(r'^[A-Z]{3}\d{3}(GP|EC|FS|KZN|L|MP|NC|NW|WC)$', alphanumeric):
            return True, alphanumeric, 'ZA'
        
        # TANZÂNIA: T + 3 números + 3 letras
        if re.match(r'^T\d{3}[A-Z]{3}$', alphanumeric):
            return True, alphanumeric, 'TZ'
        
        # TANZÂNIA: 1-2 letras + 4-5 números + 1-3 letras
        if re.match(r'^[A-Z]{1,2}\d{4,5}[A-Z]{1,3}$', alphanumeric):
            return True, alphanumeric, 'TZ'
        
        # SUAZILÂNDIA: 2 letras + 4-5 números
        if re.match(r'^[A-Z]{2}\d{4,5}$', alphanumeric):
            return True, alphanumeric, 'SZ'
        
        # SUAZILÂNDIA: 2 letras + 4 números + 1 letra
        if re.match(r'^[A-Z]{2}\d{4}[A-Z]{1}$', alphanumeric):
            return True, alphanumeric, 'SZ'
        
        # ZÂMBIA: 2 letras + 4-5 números
        if re.match(r'^[A-Z]{2}\d{4,5}$', alphanumeric):
            return True, alphanumeric, 'ZM'
        
        # ZIMBÁBUE: 3 letras + 4 números
        if re.match(r'^[A-Z]{3}\d{4}$', alphanumeric):
            return True, alphanumeric, 'ZW'
        
        # ZIMBÁBUE: 2 letras + 5 números
        if re.match(r'^[A-Z]{2}\d{5}$', alphanumeric):
            return True, alphanumeric, 'ZW'
        
        return False, None, None
    
    @classmethod
    def format_plate(cls, plate):
        """Formata a matrícula para um padrão consistente (sem hífens)"""
        # Remover todos os caracteres não alfanuméricos
        clean = re.sub(r'[^A-Z0-9]', '', plate)
        return clean.upper()
    
    @classmethod
    def get_country_name(cls, country_code):
        """Retorna o nome do país"""
        return cls.COUNTRY_NAMES.get(country_code, "País desconhecido")
    
    @classmethod
    def get_supported_formats_examples(cls):
        """Retorna exemplos de formatos suportados para mensagens de erro"""
        examples = [
            "MOÇAMBIQUE:",
            "  ABC1234, ABC123MC, ABC-123-MC",
            "ÁFRICA DO SUL:",
            "  CA123BC12, ABC123GP, CA-123-BC-12", 
            "TANZÂNIA:",
            "  T123ABC, AB12345CD, ABC123",
            "SUAZILÂNDIA:",
            "  SD12345, SD1234A, ABC1234",
            "ZÂMBIA:",
            "  BA12345, BA1234A, ABC123",
            "ZIMBÁBUE:",
            "  ABC1234, AB12345, ABC123D"
        ]
        return examples

    @classmethod
    def validate_plate_strict(cls, plate):
        """
        Validação estrita apenas para os formatos oficiais
        """
        clean_plate = plate.strip().upper()
        clean_plate_no_separators = re.sub(r'[-\s]', '', clean_plate)
        
        # Formatos oficiais exatos por país
        official_patterns = [
            # Moçambique
            r'^[A-Z]{3}\d{4}$',                    # ABC1234
            r'^[A-Z]{3}\d{3}[A-Z]{2}$',           # ABC123MC
            r'^[A-Z]{3}\d{3}MC$',                 # ABC123MC
            
            # África do Sul  
            r'^[A-Z]{2}\d{2}[A-Z]{2}\d{2}$',      # CA123BC12
            r'^[A-Z]{3}\d{3}(GP|EC|FS|KZN|L|MP|NC|NW|WC)$', # Com província
            
            # Tanzânia
            r'^T\d{3}[A-Z]{3}$',                  # T123ABC
            
            # Suazilândia
            r'^[A-Z]{2}\d{5}$',                   # SD12345
            
            # Zâmbia
            r'^[A-Z]{2}\d{5}$',                   # BA12345
            
            # Zimbábue
            r'^[A-Z]{3}\d{4}$',                   # ABC1234
        ]
        
        for pattern in official_patterns:
            if re.match(pattern, clean_plate_no_separators):
                return True, clean_plate_no_separators, "Formato oficial válido"
        
        return False, None, "Não é um formato oficial"

KV = '''
<SplashScreen>:
    MDFloatLayout:
        canvas.before:
            Color:
                rgba: (0.0, 0.36, 0.80, 1)
            Rectangle:
                size: self.size
                pos: self.pos

        AnimatedLogo:
            id: logo
            source: "logo.png"
            size_hint: None, None
            size: "80dp", "80dp"
            pos_hint: {"center_x": 0.5, "center_y": 0.58}
            opacity: 0
            on_kv_post: app.animate_logo(self)

            canvas.before:
                # Glow effect with multiple layers
                Color:
                    rgba: (1, 1, 1, self.opacity * 0.3 * (1 + 0.5 * (self.scale - 1)))
                Rectangle:
                    size: (self.width * 1.5, self.height * 1.5)
                    pos: (self.x - self.width * 0.25, self.y - self.height * 0.25)

                Color:
                    rgba: (0.0, 0.36, 0.80, self.opacity * 0.4 * (1 + 0.3 * (self.scale - 1)))
                Rectangle:
                    size: (self.width * 1.2, self.height * 1.2)
                    pos: (self.x - self.width * 0.1, self.y - self.height * 0.1)

        MDLabel:
            id: progress_label
            text: "...0%"
            halign: "center"
            font_style: "Body2"
            theme_text_color: "Custom"
            text_color: 1, 1, 1, 1
            pos_hint: {"center_x": 0.5, "center_y": 0.22}

        MDProgressBar:
            id: progress_bar
            type: "determinate"
            pos_hint: {"center_x": 0.5, "center_y": 0.28}
            size_hint_x: 0.75
            color: 0.9, 0.9, 0.9, 1

        MDLabel:
            id: loading_text
            text: "Carregando Sistema..."
            halign: "center"
            font_style: "H5"
            theme_text_color: "Custom"
            text_color: 1, 1, 1, 1
            opacity: 0
            pos_hint: {"center_x": 0.5, "center_y": 0.36}

<LoginScreen>:
    MDFloatLayout:
        md_bg_color: 0.96, 0.97, 0.98, 1

        MDCard:
            size_hint: None, None
            size: "320dp", "350dp"
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            elevation: 1
            padding: "25dp"
            spacing: "20dp"
            orientation: "vertical"
            radius: [14, 14, 14, 14]
            md_bg_color: 1, 1, 1, 1

            Image:
                source: "emme.png"
                size_hint: None, None
                size: "150dp", "150dp"
                pos_hint: {"center_x": 0.5}

            MDLabel:
                text: "Controle de Viaturas"
                halign: "center"
                font_style: "H5"
                theme_text_color: "Custom"
                text_color: 0.0, 0.36, 0.80, 1
                bold: True

            BoxLayout:
                orientation: "vertical"
                spacing: "15dp"
                size_hint_y: None
                height: "120dp"
                
                MDTextField:
                    id: email
                    hint_text: "Email"
                    icon_left: "email"
                    mode: "rectangle"
                    line_color_normal: 0.0, 0.36, 0.80, 1

                MDTextField:
                    id: password
                    hint_text: "Senha"
                    icon_left: "key"
                    password: True
                    mode: "rectangle"
                    line_color_normal: 0.0, 0.36, 0.80, 1

            BoxLayout:
                orientation: "vertical"
                spacing: "10dp"
                size_hint_y: None
                height: "90dp"

                MDRaisedButton:
                    text: "Entrar"
                    size_hint_x: 1
                    pos_hint: {"center_x": 0.5}
                    md_bg_color: 0.0, 0.36, 0.80, 1
                    text_color: 1, 1, 1, 1
                    on_release: root.try_login()
                    elevation: 2

                MDFlatButton:
                    text: "Esqueci minha senha"
                    size_hint_x: 1
                    pos_hint: {"center_x": 0.5}
                    theme_text_color: "Custom"
                    text_color: 0.0, 0.36, 0.80, 1
                    on_release: root.forgot_password()

                MDLabel:
                    text: "Digite suas credenciais para acessar"
                    halign: "center"
                    font_style: "Caption"
                    theme_text_color: "Custom"
                    text_color: 0.4, 0.4, 0.4, 1

<CameraScreen>:
    name: 'camera'
    
    BoxLayout:
        orientation: 'vertical'
        spacing: '10dp'
        padding: '10dp'

        # Preview da câmera com contorno
        MDCard:
            id: camera_preview_card
            size_hint: 1, 0.7
            elevation: 2
            padding: '2dp'
            radius: [12, 12, 12, 12]
            md_bg_color: 0.1, 0.1, 0.1, 1
            
            Image:
                id: camera_preview
                source: ''  # Será atualizado via texture
                allow_stretch: True
                keep_ratio: True
                size_hint: 1, 1
                opacity: 1

        # Container de status e informações
        BoxLayout:
            orientation: 'vertical'
            size_hint: 1, 0.15
            spacing: '5dp'
            padding: '5dp'

            # Label de status
            MDLabel:
                id: status_label
                text: "Inicializando câmera..."
                halign: 'center'
                valign: 'middle'
                theme_text_color: "Primary"
                font_style: "Body1"
                size_hint_y: 0.5

            # Container para placas detectadas
            ScrollView:
                size_hint_y: 0.5
                MDBoxLayout:
                    id: plates_container
                    orientation: 'horizontal'
                    adaptive_size: True
                    spacing: '5dp'
                    padding: '5dp'

        # Container de controles
        BoxLayout:
            orientation: 'vertical'
            size_hint: 1, 0.15
            spacing: '10dp'
            padding: '10dp'

            # Linha 1: Switch de detecção
            BoxLayout:
                orientation: 'horizontal'
                size_hint_y: 0.4
                spacing: '10dp'

                MDLabel:
                    text: "Detecção em tempo real:"
                    theme_text_color: "Primary"
                    font_style: "Body2"
                    halign: 'left'
                    size_hint_x: 0.7

                MDSwitch:
                    id: detection_switch
                    active: False
                    size_hint_x: 0.3
                    on_active: root.toggle_real_time_detection(self.active)

            # Linha 2: Botões de ação
            BoxLayout:
                orientation: 'horizontal'
                size_hint_y: 0.6
                spacing: '15dp'

                MDIconButton:
                    icon: "arrow-left"
                    theme_text_color: "Custom"
                    text_color: 0.0, 0.36, 0.80, 1
                    size_hint_x: 0.2
                    on_release: root.go_back()

                MDRaisedButton:
                    id: capture_btn
                    text: 'CAPTURAR IMAGEM'
                    size_hint_x: 0.6
                    md_bg_color: 0.0, 0.36, 0.80, 1
                    text_color: 1, 1, 1, 1
                    disabled: True
                    on_release: root.capture()

                MDIconButton:
                    icon: "information-outline"
                    theme_text_color: "Custom"
                    text_color: 0.6, 0.6, 0.6, 1
                    size_hint_x: 0.2
                    on_release: root.show_camera_info()

        # Overlay de loading
        MDBoxLayout:
            id: loading_overlay
            orientation: 'vertical'
            size_hint: 1, 1
            pos_hint: {'center_x': 0.5, 'center_y': 0.5}
            spacing: '20dp'
            padding: '20dp'
            opacity: 0
            md_bg_color: 0, 0, 0, 0.7

            MDSpinner:
                size_hint: None, None
                size: '50dp', '50dp'
                pos_hint: {'center_x': 0.5}
                active: False
                color: 1, 1, 1, 1

            MDLabel:
                text: "Processando..."
                theme_text_color: "Custom"
                text_color: 1, 1, 1, 1
                halign: 'center'
                font_style: 'H6'

<MainScreen>:
    MDFloatLayout:
        md_bg_color: 0.96, 0.97, 0.98, 1

        MDTopAppBar:
            id: toolbar
            title: "EmmE Verificação"
            md_bg_color: 0.0, 0.36, 0.80, 1
            specific_text_color: 1, 1, 1, 1
            elevation: 2
            left_action_items: [["logout", lambda x: root.logout()]]
            right_action_items: [["information-outline", lambda x: root.show_about()],["filter", lambda x: root.filter_paid_matriculas()],["chart-bar", lambda x: root.show_stats()],["camera", lambda x: root.start_scanner()]]
            pos_hint: {"top": 1}

        MDCard:
            size_hint: None, None
            size: "360dp", "460dp"
            pos_hint: {"center_x": 0.5, "center_y": 0.45}
            elevation: 2
            padding: "25dp"
            spacing: "20dp"
            orientation: "vertical"
            radius: [15, 15, 15, 15]
            md_bg_color: 1, 1, 1, 1

            BoxLayout:
                orientation: "vertical"
                spacing: "15dp"
                size_hint_y: None
                height: "80dp"
                
                MDTextField:
                    id: matricula_input
                    hint_text: "Matrícula da viatura"
                    icon_left: "car"
                    mode: "rectangle"
                    line_color_normal: 0.0, 0.36, 0.80, 1
                    helper_text: "Ex: ABC-123-CD, CA123BC12, T123ABC"
                    helper_text_mode: "on_focus"
                    on_text: root.validar_matricula_em_tempo_real(self.text)

            BoxLayout:
                orientation: "vertical"
                spacing: "12dp"
                size_hint_y: None
                height: "180dp"

                MDRaisedButton:
                    text: "PESQUISAR / REGISTRAR"
                    size_hint_x: 1
                    md_bg_color: 0.0, 0.36, 0.80, 1
                    text_color: 1, 1, 1, 1
                    on_release: root.registrar_ou_verificar()
                    elevation: 3

                MDFlatButton:
                    text: "ESCANEAR MATRÍCULA"
                    size_hint_x: 1
                    theme_text_color: "Custom"
                    text_color: 0.0, 0.36, 0.80, 1
                    line_color: 0.0, 0.36, 0.80, 1
                    on_release: root.start_scanner();root.show_pagamento_status()

                MDFlatButton:
                    text: "LISTAR MATRÍCULAS"
                    size_hint_x: 1
                    theme_text_color: "Custom"
                    text_color: 0.0, 0.78, 0.59, 1
                    line_color: 0.0, 0.78, 0.59, 1
                    on_release: root.listar_matriculas()

                
            MDCard:
                id: result_card
                orientation: "vertical"
                size_hint: 1, None
                height: "80dp"
                padding: "15dp"
                elevation: 1
                radius: [8, 8, 8, 8]
                md_bg_color: 0.98, 0.99, 1, 1
                
                MDLabel:
                    id: result_label
                    text: "Bem-vindo! Digite uma matrícula ou use o scanner."
                    halign: "center"
                    valign: "center"
                    theme_text_color: "Custom"
                    text_color: 0.25, 0.28, 0.35, 1
                    font_style: "Body1"

            BoxLayout:
                orientation: "horizontal"
                size_hint_y: None
                height: "40dp"
                spacing: "10dp"
                
                MDLabel:
                    id: user_label
                    text: ""
                    halign: "left"
                    font_style: "Caption"
                    theme_text_color: "Custom"
                    text_color: 0.45, 0.47, 0.5, 1
                    size_hint_x: 0.6

                MDLabel:
                    id: stats_label
                    text: ""
                    halign: "right"
                    font_style: "Caption"
                    theme_text_color: "Custom"
                    text_color: 0.45, 0.47, 0.5, 1
                    size_hint_x: 0.4

<AboutScreen>:
    MDFloatLayout:
        md_bg_color: 0.96, 0.97, 0.98, 1

        MDTopAppBar:
            title: "Sobre o EmmE Verificação"
            md_bg_color: 0.0, 0.36, 0.80, 1
            specific_text_color: 1, 1, 1, 1
            elevation: 2
            left_action_items: [["arrow-left", lambda x: root.go_back()]]

        MDCard:
            size_hint: None, None
            size: "360dp", "500dp"
            pos_hint: {"center_x": 0.5, "center_y": 0.45}
            elevation: 2
            padding: "25dp"
            spacing: "20dp"
            orientation: "vertical"
            radius: [15, 15, 15, 15]
            md_bg_color: 1, 1, 1, 1

            Image:
                source: "emme.png"
                size_hint: None, None
                size: "120dp", "120dp"
                pos_hint: {"center_x": 0.5}

            MDLabel:
                text: "EmmE Verificação"
                halign: "center"
                font_style: "H4"
                theme_text_color: "Custom"
                text_color: 0.0, 0.36, 0.80, 1
                bold: True

            MDLabel:
                text: "Sistema de Controle de Viaturas"
                halign: "center"
                font_style: "H6"
                theme_text_color: "Custom"
                text_color: 0.4, 0.4, 0.4, 1

            MDLabel:
                text: "Versão 1.0.0"
                halign: "center"
                font_style: "Body1"
                theme_text_color: "Custom"
                text_color: 0.6, 0.6, 0.6, 1

            BoxLayout:
                orientation: "vertical"
                spacing: "15dp"
                size_hint_y: None
                height: "200dp"

                MDLabel:
                    text: "Este aplicativo permite o controle e verificação de matrículas de viaturas, facilitando o gerenciamento de registros e pagamentos."
                    halign: "center"
                    font_style: "Body2"
                    theme_text_color: "Custom"
                    text_color: 0.25, 0.28, 0.35, 1

                MDLabel:
                    text: "Funcionalidades principais:"
                    halign: "center"
                    font_style: "Subtitle1"
                    theme_text_color: "Custom"
                    text_color: 0.0, 0.36, 0.80, 1
                    bold: True

                MDLabel:
                    text: "• Registro de matrículas\\n• Verificação de pagamentos\\n• Sincronização offline\\n• Relatórios e estatísticas\\n• Scanner de matrículas"
                    halign: "center"
                    font_style: "Body2"
                    theme_text_color: "Custom"
                    text_color: 0.25, 0.28, 0.35, 1

            MDLabel:
                text: "Desenvolvido com KivyMD"
                halign: "center"
                font_style: "Caption"
                theme_text_color: "Custom"
                text_color: 0.6, 0.6, 0.6, 1

'''

class AnimatedLogo(Image):
    scale = NumericProperty(1.0)
    angle = NumericProperty(0.0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            self._push = PushMatrix()
            self._scale = Scale(x=self.scale, y=self.scale, origin=self.center)
            self._rotate = Rotate(angle=self.angle, origin=self.center)
        with self.canvas.after:
            self._pop = PopMatrix()
        self.bind(scale=self._update_scale, center=self._update_scale, angle=self._update_rotation)

    def _update_scale(self, *args):
        self._scale.origin = self.center
        self._scale.x = self.scale
        self._scale.y = self.scale

    def _update_rotation(self, *args):
        self._rotate.origin = self.center
        self._rotate.angle = self.angle

class SplashScreen(MDScreen):
    def on_enter(self):
        logging.info("SplashScreen iniciado")
        self.ids.progress_bar.value = 0
        self.start_time = datetime.now()
        self.animate_text()
        Clock.schedule_interval(self.update_progress, 0.05)

    def animate_text(self):
        Animation(opacity=1, duration=1.7, t='out_quad').start(self.ids.loading_text)

    def update_progress(self, dt):
        if self.ids.progress_bar.value < 100:
            self.ids.progress_bar.value += 2
            self.ids.progress_label.text = f"...{int(self.ids.progress_bar.value)}%"
        else:
            self.ids.progress_label.text = "...100%"
            elapsed = (datetime.now() - self.start_time).total_seconds()
            if elapsed >= 2.5:
                Clock.unschedule(self.update_progress)
                fade_out = Animation(opacity=0, duration=0.5)
                fade_out.bind(on_complete=lambda *a: MDApp.get_running_app().load_session())
                fade_out.start(self)

    def on_leave(self):
        logging.info("Saindo do SplashScreen")

class SecurityUtils:
    @staticmethod
    def validate_email(email):
        import re
        return re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email)
    
    @staticmethod
    def validate_password(password):
        return len(password) >= 8

class LoginScreen(MDScreen):
    def validate_email(self, email):
        """Valida o formato do email."""
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None

    def try_login(self):
        email = self.ids.email.text.strip()
        password = self.ids.password.text

        if not email or not password:
            self.show_error("Por favor, preencha todos os campos")
            return

        # Validação de email
        if not self.validate_email(email):
            self.show_error("Por favor, digite um email válido")
            self.ids.email.error = True
            return

        try:
            app = MDApp.get_running_app()
            
            self.ids.email.error = False
            self.ids.password.error = False
            
            # Mostra loading
            self.show_loading(True)
            
            # Processa login
            Clock.schedule_once(lambda dt: self._process_login(app, email, password), 0.1)
            
        except Exception as e:
            self.show_loading(False)
            self.show_error(f"Erro de conexão: {str(e)}")

    def _process_login(self, app, email, password):
        """Processa o login em background."""
        try:
            # DEBUG: Verificar métodos disponíveis
            print("Métodos disponíveis no FirebaseManager:")
            available_methods = [m for m in dir(app.firebase) if not m.startswith('_')]
            print(available_methods)
            
            # Tenta diferentes métodos de login - USANDO login_user PRIMEIRO
            user, error = None, None
            
            # Método 1: login_user (que já existe)
            if hasattr(app.firebase, 'login_user'):
                print("Usando login_user")
                user, error = app.firebase.login_user(email, password)
            # Método 2: sign_in_with_email_and_password (mas sem api_key)
            elif hasattr(app.firebase, 'sign_in_with_email_and_password'):
                print("Usando sign_in_with_email_and_password com fallback")
                user, error = self._safe_sign_in(app.firebase, email, password)
            else:
                # Fallback para método básico
                print("Usando fallback básico")
                user, error = self._basic_firebase_login(app.firebase, email, password)

            print(f"Resultado do login: user={user is not None}, error={error}")

            if user:
                print("Login bem-sucedido, processando usuário...")
                
                # Buscar dados adicionais do usuário
                user_id = user.get('localId') or user.get('userId') or user.get('uid')
                user_data = self.load_user_data_from_firebase(user_id)

                # Verificar se o usuário existe em /Funcionarios
                if user_data is None:
                    self.show_loading(False)
                    print("Usuário não encontrado em /Funcionarios")
                    self.show_error("Usuário não autorizado. Contate o administrador.")
                    return

                # Estrutura correta do current_user
                app.current_user = {
                    'email': email,
                    'idToken': user.get('idToken', ''),
                    'refreshToken': user.get('refreshToken', ''),
                    'localId': user_id,
                    'user_id': user_id,
                    'user_data': user_data,
                    'stats': {
                        'pesquisas': 0,
                        'registros': 0,
                        'ultimas_viaturas': [],
                        'ultimas_verificacoes': [],
                        'meta_diaria': 10
                    }
                }

                # Salvar hash da senha para verificação local
                password_hash = hashlib.sha256(password.encode()).hexdigest()

                # Criar sessão
                app.session_manager.create_session(app.current_user)

                # Salvar usuário no banco local
                try:
                    app.db_manager.save_user(
                        email=email,
                        password_hash=password_hash,
                        firebase_uid=user_id,
                        stats=app.current_user['stats'],
                        user_data=user_data
                    )

                    # Adicionar ao histórico
                    app.db_manager.add_historico(
                        email,
                        'login',
                        None,
                        'Login realizado com sucesso'
                    )
                except Exception as db_error:
                    print(f"Erro ao salvar no banco local: {db_error}")

                # Carregar estatísticas
                self.load_stats(app.current_user)
                
                # Fecha loading e vai para main
                self.show_loading(False)
                self.manager.current = 'main'
                
            else:
                self.show_loading(False)
                error_msg = error or "Credenciais inválidas"
                print(f"Erro de login: {error_msg}")
                self.show_error(error_msg)
                self.ids.password.error = True

        except Exception as e:
            self.show_loading(False)
            print(f"Exceção durante login: {str(e)}")
            import traceback
            traceback.print_exc()
            self.show_error(f"Erro durante login: {str(e)}")

    def _safe_sign_in(self, firebase_manager, email, password):
        """Versão segura do sign_in_with_email_and_password que evita api_key"""
        try:
            # Tenta usar o método diretamente
            return firebase_manager.sign_in_with_email_and_password(email, password)
        except AttributeError as e:
            if 'api_key' in str(e):
                # Se der erro de api_key, tenta usar login_user
                if hasattr(firebase_manager, 'login_user'):
                    return firebase_manager.login_user(email, password)
                else:
                    return None, "Método de login não disponível"
            else:
                return None, f"Erro: {str(e)}"

    def _basic_firebase_login(self, firebase_manager, email, password):
        """Implementação básica de login como fallback"""
        try:
            import requests
            
            # Tenta obter a API key de diferentes formas
            api_key = None
            
            # Método 1: do atributo config
            if hasattr(firebase_manager, 'config') and firebase_manager.config:
                api_key = firebase_manager.config.get('apiKey')
            
            # Método 2: do atributo firebase
            if not api_key and hasattr(firebase_manager, 'firebase'):
                if hasattr(firebase_manager.firebase, '_get_api_key'):
                    api_key = firebase_manager.firebase._get_api_key()
            
            # Método 3: tentar encontrar em qualquer atributo
            if not api_key:
                for attr_name in dir(firebase_manager):
                    if 'key' in attr_name.lower() or 'api' in attr_name.lower():
                        attr_value = getattr(firebase_manager, attr_name)
                        if isinstance(attr_value, str) and len(attr_value) > 20:
                            api_key = attr_value
                            break
            
            if not api_key:
                return None, "API key do Firebase não encontrada"
            
            print(f"Usando API key: {api_key[:10]}...")
            
            # URL da API do Firebase Auth
            url = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={api_key}"
            
            payload = {
                "email": email,
                "password": password,
                "returnSecureToken": True
            }
            
            print(f"Fazendo requisição para: {url}")
            response = requests.post(url, json=payload)
            result = response.json()
            
            print(f"Resposta do Firebase: {result}")
            
            if response.status_code == 200:
                return {
                    'idToken': result['idToken'],
                    'refreshToken': result.get('refreshToken', ''),
                    'localId': result['localId'],
                    'email': result['email']
                }, None
            else:
                error_msg = result.get('error', {}).get('message', 'Erro desconhecido')
                return None, error_msg
                
        except Exception as e:
            error_msg = f"Erro de conexão: {str(e)}"
            print(error_msg)
            return None, error_msg

    def load_user_data_from_firebase(self, user_id):
        """Carrega dados do usuário especificamente do caminho /Funcionarios"""
        try:
            app = MDApp.get_running_app()

            if not user_id:
                print("User ID é None ou vazio")
                return None

            print(f"Buscando dados do usuário em /Funcionarios: {user_id}")

            # Buscar especificamente no caminho /Funcionarios/{user_id}
            path = f"Funcionarios/{user_id}"
            try:
                print(f"Buscando em: {path}")
                data = app.firebase.get_db_data(path)
                print(f"Resposta da busca: {data}")
                if data and data is not None:
                    print(f"Dados encontrados: {data}")
                    nome = data.get('nome') or data.get('name') or data.get('displayName') or data.get('email', 'Usuário')
                    return {
                        'nome': nome,
                        'user_id': user_id,
                        'db_path': path,
                        'dados_completos': data
                    }
                else:
                    print(f"Nenhum dado encontrado em {path} - usuário não autorizado")
                    return None
            except Exception as e:
                print(f"Erro ao buscar em {path}: {e}")
                return None

        except Exception as e:
            print(f"Erro na busca de dados do usuário: {str(e)}")
            return None

    def _get_default_user_data(self, user_id):
        """Retorna dados padrão do usuário"""
        return {
            'nome': 'Usuário',
            'user_id': user_id or 'unknown',
            'db_path': 'Não encontrado',
            'dados_completos': {}
        }

    def load_stats(self, user_data):
        """Carrega estatísticas salvas"""
        from kivy.storage.jsonstore import JsonStore
        try:
            store = JsonStore('session.json')
            if store.exists('auth'):
                saved_stats = store.get('auth')['stats']
                user_data['stats']['pesquisas'] = saved_stats.get('pesquisas', 0)
                user_data['stats']['registros'] = saved_stats.get('registros', 0)
                user_data['stats']['ultimas_viaturas'] = saved_stats.get('ultimas_viaturas', [])
        except Exception as e:
            print(f"Erro ao carregar estatísticas: {e}")

    def show_error(self, message):
        """Mostra diálogo de erro"""
        dialog = MDDialog(
            title="Erro de Login",
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ],
            radius=[10, 10, 10, 10]
        )
        dialog.open()

    def show_loading(self, show):
        """Mostra/oculta loading."""
        if show:
            content = BoxLayout(
                orientation='vertical', 
                spacing='15dp', 
                size_hint_y=None, 
                height='120dp'
            )
            content.add_widget(MDSpinner(
                size_hint=(None, None),
                size=('46dp', '46dp'),
                active=True,
                color=MDApp.get_running_app().theme_cls.primary_color
            ))
            content.add_widget(MDLabel(
                text="Fazendo login...",
                halign='center',
                theme_text_color="Secondary"
            ))

            self._loading_dialog = MDDialog(
                title="Autenticando",
                type="custom",
                content_cls=content,
                auto_dismiss=False,
                radius=[15, 15, 15, 15]
            )
            self._loading_dialog.open()
        else:
            if hasattr(self, '_loading_dialog') and self._loading_dialog:
                self._loading_dialog.dismiss()
                self._loading_dialog = None

    def forgot_password(self):
        """Processa solicitação de redefinição de senha."""
        email = self.ids.email.text.strip()

        if not email:
            self.show_error("Por favor, digite seu email para solicitar redefinição de senha")
            return

        if not self.validate_email(email):
            self.show_error("Por favor, digite um email válido")
            return

        # Mostra diálogo de confirmação
        dialog = MDDialog(
            title="Confirmar Solicitação",
            text=f"Deseja enviar uma solicitação de redefinição de senha para {email}?",
            buttons=[
                MDFlatButton(
                    text="CANCELAR",
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="ENVIAR",
                    on_release=lambda x: self.confirm_forgot_password(dialog, email)
                )
            ],
            radius=[10, 10, 10, 10]
        )
        dialog.open()

    def confirm_forgot_password(self, dialog, email):
        """Confirma e envia a solicitação de redefinição."""
        dialog.dismiss()

        # Mostra loading
        content = BoxLayout(
            orientation='vertical',
            spacing='15dp',
            size_hint_y=None,
            height='120dp'
        )
        content.add_widget(MDSpinner(
            size_hint=(None, None),
            size=('46dp', '46dp'),
            active=True,
            color=MDApp.get_running_app().theme_cls.primary_color
        ))
        content.add_widget(MDLabel(
            text="Aguarde...",
            halign='center',
            theme_text_color="Secondary"
        ))

        loading_dialog = MDDialog(
            title="Enviando solicitação...",
            type="custom",
            content_cls=content,
            auto_dismiss=False,
            radius=[15, 15, 15, 15]
        )
        loading_dialog.open()

        # Processa em thread separado
        def process_request(dt):
            try:
                app = MDApp.get_running_app()
                success, message = app.firebase.send_password_reset_notification(email)

                loading_dialog.dismiss()

                if success:
                    self.show_success(message)
                else:
                    self.show_error(message)

            except Exception as e:
                loading_dialog.dismiss()
                self.show_error(f"Erro inesperado: {str(e)}")

        Clock.schedule_once(process_request, 0.1)

    def show_success(self, message):
        """Mostra diálogo de sucesso."""
        dialog = MDDialog(
            title="Sucesso",
            text=message,
            buttons=[
                MDFlatButton(
                    text="OK",
                    on_release=lambda x: dialog.dismiss()
                )
            ],
            radius=[10, 10, 10, 10]
        )
        dialog.open()

class CameraScreen(MDScreen):
    camera_available = False
    camera_processor = None
    capture_in_progress = False
    real_time_detection = False
    detected_plates = []
    
    def on_enter(self):
        """Ao entrar na tela da câmera"""
        if not MDApp.get_running_app().current_user:
            self.manager.current = 'login'
            return
            
        # Inicializa a câmera
        self.setup_camera()

    def setup_camera(self):
        """Configura a câmera"""
        try:
            from android_camera import AndroidCameraProcessor
            
            self.ids.status_label.text = "Inicializando câmera..."
            self.ids.capture_btn.disabled = True
            
            self.camera_processor = AndroidCameraProcessor()
            self.camera_available = self.camera_processor.init_camera()
            
            if self.camera_available:
                self.ids.status_label.text = "Câmera pronta - Aponte para a placa"
                self.ids.capture_btn.disabled = False
                
                # Inicia preview em tempo real
                Clock.schedule_interval(self.update_camera_preview, 1.0/15.0)  # 15 FPS
            else:
                self.show_camera_error("Não foi possível acessar a câmera")
                
        except Exception as e:
            logging.error(f"Erro ao configurar câmera: {e}")
            self.show_camera_error(f"Erro: {str(e)}")

    def update_camera_preview(self, dt):
        """Atualiza o preview da câmera em tempo real"""
        if not self.camera_available or not self.camera_processor or self.capture_in_progress:
            return
        
        try:
            # Captura frame
            frame = self.camera_processor.capture_frame()
            
            if frame is not None:
                if self.real_time_detection:
                    # Processa com detecção em tempo real
                    processed_frame, plates = self.camera_processor.process_frame_with_detection(frame)
                    
                    # Atualiza placas detectadas
                    if plates:
                        self.detected_plates = plates
                        self.update_detected_plates_display(plates)
                    else:
                        self.clear_detected_plates_display()
                        
                    frame_to_show = processed_frame
                else:
                    frame_to_show = frame
                    
                # Converte para texture Kivy e atualiza preview
                texture = self.camera_processor.cv2_to_kivy_texture(frame_to_show)
                if texture:
                    self.ids.camera_preview.texture = texture
                    
        except Exception as e:
            logging.error(f"Erro no preview: {e}")

    def update_detected_plates_display(self, plates):
        """Atualiza a exibição das placas detectadas"""
        container = self.ids.plates_container
        container.clear_widgets()
        
        for plate in plates[:3]:  # Mostra apenas as 3 primeiras
            chip = MDChip(
                text=plate,
                icon="car",
                theme_text_color="Custom",
                text_color=[1, 1, 1, 1],
                md_bg_color=[0.0, 0.36, 0.80, 1],
                size_hint=[None, None],
                size=["100dp", "30dp"]
            )
            container.add_widget(chip)
        
        self.ids.status_label.text = f"Detectadas: {len(plates)} placa(s)"

    def clear_detected_plates_display(self):
        """Limpa a exibição de placas detectadas"""
        self.ids.plates_container.clear_widgets()
        if not self.capture_in_progress:
            self.ids.status_label.text = "Aponte para uma placa" if self.real_time_detection else "Modo visualização"

    def toggle_real_time_detection(self, active):
        """Ativa/desativa detecção em tempo real"""
        self.real_time_detection = active
        if active:
            self.ids.status_label.text = "Detecção ativa - Aponte para a placa"
        else:
            self.ids.status_label.text = "Detecção desativada"
            self.clear_detected_plates_display()

    def capture(self):
        """Captura e processa a imagem atual"""
        if not self.camera_available or self.capture_in_progress:
            return
            
        self.capture_in_progress = True
        self.show_loading(True)
        self.ids.status_label.text = "Processando imagem..."
        self.ids.capture_btn.disabled = True
        
        # Para o preview temporariamente
        Clock.unschedule(self.update_camera_preview)
        
        # Processa em background
        Clock.schedule_once(lambda dt: self.process_capture(), 0.1)

    def process_capture(self):
        """Processa a captura da imagem"""
        try:
            # Captura frame final
            frame = self.camera_processor.capture_frame()
            
            if frame is not None:
                # Detecta placas na imagem capturada
                plates = self.camera_processor.detect_plates(frame)
                
                if plates:
                    # Usa a primeira placa detectada
                    detected_plate = plates[0]
                    self.ids.status_label.text = f"Placa detectada: {detected_plate}"
                    
                    # Mostra confirmação
                    self.show_capture_success(detected_plate)
                    
                else:
                    self.ids.status_label.text = "Nenhuma placa detectada. Tente novamente."
                    self.reactivate_preview()
                    
            else:
                self.ids.status_label.text = "Erro ao capturar imagem"
                self.reactivate_preview()
                
        except Exception as e:
            logging.error(f'Camera: Erro no processamento: {e}')
            self.ids.status_label.text = f"Erro: {str(e)}"
            self.reactivate_preview()

    def show_capture_success(self, plate_text):
        """Mostra confirmação de captura bem-sucedida"""
        content = BoxLayout(orientation='vertical', spacing='15dp', padding='15dp')
        
        content.add_widget(MDLabel(
            text="✅ Placa Detectada!",
            halign='center',
            theme_text_color="Primary",
            font_style="H5"
        ))
        
        content.add_widget(MDLabel(
            text=f"Matrícula: {plate_text}",
            halign='center',
            theme_text_color="Secondary",
            font_style="H6"
        ))
        
        dialog = MDDialog(
            title=" ",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="USAR ESTA MATRÍCULA",
                    on_release=lambda x: self.use_detected_plate(dialog, plate_text)
                ),
                MDFlatButton(
                    text="CAPTURAR NOVAMENTE",
                    on_release=lambda x: self.retry_capture(dialog)
                )
            ]
        )
        dialog.open()

    def use_detected_plate(self, dialog, plate_text):
        """Usa a placa detectada e retorna para a tela principal"""
        dialog.dismiss()
        self.show_loading(False)
        self.return_to_main_screen(plate_text)

    def retry_capture(self, dialog):
        """Tenta capturar novamente"""
        dialog.dismiss()
        self.reactivate_preview()

    def reactivate_preview(self):
        """Reativa o preview da câmera"""
        self.capture_in_progress = False
        self.show_loading(False)
        self.ids.capture_btn.disabled = False
        Clock.schedule_interval(self.update_camera_preview, 1.0/15.0)

    def return_to_main_screen(self, plate_text):
        """Retorna para a tela principal com a placa detectada"""
        self.manager.current = 'main'
        main_screen = self.manager.get_screen('main')
        main_screen.ids.matricula_input.text = plate_text
        main_screen.ids.result_label.text = f"Placa detectada: {plate_text}"
        main_screen.ids.result_label.theme_text_color = "Primary"

    def show_loading(self, show):
        """Mostra/oculta overlay de loading"""
        if show:
            self.ids.loading_overlay.opacity = 1
            self.ids.loading_overlay.children[1].active = True  # Spinner
        else:
            self.ids.loading_overlay.opacity = 0
            self.ids.loading_overlay.children[1].active = False  # Spinner

    def show_camera_error(self, message):
        """Mostra erro da câmera"""
        self.ids.status_label.text = message
        self.ids.status_label.theme_text_color = "Error"

    def show_camera_info(self):
        """Mostra informações sobre o uso da câmera"""
        dialog = MDDialog(
            title="Como usar a câmera",
            text="• Aponte a câmera para a placa do veículo\n• Ative a detecção em tempo real para ver as placas detectadas\n• Capture quando a placa estiver visível\n• Use boa iluminação e evite reflexos",
            buttons=[
                MDFlatButton(
                    text="ENTENDI",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()

    def go_back(self):
        """Volta para a tela principal"""
        self.manager.current = 'main'

    def on_leave(self):
        """Ao sair da tela, para a câmera"""
        if self.camera_processor:
            self.camera_processor.stop_camera()
        Clock.unschedule(self.update_camera_preview)


class LineSeparator(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        self.height = 1
        with self.canvas:
            Color(0.8, 0.8, 0.8, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)

    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos

class MainScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ultimas_matriculas = []
        self.current_location = None
        self._loading_dialog = None
        self.plate_validator = PlateValidator()
        self._cache_verificacoes = {}  # Cache para verificações recentes
        self._cache_timeout = 300  # 5 minutos de cache
        self._last_verification_time = 0
    

    def _processar_matricula_otimizado(self, matricula):
        """Processa matrícula com otimizações para velocidade"""
        try:
            app = MDApp.get_running_app()
            start_time = datetime.now()

            # ✅ 1. VERIFICAÇÃO RÁPIDA DE CACHE (evita repetições)
            cache_key = f"{matricula}_{datetime.now().strftime('%Y%m%d%H')}"
            if cache_key in self._cache_verificacoes:
                cached_result = self._cache_verificacoes[cache_key]
                if time.time() - cached_result['timestamp'] < self._cache_timeout:
                    self._mostrar_resultado_cache(cached_result)
                    return

            # ✅ 2. VALIDAÇÃO LOCAL ULTRA-RÁPIDA
            if not self._validacao_local_rapida(matricula):
                self.show_result("❌ Formato de matrícula inválido", "error")
                return

            # ✅ 3. VERIFICAÇÃO PARALELA ASSÍNCRONA
            Clock.schedule_once(lambda dt: self._verificacao_assincrona(matricula, start_time), 0.01)

        except Exception as e:
            logging.error(f"Erro no processamento otimizado: {str(e)}")
            self.show_result("❌ Erro interno do sistema", "error")
            self.show_loading(False)


    def _verificacao_assincrona(self, matricula, start_time):
        """Executa verificações em background sem travar a UI"""
        try:
            app = MDApp.get_running_app()
            
            # ✅ 4. VERIFICAÇÃO LOCAL PRIORITÁRIA
            registro_local = self._verificar_local_rapido(matricula)
            if registro_local:
                self._processar_resultado_local(registro_local, start_time)
                return

            # ✅ 5. VERIFICAÇÕES EXTERNAS EM PARALELO
            resultados = self._executar_verificacoes_paralelas(matricula, app)
            
            # ✅ 6. PROCESSAMENTO INTELIGENTE DOS RESULTADOS
            self._processar_resultados_combinados(matricula, resultados, start_time)

        except Exception as e:
            logging.error(f"Erro na verificação assíncrona: {str(e)}")
            self.show_result("❌ Erro na verificação", "error")
            self.show_loading(False)


    def _processar_resultados_combinados(self, matricula, resultados, start_time):
        """Processa resultados de forma inteligente e rápida"""
        try:
            app = MDApp.get_running_app()
            
            # ✅ 7. PRIORIZA RESULTADOS POSITIVOS
            estacionamento = resultados.get('estacionamento', {})
            pagamento = resultados.get('pagamento', {})
            firebase = resultados.get('firebase')

            # Se tem estacionamento ativo → mostra primeiro
            if estacionamento.get('ativo'):
                self._processar_estacionamento_ativo(estacionamento)
                
            # Se tem pagamento válido → mostra segundo
            elif pagamento.get('sucesso') and pagamento.get('encontrado'):
                status = pagamento.get('status_pagamento', '').upper()
                if status == 'PAGO':
                    self.show_result(f"✅ Pagamento confirmado: {matricula}\nStatus: {status}", "success")
                    
            # Se tem registro no Firebase → mostra terceiro
            elif firebase:
                info = f"✅ Registro encontrado:\nMatrícula: {matricula}"
                if 'local' in firebase:
                    info += f"\nLocal: {firebase['local']}"
                if 'timestamp' in firebase:
                    info += f"\nData: {firebase['timestamp']}"
                self.show_result(info, "success")
                
            # Se não encontrou nada → registro novo
            else:
                self._registrar_nova_matricula_rapido(matricula, app)

            # ✅ 8. ATUALIZA ESTATÍSTICAS E CACHE
            self._atualizar_estatisticas_cache(matricula, resultados, start_time)

        except Exception as e:
            logging.error(f"Erro no processamento combinado: {str(e)}")
            self.show_result("❌ Erro no processamento", "error")
        finally:
            self.show_loading(False)


    def _registrar_nova_matricula_rapido(self, matricula, app):
        """Registro rápido com operações mínimas"""
        try:
            # Dados básicos
            data_atual = datetime.now().strftime('%Y-%m-%d')
            hora_atual = datetime.now().strftime('%H:%M:%S')
            local = "Local Padrão"
            
            if self.current_location:
                lat = self.current_location.get('lat', 'N/A')
                lon = self.current_location.get('lon', 'N/A')
                local = f"Lat: {lat:.4f}, Lon: {lon:.4f}"  # Precisão reduzida para velocidade

            # Salvar localmente (operação rápida)
            success = app.db_manager.save_viatura(
                matricula=matricula,
                local=local,
                usuario_email=app.current_user['email'],
                data_registro=data_atual,
                hora_registro=hora_atual,
                status='Ativa',
                estado_pagamento='pendente',
                firebase_synced=False
            )

            if success:
                # Tentativa rápida de sincronização Firebase
                try:
                    dados_viatura = {
                        'matricula': matricula,
                        'local': local,
                        'data_registro': data_atual,
                        'hora_registro': hora_atual,
                        'status': 'Ativa',
                        'usuario': app.current_user['email']
                    }
                    app.firebase.add_viatura(dados_viatura)
                    app.db_manager.update_sync_status(matricula, True)
                    self.show_result(f"✅ {matricula} registrada com sucesso!", "success")
                except:
                    self.show_result(f"✅ {matricula} salva localmente", "success")
                
                # Atualizar estatísticas
                app.current_user['stats']['registros'] += 1
                
            else:
                self.show_result("❌ Erro ao salvar", "error")

        except Exception as e:
            logging.error(f"Erro no registro rápido: {str(e)}")
            self.show_result("❌ Erro no registro", "error")

    def _atualizar_estatisticas_cache(self, matricula, resultados, start_time):
        """Atualiza estatísticas e cache de forma otimizada"""
        try:
            app = MDApp.get_running_app()
            
            # ✅ Atualizar estatísticas
            app.current_user['stats']['pesquisas'] += 1
            
            # ✅ Cache do resultado
            cache_key = f"{matricula}_{datetime.now().strftime('%Y%m%d%H')}"
            self._cache_verificacoes[cache_key] = {
                'matricula': matricula,
                'resultados': resultados,
                'timestamp': time.time()
            }
            
            # ✅ Limpar cache antigo (manter apenas últimas 50 entradas)
            if len(self._cache_verificacoes) > 50:
                oldest_keys = sorted(self._cache_verificacoes.keys(), 
                                   key=lambda k: self._cache_verificacoes[k]['timestamp'])[:10]
                for key in oldest_keys:
                    del self._cache_verificacoes[key]

            # ✅ Tempo de processamento para debug
            processing_time = (datetime.now() - start_time).total_seconds()
            if processing_time > 1.0:  # Log apenas se for lento
                logging.info(f"⏱️ Tempo processamento {matricula}: {processing_time:.2f}s")

            self.update_stats()

        except Exception as e:
            logging.warning(f"Erro ao atualizar cache: {e}")

    def _mostrar_resultado_cache(self, cached_result):
        """Mostra resultado do cache rapidamente"""
        resultados = cached_result['resultados']
        matricula = cached_result['matricula']

        # Lógica similar ao processamento normal, mas mais rápida
        estacionamento = resultados.get('estacionamento', {})
        pagamento = resultados.get('pagamento', {})
        
        if estacionamento.get('ativo'):
            self._processar_estacionamento_ativo(estacionamento)
        elif pagamento.get('sucesso') and pagamento.get('encontrado'):
            status = pagamento.get('status_pagamento', '').upper()
            self.show_result(f"✅ [CACHE] Pagamento: {matricula}\nStatus: {status}", "success")
        else:
            self.show_result(f"ℹ️ [CACHE] {matricula} - Sem registros ativos", "info")

    def _processar_resultado_local(self, registro_local, start_time):
        """Processa resultado do cache local rapidamente"""
        self.show_result(f"✅ [LOCAL] {registro_local['matricula']} já verificada hoje", "success")
        
        # Atualizar estatísticas rapidamente
        app = MDApp.get_running_app()
        app.current_user['stats']['pesquisas'] += 1
        self.update_stats()
        self.show_loading(False)
        
        # Log de performance
        processing_time = (datetime.now() - start_time).total_seconds()
        logging.info(f"⚡ Cache local: {processing_time:.3f}s")


    def _executar_verificacoes_paralelas(self, matricula, app):
        """Executa verificações em 'paralelo' (sequencial mas otimizado)"""
        resultados = {
            'estacionamento': None,
            'pagamento': None,
            'firebase': None
        }

        try:
            # ✅ VERIFICAÇÃO DE ESTACIONAMENTO (com timeout)
            def verificar_estacionamento():
                try:
                    return self.verificar_estacionamento_ativo(matricula)
                except Exception as e:
                    logging.warning(f"Erro estacionamento: {e}")
                    return {'ativo': False, 'erro': str(e)}

            # ✅ VERIFICAÇÃO DE PAGAMENTO (com timeout)  
            def verificar_pagamento():
                try:
                    return self.verificar_pagamento_status(matricula)
                except Exception as e:
                    logging.warning(f"Erro pagamento: {e}")
                    return {'sucesso': False, 'erro': str(e)}

            # Executa as verificações
            resultados['estacionamento'] = verificar_estacionamento()
            resultados['pagamento'] = verificar_pagamento()

            # ✅ VERIFICAÇÃO FIREBASE (apenas se necessário)
            if not resultados['estacionamento'].get('ativo'):
                try:
                    resultados['firebase'] = app.firebase.check_viatura(matricula)
                except Exception as e:
                    logging.warning(f"Erro Firebase: {e}")
                    resultados['firebase'] = None

        except Exception as e:
            logging.error(f"Erro nas verificações paralelas: {e}")

        return resultados
    

    def _verificar_local_rapido(self, matricula):
        """Verificação local otimizada"""
        try:
            app = MDApp.get_running_app()
            
            # Busca rápida no banco local
            local_record = app.db_manager.get_viatura(matricula)
            if not local_record:
                return None

            # Verificação rápida de data
            created_at = local_record.get('created_at')
            if created_at:
                try:
                    created_date = datetime.strptime(created_at, '%Y-%m-%d %H:%M:%S')
                    today = datetime.now()
                    # Verifica se foi registrado hoje (cache de 24h)
                    if created_date.date() == today.date():
                        return {
                            'matricula': matricula,
                            'local': local_record.get('local'),
                            'timestamp': created_at,
                            'source': 'local_cache',
                            'tipo': 'registro_recente'
                        }
                except ValueError:
                    pass

            return None
        except Exception as e:
            logging.warning(f"Erro na verificação local: {e}")
            return None


    def _validacao_local_rapida(self, matricula):
        """Validação local sem bloqueio"""
        if not matricula or len(matricula) < 4:
            return False
        
        # Validação básica de caracteres primeiro (mais rápido)
        clean_plate = re.sub(r'[^A-Z0-9]', '', matricula.upper())
        if len(clean_plate) < 4 or len(clean_plate) > 10:
            return False
            
        return True


    def validar_formato_matricula(self, matricula):
        """Valida o formato da matrícula usando o PlateValidator"""
        if not matricula or len(matricula) < 4:
            return False
            
        # Usar o validador oficial
        is_valid, country, normalized_plate, message = PlateValidator.validate_plate(matricula)
        
        if is_valid:
            # Atualizar o campo com a versão normalizada
            if normalized_plate and hasattr(self, 'ids') and hasattr(self.ids, 'matricula_input'):
                self.ids.matricula_input.text = normalized_plate
            return True
        else:
            # Mostrar exemplos de formatos suportados
            self.mostrar_formatos_suportados()
            return False
    
    def validar_matricula_em_tempo_real(self, text):
        """Validação em tempo real da matrícula"""
        if not text or len(text) < 3:
            return
        
        # Validar formato básico quando tiver pelo menos 6 caracteres
        if len(text) >= 6:
            is_valid, country, normalized, message = PlateValidator.validate_plate(text)
            
            if is_valid:
                country_name = PlateValidator.get_country_name(country)
                self.ids.matricula_input.helper_text = f"✅ {country_name} - Formato válido"
                self.ids.matricula_input.line_color_focus = (0.0, 0.78, 0.59, 1)  # Verde
            else:
                self.ids.matricula_input.helper_text = "Formato: ABC1234, CA123BC12, T123ABC, etc."
                self.ids.matricula_input.line_color_focus = (0.96, 0.26, 0.21, 1)  # Vermelho
    
    def mostrar_formatos_suportados(self):
        """Mostra diálogo com formatos suportados"""
        examples = PlateValidator.get_supported_formats_examples()
        
        content = BoxLayout(orientation='vertical', spacing='10dp', padding='10dp', size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        content.add_widget(MDLabel(
            text="Formatos de matrícula suportados:",
            theme_text_color="Primary",
            font_style="H6",
            size_hint_y=None,
            height='40dp'
        ))
        
        for example in examples:
            content.add_widget(MDLabel(
                text=example,
                theme_text_color="Secondary",
                font_style="Body1",
                size_hint_y=None,
                height='30dp'
            ))
        
        dialog = MDDialog(
            title="Formato Inválido",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="ENTENDI",
                    on_release=lambda x: dialog.dismiss()
                )
            ],
            radius=[10, 10, 10, 10],
            size_hint=(0.9, 0.8)
        )
        dialog.open()
    
    def validar_formato_matricula_estrito(self, matricula):
        """Validação estrita apenas para formatos oficiais"""
        is_valid, normalized_plate, message = PlateValidator.validate_plate_strict(matricula)
        
        if is_valid and normalized_plate and hasattr(self, 'ids') and hasattr(self.ids, 'matricula_input'):
            self.ids.matricula_input.text = normalized_plate
            
        return is_valid

    # ========== MÉTODOS CORRIGIDOS DE VERIFICAÇÃO DE ESTACIONAMENTOS ==========
    
    def verificar_estacionamento_ativo(self, matricula):
        """Método CORRIGIDO para verificador - considera validade temporal"""
        try:
            app = MDApp.get_running_app()
            matricula_limpa = re.sub(r'[-\s]', '', matricula).upper()
            
            logging.info(f"🔍 Verificador - Consultando: {matricula_limpa}")
            
            # Usa método ESPECÍFICO do verificador
            estacionamentos_data = app.firebase.get_estacionamentos_verificador()
            
            if estacionamentos_data is None:
                return {'ativo': False, 'matricula': matricula_limpa, 'erro': 'Sem permissão'}
                
            if not estacionamentos_data:
                return {'ativo': False, 'matricula': matricula_limpa}
            
            # Verificar cada estacionamento
            for registro_id, dados in estacionamentos_data.items():
                if dados and self._corresponde_matricula(dados, matricula_limpa):
                    # ✅ VERIFICAÇÃO CORRIGIDA: considerar validade temporal
                    if self._estacionamento_valido_com_tempo(dados):
                        logging.info(f"✅ Estacionamento ATIVO e VÁLIDO: {matricula_limpa}")
                        return {
                            'ativo': True,
                            'matricula': matricula_limpa,
                            'registro_id': registro_id,
                            'detalhes_completos': dados,
                            'fonte': 'verificador',
                            'valido_ate': dados.get('data_expiracao', 'N/A')
                        }
                    else:
                        logging.info(f"⏰ Estacionamento EXPIRADO: {matricula_limpa}")
                        
            return {'ativo': False, 'matricula': matricula_limpa}
            
        except Exception as e:
            logging.error(f"❌ Erro na verificação: {str(e)}")
            return {'ativo': False, 'matricula': matricula, 'erro': str(e)}

    def _estacionamento_valido_com_tempo(self, dados):
        """Verificação CORRIGIDA que considera validade temporal"""
        try:
            status = dados.get('status', '').upper()
            data_expiracao_str = dados.get('data_expiracao', '')
            data_inicio_str = dados.get('data_inicio', '')
            hora_inicio_str = dados.get('hora_inicio', '')
            
            # Verificar status
            if status != 'ATIVO':
                logging.info(f"❌ Status não é ATIVO: {status}")
                return False
            
            # ✅ VERIFICAÇÃO TEMPORAL CORRIGIDA
            agora = datetime.now()
            
            # Verificar data de expiração
            if data_expiracao_str:
                try:
                    # Converter data_expiracao para datetime
                    if 'T' in data_expiracao_str:
                        data_expiracao = datetime.fromisoformat(data_expiracao_str.replace('Z', '+00:00'))
                    else:
                        # Tentar formatos diferentes
                        for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d']:
                            try:
                                data_expiracao = datetime.strptime(data_expiracao_str, fmt)
                                break
                            except:
                                continue
                        else:
                            data_expiracao = None
                    
                    if data_expiracao and agora > data_expiracao:
                        logging.info(f"⏰ Expirado em: {data_expiracao}")
                        return False
                        
                except Exception as e:
                    logging.warning(f"Erro ao processar data_expiracao {data_expiracao_str}: {e}")
            
            # Verificar data de início (se aplicável)
            if data_inicio_str:
                try:
                    if 'T' in data_inicio_str:
                        data_inicio = datetime.fromisoformat(data_inicio_str.replace('Z', '+00:00'))
                    else:
                        data_inicio = datetime.strptime(data_inicio_str, '%Y-%m-%d')
                    
                    if data_inicio and agora < data_inicio:
                        logging.info(f"⏰ Ainda não iniciou: {data_inicio}")
                        return False
                        
                except Exception as e:
                    logging.warning(f"Erro ao processar data_inicio {data_inicio_str}: {e}")
            
            # ✅ VERIFICAÇÃO ADICIONAL: duração/horas restantes
            if hora_inicio_str and data_inicio_str:
                try:
                    # Combinar data e hora para calcular duração
                    data_hora_inicio_str = f"{data_inicio_str} {hora_inicio_str}"
                    data_hora_inicio = datetime.strptime(data_hora_inicio_str, '%Y-%m-%d %H:%M:%S')
                    
                    # Verificar se tem duração definida
                    duracao_horas = dados.get('duracao_horas', 0)
                    if duracao_horas:
                        data_hora_fim = data_hora_inicio + timedelta(hours=duracao_horas)
                        if agora > data_hora_fim:
                            logging.info(f"⏰ Duração esgotada: {duracao_horas}h")
                            return False
                            
                except Exception as e:
                    logging.warning(f"Erro ao calcular duração: {e}")
            
            logging.info(f"✅ Estacionamento válido temporalmente")
            return True
            
        except Exception as e:
            logging.error(f"Erro na verificação temporal: {e}")
            return False

    def _corresponde_matricula(self, dados, matricula_limpa):
        """Verifica se os dados correspondem à matrícula"""
        matricula_dados = dados.get('matricula', '')
        return re.sub(r'[-\s]', '', matricula_dados).upper() == matricula_limpa

    def _processar_estacionamento_ativo(self, resultado):
        """Processa quando há estacionamento ativo - COM INFORMAÇÕES TEMPORAIS"""
        matricula = resultado['matricula']
        detalhes = resultado.get('detalhes_completos', {})
        
        # Formatar informações ricas com dados temporais
        info_parts = [f"✅ ESTACIONAMENTO ATIVO\nMatrícula: {matricula}"]
        
        # Informações do estacionamento
        if detalhes.get('data_expiracao'):
            data_exp = self._formatar_data_completa(detalhes['data_expiracao'])
            info_parts.append(f"📅 Expira: {data_exp}")
        
        if detalhes.get('data_inicio'):
            data_ini = self._formatar_data_completa(detalhes['data_inicio'])
            info_parts.append(f"⏰ Início: {data_ini}")
        
        if detalhes.get('hora_inicio'):
            info_parts.append(f"🕒 Hora início: {detalhes['hora_inicio']}")
        
        # Calcular tempo restante se possível
        tempo_restante = self._calcular_tempo_restante(detalhes)
        if tempo_restante:
            info_parts.append(f"⏱️ Tempo restante: {tempo_restante}")
        
        if detalhes.get('endereco'):
            info_parts.append(f"📍 Local: {detalhes['endereco']}")
        
        if detalhes.get('usuario'):
            info_parts.append(f"👤 Cliente: {detalhes['usuario']}")
        
        if detalhes.get('valor'):
            info_parts.append(f"💰 Valor: {detalhes['valor']}€")
        
        if detalhes.get('duracao_horas'):
            info_parts.append(f"🕐 Duração: {detalhes['duracao_horas']}h")
        
        # Adicionar fonte da informação
        fonte = resultado.get('fonte', 'sistema')
        info_parts.append(f"🔍 Fonte: {fonte.replace('_', ' ').title()}")
        
        self.show_result("\n".join(info_parts), "success")

    def _formatar_data_completa(self, data_iso):
        """Formata data para exibição completa"""
        try:
            if 'T' in data_iso:
                dt = datetime.fromisoformat(data_iso.replace('Z', '+00:00'))
                return dt.strftime('%d/%m/%Y %H:%M')
            else:
                # Tentar diferentes formatos
                for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d']:
                    try:
                        dt = datetime.strptime(data_iso, fmt)
                        return dt.strftime('%d/%m/%Y %H:%M')
                    except:
                        continue
                return data_iso
        except:
            return data_iso

    def _calcular_tempo_restante(self, detalhes):
        """Calcula o tempo restante do estacionamento"""
        try:
            data_expiracao_str = detalhes.get('data_expiracao')
            if not data_expiracao_str:
                return None
            
            # Converter data de expiração
            if 'T' in data_expiracao_str:
                data_expiracao = datetime.fromisoformat(data_expiracao_str.replace('Z', '+00:00'))
            else:
                data_expiracao = datetime.strptime(data_expiracao_str, '%Y-%m-%d %H:%M:%S')
            
            agora = datetime.now()
            
            if agora > data_expiracao:
                return "EXPIRADO"
            
            diferenca = data_expiracao - agora
            
            # Formatar tempo restante
            if diferenca.days > 0:
                return f"{diferenca.days}d {diferenca.seconds//3600}h"
            elif diferenca.seconds >= 3600:
                horas = diferenca.seconds // 3600
                minutos = (diferenca.seconds % 3600) // 60
                return f"{horas}h {minutos}min"
            else:
                minutos = diferenca.seconds // 60
                return f"{minutos}min"
                
        except Exception as e:
            logging.warning(f"Erro ao calcular tempo restante: {e}")
            return None

    # ========== NOVO MÉTODO PARA VERIFICAÇÃO EM LOTE ==========
    
    def verificar_todos_estacionamentos_ativos(self):
        """Verifica TODOS os estacionamentos ativos e mostra apenas os válidos"""
        try:
            self.show_result("🔍 Verificando todos os estacionamentos...", "info")
            self.show_loading(True)
            Clock.schedule_once(lambda dt: self._verificar_todos_estacionamentos(), 0.1)
        except Exception as e:
            self.show_result(f"❌ Erro: {str(e)}", "error")
            self.show_loading(False)

    def _verificar_todos_estacionamentos(self):
        """Verifica todos os estacionamentos e filtra apenas os válidos"""
        try:
            app = MDApp.get_running_app()
            
            # Buscar dados
            estacionamentos_data = app.firebase.get_estacionamentos_verificador()
            
            if estacionamentos_data is None:
                self.show_loading(False)
                self.show_result("❌ Sem permissão para acessar dados", "error")
                return
                
            if not estacionamentos_data:
                self.show_loading(False)
                self.show_result("ℹ️ Nenhum estacionamento encontrado", "info")
                return
            
            estacionamentos_validos = []
            estacionamentos_expirados = []
            
            # Verificar cada estacionamento
            for registro_id, dados in estacionamentos_data.items():
                if not dados or not isinstance(dados, dict):
                    continue
                
                matricula = dados.get('matricula', '')
                if not matricula:
                    continue
                
                # Verificar validade
                if self._estacionamento_valido_com_tempo(dados):
                    estacionamentos_validos.append({
                        'matricula': matricula,
                        'detalhes': dados,
                        'registro_id': registro_id
                    })
                else:
                    estacionamentos_expirados.append({
                        'matricula': matricula,
                        'detalhes': dados,
                        'registro_id': registro_id
                    })
            
            self.show_loading(False)
            self._mostrar_relatorio_estacionamentos(estacionamentos_validos, estacionamentos_expirados)
            
        except Exception as e:
            logging.error(f"Erro na verificação em lote: {str(e)}")
            self.show_loading(False)
            self.show_result(f"❌ Erro: {str(e)}", "error")

    def _mostrar_relatorio_estacionamentos(self, validos, expirados):
        """Mostra relatório completo de estacionamentos"""
        content = BoxLayout(orientation='vertical', spacing='12dp', padding='12dp', size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        # Header
        header = BoxLayout(orientation='horizontal', size_hint_y=None, height='50dp')
        header.add_widget(MDLabel(
            text=f"[size=18][b]RELATÓRIO ESTACIONAMENTOS - {datetime.now().strftime('%d/%m/%Y %H:%M')}[/b][/size]",
            markup=True,
            halign='center',
            size_hint_x=1
        ))
        content.add_widget(header)
        content.add_widget(LineSeparator())
        
        # Seção de válidos
        if validos:
            content.add_widget(MDLabel(
                text=f"✅ ESTACIONAMENTOS VÁLIDOS ({len(validos)})",
                theme_text_color="Primary",
                font_style="H6",
                bold=True,
                size_hint_y=None,
                height='40dp'
            ))
            
            scroll_validos = ScrollView(size_hint=(1, None), height='300dp')
            grid_validos = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
            grid_validos.bind(minimum_height=grid_validos.setter('height'))
            
            for estacionamento in validos:
                card = self._criar_card_estacionamento_detalhado(estacionamento, "valido")
                grid_validos.add_widget(card)
            
            scroll_validos.add_widget(grid_validos)
            content.add_widget(scroll_validos)
        
        # Seção de expirados
        if expirados:
            content.add_widget(MDLabel(
                text=f"❌ ESTACIONAMENTOS EXPIRADOS ({len(expirados)})",
                theme_text_color="Error",
                font_style="H6",
                bold=True,
                size_hint_y=None,
                height='40dp'
            ))
            
            scroll_expirados = ScrollView(size_hint=(1, None), height='200dp')
            grid_expirados = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
            grid_expirados.bind(minimum_height=grid_expirados.setter('height'))
            
            for estacionamento in expirados:
                card = self._criar_card_estacionamento_detalhado(estacionamento, "expirado")
                grid_expirados.add_widget(card)
            
            scroll_expirados.add_widget(grid_expirados)
            content.add_widget(scroll_expirados)
        
        # Estatísticas
        stats_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='40dp', spacing='10dp')
        
        stats_text = [
            f"[b]✅ {len(validos)} válidos[/b]",
            f"[color=ff3333]❌ {len(expirados)} expirados[/color]",
            f"[b]📊 Total: {len(validos) + len(expirados)}[/b]"
        ]
        
        for stat in stats_text:
            stats_layout.add_widget(MDLabel(
                text=stat,
                markup=True,
                theme_text_color="Primary",
                halign='center',
                size_hint_x=0.33
            ))
        
        content.add_widget(stats_layout)
        
        # Diálogo
        dialog = MDDialog(
            type="custom",
            content_cls=content,
            size_hint=(0.98, 0.95),
            buttons=[
                MDFlatButton(
                    text="FECHAR",
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="ATUALIZAR",
                    on_release=lambda x: (dialog.dismiss(), self.verificar_todos_estacionamentos_ativos())
                )
            ]
        )
        dialog.open()
        
        # Mostrar resultado na tela principal
        if validos:
            self.show_result(f"✅ {len(validos)} estacionamentos válidos encontrados", "success")
        else:
            self.show_result("ℹ️ Nenhum estacionamento válido encontrado", "info")

    def _criar_card_estacionamento_detalhado(self, estacionamento, tipo):
        """Cria card detalhado para estacionamento"""
        dados = estacionamento['detalhes']
        matricula = estacionamento['matricula']
        
        card = MDCard(
            size_hint_y=None,
            height='140dp' if tipo == "valido" else '120dp',
            elevation=2,
            padding='12dp',
            radius=[8]
        )
        
        card_layout = BoxLayout(orientation='vertical', spacing='4dp')
        
        # Top row
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='30dp')
        top_row.add_widget(MDLabel(
            text=f"[b]{matricula}[/b]",
            markup=True,
            theme_text_color="Primary",
            font_style="H6",
            size_hint_x=0.7
        ))
        
        status_text = "✅ VÁLIDO" if tipo == "valido" else "❌ EXPIRADO"
        status_color = "Primary" if tipo == "valido" else "Error"
        
        top_row.add_widget(MDLabel(
            text=status_text,
            theme_text_color=status_color,
            font_style="Caption",
            bold=True,
            size_hint_x=0.3,
            halign='right'
        ))
        card_layout.add_widget(top_row)
        
        # Informações temporais
        info_tempo = []
        
        if dados.get('data_expiracao'):
            data_exp = self._formatar_data_completa(dados['data_expiracao'])
            info_tempo.append(f"Expira: {data_exp}")
        
        if dados.get('data_inicio'):
            data_ini = self._formatar_data_completa(dados['data_inicio'])
            info_tempo.append(f"Início: {data_ini}")
        
        if tipo == "valido":
            tempo_restante = self._calcular_tempo_restante(dados)
            if tempo_restante:
                info_tempo.append(f"Restante: {tempo_restante}")
        
        if info_tempo:
            card_layout.add_widget(MDLabel(
                text=" | ".join(info_tempo),
                theme_text_color="Secondary",
                font_style="Caption",
                size_hint_y=None,
                height='25dp'
            ))
        
        # Informações adicionais
        info_extra = []
        
        if dados.get('usuario'):
            info_extra.append(f"👤 {dados['usuario']}")
        
        if dados.get('endereco'):
            info_extra.append(f"📍 {dados['endereco']}")
        
        if dados.get('valor'):
            info_extra.append(f"💰 {dados['valor']}€")
        
        if info_extra:
            card_layout.add_widget(MDLabel(
                text=" | ".join(info_extra),
                theme_text_color="Secondary",
                font_style="Caption",
                size_hint_y=None,
                height='25dp'
            ))
        
        card.add_widget(card_layout)
        return card
	
    # ⚠️ Adicione este método se quiser usar OCR:
    def _ocr_image(self, image_path):
        """Processa OCR com segurança no Android"""
        if kivy_platform == 'android':
            logging.warning("OCR não suportado no Android")
            return None
        if pytesseract is None:
            logging.warning("pytesseract não está disponível")
            return None
        try:
            # Exemplo de uso (ajuste conforme sua lógica)
            text = pytesseract.image_to_string(image_path)
            return text.strip()
        except Exception as e:
            logging.error(f"Erro no OCR: {e}")
            return None
            
    # ========== ATUALIZAR O MÉTODO listar_estacionamentos_ativos ==========
    
    def listar_estacionamentos_ativos(self):
        """Agora usa a verificação temporal correta"""
        self.verificar_todos_estacionamentos_ativos()

    # ========== MÉTODO PRINCIPAL DE PROCESSAMENTO ==========
    
    def _processar_matricula(self, matricula):
        """Processa matrícula com verificações melhoradas"""
        try:
            from datetime import datetime
            app = MDApp.get_running_app()

            # ✅ VERIFICAÇÃO LOCAL
            local_record = app.db_manager.get_viatura(matricula)
            if local_record:
                created_at = local_record.get('created_at')
                if created_at:
                    try:
                        created_date = datetime.strptime(created_at, '%Y-%m-%d %H:%M:%S')
                        today = datetime.now().date()
                        if created_date.date() == today:
                            self.show_result(f"✅ Matrícula {matricula} já registrada hoje.", "success")
                            app.current_user['stats']['pesquisas'] += 1
                            # Track last verifications
                            if 'ultimas_verificacoes' not in app.current_user['stats']:
                                app.current_user['stats']['ultimas_verificacoes'] = []
                            app.current_user['stats']['ultimas_verificacoes'].append(f"{datetime.now().strftime('%H:%M:%S')} - {matricula}")
                            # Keep only last 10 verifications
                            if len(app.current_user['stats']['ultimas_verificacoes']) > 10:
                                app.current_user['stats']['ultimas_verificacoes'] = app.current_user['stats']['ultimas_verificacoes'][-10:]
                            self.update_stats()
                            self.save_session(app.current_user)
                            self.show_loading(False)
                            return
                    except ValueError:
                        pass

            # ✅ VERIFICAÇÃO: Estacionamento ativo
            resultado_estacionamento = self.verificar_estacionamento_ativo(matricula)
            
            if resultado_estacionamento.get('ativo'):
                # Tem estacionamento ativo - mostrar informações
                self._processar_estacionamento_ativo(resultado_estacionamento)
                
            else:
                # ✅ COMPORTAMENTO ORIGINAL
                registro = self.check_viatura(matricula)
                
                if registro:
                    info = f"✅ Registro encontrado:\nMatrícula: {matricula}"
                    if 'local' in registro:
                        info += f"\nLocal: {registro['local']}"
                    if 'timestamp' in registro:
                        info += f"\nData: {registro['timestamp']}"

                    self.show_result(info, "success")
                else:
                    # Verifica se há registro pendente no cache offline
                    cache_status = app.firebase.offline_cache.get_cache_status()
                    if cache_status.get('pending_registrations', 0) > 0:
                        pending = app.firebase.offline_cache.get_pending_registrations()
                        matricula_pendente = any(p['matricula'].upper() == matricula for p in pending)
                        if matricula_pendente:
                            self.show_result(f"⚠️ Matrícula {matricula} registrada offline.\nAguardando sincronização.", "warning")
                            return

                    self._registrar_nova_matricula(matricula, app)
            
            # ✅ ATUALIZAÇÃO DE ESTATÍSTICAS
            app.current_user['stats']['pesquisas'] += 1
            # Track last verifications
            if 'ultimas_verificacoes' not in app.current_user['stats']:
                app.current_user['stats']['ultimas_verificacoes'] = []
            app.current_user['stats']['ultimas_verificacoes'].append(f"{datetime.now().strftime('%H:%M:%S')} - {matricula}")
            # Keep only last 10 verifications
            if len(app.current_user['stats']['ultimas_verificacoes']) > 10:
                app.current_user['stats']['ultimas_verificacoes'] = app.current_user['stats']['ultimas_verificacoes'][-10:]
            
            self.update_stats()
            self.save_session(app.current_user)

            # Salva estatísticas no Firebase após cada verificação
            try:
                user_id = app.current_user.get('user_id') or app.firebase.user_id
                if user_id:
                    success, message = app.firebase.save_estatisticas(
                        user_id,
                        app.current_user['stats']
                    )
                    if not success:
                        logging.warning(f"Erro ao salvar estatísticas no Firebase: {message}")
                else:
                    logging.warning("User ID não disponível para salvar estatísticas")
            except Exception as e:
                logging.warning(f"Erro ao sincronizar estatísticas: {str(e)}")

        except Exception as e:
            logging.error(f"Erro ao processar matrícula: {str(e)}")
            self.ids.result_label.text = f"❌ Erro: {str(e)}"
            self.ids.result_label.theme_text_color = "Error"
        finally:
            self.show_loading(False)

    # ========== MÉTODOS EXISTENTES ==========
    
    def update_user_info(self, user_data):
        """Atualiza as informações do usuário na tela principal"""
        if hasattr(self.ids, 'user_label'):
            if user_data and 'user_data' in user_data:
                nome = user_data['user_data'].get('nome', 'Usuário')
                self.ids.user_label.text = f"👤 {nome}"
            else:
                # Fallback para email se não tiver nome
                email = user_data.get('email', 'Usuário') if user_data else 'Usuário'
                self.ids.user_label.text = f"👤 {email.split('@')[0]}"

    def start_scanner(self):
        self.manager.current = 'camera'

    def on_pre_enter(self):
        """Ao entrar na tela principal do verificador"""
        if not MDApp.get_running_app().current_user:
            self.manager.current = 'login'
            return
            
        app = MDApp.get_running_app()
        
        # Verifica se é funcionário/autorizado
        if not app.firebase._is_funcionario():
            self.show_result("❌ Acesso restrito a funcionários autorizados", "error")
            Clock.schedule_once(lambda dt: self.logout(), 3)
            return
            
        self.update_user_info(app.current_user)
        self.update_stats()
        self.get_location()
        self.ids.result_label.text = "Verificador - Digite uma matrícula"
        self.ids.result_label.theme_text_color = "Secondary"

    
    def get_location(self):
        try:
            import random
            self.current_location = {
                'lat': -25.9692 + random.uniform(-0.01, 0.01),
                'lon': 32.5732 + random.uniform(-0.01, 0.01)
            }
            lat = self.current_location['lat']
            lon = self.current_location['lon']
            self.ids.result_label.text = f"📍 Localização simulada: {lat:.6f}, {lon:.6f}"
            self.ids.result_label.theme_text_color = "Primary"
            
        except Exception as e:
            self.ids.result_label.text = f"❌ Erro ao obter localização: {str(e)}"
            self.ids.result_label.theme_text_color = "Error"
            self.current_location = None
    
    def update_stats(self):
        if hasattr(self.ids, 'stats_label'):
            user = MDApp.get_running_app().current_user
            if user and 'stats' in user:
                stats = user['stats']
                self.ids.stats_label.text = f"🔍 {stats['pesquisas']} | 📝 {stats['registros']}"

    def check_viatura(self, matricula: str) -> Optional[dict]:
        try:
            app = MDApp.get_running_app()
            local_record = app.db_manager.get_viatura(matricula)
            if local_record:
                from datetime import datetime
                created_at = local_record.get('created_at')
                if created_at:
                    try:
                        created_date = datetime.strptime(created_at, '%Y-%m-%d %H:%M:%S').date()
                        today = datetime.now().date()
                        if created_date == today:
                            return {
                                'matricula': matricula,
                                'local': local_record.get('local'),
                                'timestamp': created_at,
                                'source': 'local'
                            }
                    except ValueError:
                        pass
            
            return app.firebase.check_viatura(matricula)
        except Exception as e:
            logging.error(f"Erro ao consultar viatura: {str(e)}")
            return None
    
    def registrar_ou_verificar(self):
        """Método principal otimizado"""
        try:
            matricula = self.ids.matricula_input.text.strip().upper()
            
            if not matricula:
                self.show_result("❌ Digite uma matrícula válida", "error")
                self.ids.matricula_input.error = True
                return
            
            # Validação rápida inicial
            if not self._validacao_local_rapida(matricula):
                self.show_result("❌ Formato de matrícula inválido", "error")
                self.ids.matricula_input.error = True
                return
                
            self.ids.matricula_input.error = False
            self.show_loading(True)
            
            # Usar processamento otimizado
            self._processar_matricula_otimizado(matricula)
            
        except Exception as e:
            logging.error(f"Erro em registrar_ou_verificar: {str(e)}")
            self.show_result("❌ Erro interno do sistema", "error")
            self.show_loading(False)

    # ADICIONAR método para limpar cache
    def limpar_cache_verificacoes(self):
        """Limpa o cache de verificações (útil para testes)"""
        self._cache_verificacoes.clear()
        logging.info("✅ Cache de verificações limpo")


    def verificar_estacionamento_ativo_otimizado(self, matricula):
        """Versão otimizada da verificação de estacionamento"""
        try:
            app = MDApp.get_running_app()
            matricula_limpa = re.sub(r'[-\s]', '', matricula).upper()
            
            # Busca direta sem processamento extra
            estacionamentos_data = app.firebase.get_estacionamentos_verificador()
            
            if estacionamentos_data is None:
                return {'ativo': False, 'matricula': matricula_limpa, 'erro': 'Sem permissão'}
                
            if not estacionamentos_data:
                return {'ativo': False, 'matricula': matricula_limpa}
            
            # Busca rápida pela matrícula
            for registro_id, dados in estacionamentos_data.items():
                if dados and self._corresponde_matricula_rapido(dados, matricula_limpa):
                    if self._estacionamento_valido_com_tempo(dados):
                        return {
                            'ativo': True,
                            'matricula': matricula_limpa,
                            'registro_id': registro_id,
                            'detalhes_completos': dados
                        }
                    break  # Para na primeira correspondência
            
            return {'ativo': False, 'matricula': matricula_limpa}
            
        except Exception as e:
            logging.error(f"❌ Erro verificação estacionamento: {str(e)}")
            return {'ativo': False, 'matricula': matricula, 'erro': str(e)}
        

    def _corresponde_matricula_rapido(self, dados, matricula_limpa):
        """Verificação rápida de correspondência"""
        matricula_dados = dados.get('matricula', '')
        return re.sub(r'[-\s]', '', matricula_dados).upper() == matricula_limpa
    
       
    def _processar_verificacao_combinada(self, matricula):
        """
        Processa verificação combinada de pagamento e estacionamento
        """
        try:
            app = MDApp.get_running_app()
            
            # Fazer verificação combinada
            resultado = self.verificar_pagamento_e_estacionamento(matricula)
            
            if resultado.get('verificacao_completa'):
                status_geral = resultado['status_geral']
                mensagem_geral = resultado['mensagem_geral']
                
                # Montar relatório detalhado
                relatorio = [f"📊 RELATÓRIO - {matricula}", f"Status Geral: {status_geral}"]
                
                # Informações de pagamento
                pagamento = resultado['pagamento']
                if pagamento['sucesso'] and pagamento['encontrado']:
                    relatorio.append(f"💳 Pagamento: {pagamento['status_pagamento']}")
                    if pagamento['dados_completos'].get('ultima_atualizacao'):
                        relatorio.append(f"📅 Última atualização: {pagamento['dados_completos']['ultima_atualizacao']}")
                else:
                    relatorio.append("💳 Pagamento: Não encontrado")
                
                # Informações de estacionamento
                estacionamento = resultado['estacionamento']
                if estacionamento.get('ativo'):
                    relatorio.append("🅿️ Estacionamento: ATIVO")
                    if estacionamento.get('detalhes_completos', {}).get('data_expiracao'):
                        relatorio.append(f"⏰ Expira: {estacionamento['detalhes_completos']['data_expiracao']}")
                else:
                    relatorio.append("🅿️ Estacionamento: Não ativo")
                
                self.show_result("\n".join(relatorio), "success" if status_geral in ['REGULAR', 'ATIVO'] else "warning")
                
            else:
                # Fallback para o método original
                self._processar_matricula(matricula)
            
            # Atualizar estatísticas
            app.current_user['stats']['pesquisas'] += 1
            self.update_stats()
            
        except Exception as e:
            logging.error(f"Erro na verificação combinada: {str(e)}")
            # Fallback para método original
            self._processar_matricula(matricula)

    def _registrar_nova_matricula(self, matricula, app):
        try:
            # Obter data e hora atual
            data_atual = datetime.now().strftime('%Y-%m-%d')
            hora_atual = datetime.now().strftime('%H:%M:%S')
            
            local = "Local Padrão"
            if self.current_location:
                lat = self.current_location.get('lat', 'N/A')
                lon = self.current_location.get('lon', 'N/A')
                local = f"Lat: {lat:.6f}, Lon: {lon:.6f}"
            
            # Dados completos para salvar
            dados_viatura = {
                'matricula': matricula,
                'local': local,
                'data_registro': data_atual,
                'hora_registro': hora_atual,
                'status': 'Ativa',
                'usuario': app.current_user['email'],
                'estado_pagamento': 'pendente'
            }
            
            # Salvar localmente
            success = app.db_manager.save_viatura(
                matricula=matricula,
                local=local,
                usuario_email=app.current_user['email'],
                data_registro=data_atual,
                hora_registro=hora_atual,
                status='Ativa',
                estado_pagamento='pendente',
                latitude=self.current_location.get('lat') if self.current_location else None,
                longitude=self.current_location.get('lon') if self.current_location else None,
                firebase_synced=False
            )
            
            if not success:
                self.show_result("❌ Erro ao salvar localmente", "error")
                return
                
            # Sincronizar com Firebase
            try:
                success, message = app.firebase.add_viatura(dados_viatura)
                
                if success:
                    app.db_manager.update_sync_status(matricula, True)
                    self.show_result(f"✅ Matrícula {matricula} registrada com sucesso!", "success")
                    app.current_user['stats']['registros'] += 1
                    
                    # Atualizar últimas viaturas
                    ultimas = app.current_user['stats'].get('ultimas_viaturas', [])
                    ultimas.append(matricula)
                    if len(ultimas) > 5:
                        ultimas = ultimas[-5:]
                    app.current_user['stats']['ultimas_viaturas'] = ultimas
                    
                    app.db_manager.update_user_stats(app.current_user['email'], app.current_user['stats'])
                    
                    Clock.schedule_once(lambda dt: setattr(self.ids.matricula_input, 'text', ''), 1.0)
                    
                else:
                    # Verifica se foi salvo no cache offline
                    cache_status = app.firebase.offline_cache.get_cache_status()
                    if cache_status.get('pending_registrations', 0) > 0:
                        self.show_result(f"⚠️ Salvo offline. Sincronização automática em até 30 minutos.", "warning")
                    else:
                        self.show_result(f"⚠️ Salvo localmente. Erro Firebase: {message}", "warning")
                    
            except Exception as e:
                # Verifica se foi salvo no cache offline
                cache_status = app.firebase.offline_cache.get_cache_status()
                if cache_status.get('pending_registrations', 0) > 0:
                    self.show_result("⚠️ Salvo offline. Sincronização automática em até 30 minutos.", "warning")
                else:
                    self.show_result("⚠️ Salvo localmente. Erro de conexão", "warning")
                logging.error(f"Erro ao sincronizar com Firebase: {str(e)}")
                
        except Exception as e:
            self.show_result("❌ Erro no registro", "error")
            logging.error(f"Erro geral no registro: {str(e)}")

    def show_result(self, message, color_type="info"):
        self.ids.result_label.text = message
        color_map = {
            "success": "Primary",
            "error": "Error", 
            "warning": "Secondary",
            "info": "Secondary"
        }
        self.ids.result_label.theme_text_color = color_map.get(color_type, "Secondary")

    def save_session(self, user_data):
        try:
            from kivy.storage.jsonstore import JsonStore
            store = JsonStore('session.json')
            store.put('auth', 
                email=user_data['email'],
                refresh_token=user_data.get('refreshToken', ''),
                stats=user_data['stats']
            )
        except Exception as e:
            logging.error(f"Erro ao salvar sessão: {str(e)}")

    def show_loading(self, show):
        self.ids.matricula_input.disabled = show
        
        if hasattr(self, '_loading_dialog') and self._loading_dialog:
            self._loading_dialog.dismiss()
            self._loading_dialog = None
        
        if show:
            content = BoxLayout(orientation='vertical', spacing='15dp', size_hint_y=None, height='120dp')
            spinner = MDSpinner(
                size_hint=(None, None), 
                size=('46dp', '46dp'), 
                active=True,
                color=MDApp.get_running_app().theme_cls.primary_color
            )
            content.add_widget(spinner)
            content.add_widget(MDLabel(
                text="Processando matrícula...", 
                halign='center',
                theme_text_color="Secondary"
            ))
            
            self._loading_dialog = MDDialog(
                title="Aguarde",
                type="custom",
                content_cls=content,
                size_hint=(0.8, None),
                height='200dp',
                auto_dismiss=False,
                radius=[15, 15, 15, 15]
            )
            self._loading_dialog.open()

    def logout(self):
        dialog = MDDialog(
            title="Confirmar Logout",
            text="Tem certeza que deseja sair?",
            buttons=[
                MDFlatButton(
                    text="CANCELAR",
                    on_release=lambda x: dialog.dismiss()
                ),
                MDRaisedButton(
                    text="SAIR",
                    on_release=lambda x: self.confirm_logout(dialog)
                )
            ],
            radius=[10, 10, 10, 10]
        )
        dialog.open()

    def confirm_logout(self, dialog):
        dialog.dismiss()
        MDApp.get_running_app().current_user = None
        self.manager.current = 'login'
        self.ids.matricula_input.text = ""
        self.ids.result_label.text = "Bem-vindo! Digite uma matrícula ou use o scanner."

    def show_stats(self):
        app = MDApp.get_running_app()
        if not app.current_user:
            return

        user = app.current_user
        stats = user['stats']

        # Get today's registrations
        today_matriculas = app.db_manager.get_today_viaturas()
        today_registrations = len(today_matriculas)

        # Get daily goal from user data (default to 10 if not set)
        daily_goal = stats.get('meta_diaria', 10)

        # Calculate performance rate (success rate)
        desempenho = (stats['registros'] / stats['pesquisas']) * 100 if stats['pesquisas'] > 0 else 0

        # Get last verifications (last 5 searches)
        last_verifications = stats.get('ultimas_verificacoes', [])[-5:]

        # Get cache status for offline info
        cache_status = app.firebase.offline_cache.get_cache_status()
        pending_offline = cache_status.get('pending_registrations', 0)
        pending_stats = cache_status.get('pending_statistics', 0)

        content = BoxLayout(
            orientation='vertical',
            spacing='15dp',
            padding='20dp',
            size_hint_y=None
        )
        content.bind(minimum_height=content.setter('height'))

        content.add_widget(MDLabel(
            text=f"Estatísticas de {user['email']}",
            theme_text_color="Primary",
            font_style="H6",
            halign='center',
            size_hint_y=None,
            height='40dp'
        ))

        # Daily goal and today's progress
        goal_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='50dp', spacing='10dp')
        goal_layout.add_widget(MDLabel(
            text=f"Meta diária: {daily_goal}",
            theme_text_color="Secondary",
            size_hint_x=0.5
        ))
        goal_layout.add_widget(MDLabel(
            text=f"Hoje: {today_registrations}/{daily_goal}",
            theme_text_color="Primary" if today_registrations >= daily_goal else "Error",
            size_hint_x=0.5,
            halign='right'
        ))
        content.add_widget(goal_layout)

        # Main stats grid
        stats_grid = GridLayout(cols=2, spacing='10dp', size_hint_y=None, height='80dp')

        stats_grid.add_widget(MDLabel(
            text=f"Pesquisas realizadas:",
            theme_text_color="Secondary"
        ))
        stats_grid.add_widget(MDLabel(
            text=f"{stats['pesquisas']}",
            theme_text_color="Primary",
            halign='right'
        ))

        stats_grid.add_widget(MDLabel(
            text=f"Matrículas registradas:",
            theme_text_color="Secondary"
        ))
        stats_grid.add_widget(MDLabel(
            text=f"{stats['registros']}",
            theme_text_color="Primary",
            halign='right'
        ))

        content.add_widget(stats_grid)

        # Performance rate
        content.add_widget(MDLabel(
            text=f"Taxa de desempenho: {desempenho:.1f}%",
            theme_text_color="Secondary",
            halign='center',
            size_hint_y=None,
            height='30dp'
        ))

        # Last verifications
        if last_verifications:
            content.add_widget(MDLabel(
                text="Últimas verificações:",
                theme_text_color="Secondary",
                size_hint_y=None,
                height='30dp'
            ))

            for verification in last_verifications:
                content.add_widget(MDLabel(
                    text=f"• {verification}",
                    theme_text_color="Primary",
                    font_style="Caption",
                    size_hint_y=None,
                    height='25dp'
                ))

        # Last matriculas
        if stats['ultimas_viaturas']:
            content.add_widget(MDLabel(
                text="Últimas matrículas:",
                theme_text_color="Secondary",
                size_hint_y=None,
                height='30dp'
            ))

            ultimas_text = ", ".join(stats['ultimas_viaturas'][-3:])
            content.add_widget(MDLabel(
                text=ultimas_text,
                theme_text_color="Primary",
                font_style="Caption",
                halign='center',
                size_hint_y=None,
                height='25dp'
            ))

        # Offline status
        if pending_offline > 0 or pending_stats > 0:
            content.add_widget(MDLabel(
                text="Status Offline:",
                theme_text_color="Secondary",
                size_hint_y=None,
                height='30dp'
            ))

            offline_info = []
            if pending_offline > 0:
                offline_info.append(f"{pending_offline} registros pendentes")
            if pending_stats > 0:
                offline_info.append(f"{pending_stats} estatísticas pendentes")

            content.add_widget(MDLabel(
                text=" | ".join(offline_info),
                theme_text_color="Error",
                font_style="Caption",
                halign='center',
                size_hint_y=None,
                height='25dp'
            ))

        dialog = MDDialog(
            title=" ",
            type="custom",
            content_cls=content,
            buttons=[
                MDFlatButton(
                    text="FECHAR",
                    on_release=lambda x: dialog.dismiss()
                )
            ],
            radius=[15, 15, 15, 15]
        )
        dialog.open()

    def listar_matriculas(self, filter_paid=False):
        """Lista as matrículas registradas hoje com detalhes completos"""
        app = MDApp.get_running_app()
        today_matriculas = app.db_manager.get_today_viaturas()

        all_matriculas = []
        for mat in today_matriculas:
            all_matriculas.append({
                'matricula': mat['matricula'],
                'local': mat['local'] or 'N/A',
                'created_at': mat.get('created_at', 'N/A'),
                'estado_pagamento': mat.get('estado_pagamento', 'Desconhecido'),
                'usuario_email': mat.get('usuario_email', 'N/A'),
                'source': 'Local DB'
            })

        # Filter by paid status if requested
        if filter_paid:
            all_matriculas = [m for m in all_matriculas if m['estado_pagamento'].lower() == 'pago']

        all_matriculas.sort(key=lambda x: x['created_at'] if x['created_at'] != 'N/A' else '', reverse=True)
        today = datetime.now().strftime('%d/%m/%Y')

        content = BoxLayout(orientation='vertical', spacing='12dp', padding='12dp', size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))

        header = BoxLayout(orientation='horizontal', size_hint_y=None, height='50dp')
        title_text = f"MATRÍCULAS PAGAS DE HOJE ({today})" if filter_paid else f"MATRÍCULAS DE HOJE ({today})"
        header.add_widget(MDLabel(
            text=f"[size=18][b]{title_text}[/b][/size]",
            markup=True,
            halign='center',
            size_hint_x=0.9
        ))
        content.add_widget(header)
        content.add_widget(LineSeparator())

        # Add search field
        search_field = MDTextField(
            hint_text="Digite a matrícula para filtrar...",
            mode="rectangle",
            icon_left="magnify",
            size_hint_y=None,
            height='48dp'
        )
        content.add_widget(search_field)
        content.add_widget(LineSeparator())

        # Create scroll view and grid
        scroll = ScrollView(size_hint=(1, None), height='300dp')
        grid = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
        grid.bind(minimum_height=grid.setter('height'))
        scroll.add_widget(grid)
        content.add_widget(scroll)

        # Function to update the grid with filtered matriculas
        def update_grid(filtered_matriculas):
            grid.clear_widgets()
            if not filtered_matriculas:
                grid.add_widget(MDLabel(
                    text="Nenhuma matrícula encontrada",
                    halign='center',
                    theme_text_color="Secondary",
                    size_hint_y=None,
                    height='40dp'
                ))
            else:
                for matricula in filtered_matriculas:
                    card = MDCard(
                        size_hint_y=None,
                        height='80dp',
                        elevation=2,
                        padding='12dp',
                        radius=[8]
                    )

                    card_layout = BoxLayout(orientation='vertical', spacing='4dp')
                    top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='25dp')
                    top_row.add_widget(MDLabel(
                        text=f"[b]{matricula['matricula']}[/b]",
                        markup=True,
                        theme_text_color="Primary",
                        font_style="H6",
                        size_hint_x=0.7
                    ))

                    estado = matricula['estado_pagamento']
                    estado_color = "Primary" if estado.lower() == "pago" else "Error"
                    top_row.add_widget(MDLabel(
                        text=f"{estado}",
                        theme_text_color=estado_color,
                        font_style="Caption",
                        size_hint_x=0.3,
                        halign='right'
                    ))
                    card_layout.add_widget(top_row)

                    bottom_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='20dp')
                    bottom_row.add_widget(MDIconButton(icon="map-marker", size_hint_x=None, width='24dp', theme_text_color="Secondary"))
                    bottom_row.add_widget(MDLabel(text=f"Local: {matricula['local']}", theme_text_color="Secondary", font_style="Caption", size_hint_x=0.6))

                    created_time = matricula['created_at']
                    if created_time != 'N/A':
                        try:
                            created_dt = datetime.strptime(created_time, '%Y-%m-%d %H:%M:%S')
                            created_time = created_dt.strftime('%H:%M:%S')
                        except:
                            pass
                    bottom_row.add_widget(MDLabel(text=f"Hora: {created_time}", theme_text_color="Secondary", font_style="Caption", size_hint_x=0.4, halign='right'))
                    card_layout.add_widget(bottom_row)

                    card.add_widget(card_layout)
                    grid.add_widget(card)

        # Function to filter matriculas based on search text
        def filter_matriculas(instance, search_text):
            if not search_text.strip():
                filtered = all_matriculas
            else:
                search_lower = search_text.lower()
                filtered = [m for m in all_matriculas if search_lower in m['matricula'].lower()]
            update_grid(filtered)

        # Bind search field to filter function
        search_field.bind(text=filter_matriculas)

        # Initial display
        update_grid(all_matriculas)

        stats_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='40dp', spacing='20dp')
        total_label = MDLabel(
            text=f"[b]Total hoje:[/b] {len(all_matriculas)}",
            markup=True,
            theme_text_color="Primary",
            halign='center'
        )
        stats_layout.add_widget(total_label)
        content.add_widget(stats_layout)

        # Update total count when filtering
        def update_total(filtered_count):
            total_label.text = f"[b]Total filtrado:[/b] {filtered_count}"

        # Modify filter function to update total
        def filter_matriculas_with_total(instance, search_text):
            if not search_text.strip():
                filtered = all_matriculas
            else:
                search_lower = search_text.lower()
                filtered = [m for m in all_matriculas if search_lower in m['matricula'].lower()]
            update_grid(filtered)
            update_total(len(filtered))

        search_field.bind(text=filter_matriculas_with_total)

        dialog = MDDialog(
            type="custom",
            content_cls=content,
            size_hint=(0.95, 0.9),
            buttons=[MDFlatButton(text="FECHAR", on_release=lambda x: dialog.dismiss())]
        )
        dialog.open()

    def show_matricula_details(self, matricula_data):
        """Mostra detalhes completos da matrícula com todas as informações solicitadas"""
        try:
            app = MDApp.get_running_app()

            # Buscar estatísticas e histórico da matrícula
            estatisticas = self.buscar_estatisticas_matricula(matricula_data['matricula'])
            historico_registros = self.buscar_historico_registros(matricula_data['matricula'])

            content = ScrollView(size_hint=(1, 1))
            main_layout = BoxLayout(
                orientation='vertical',
                spacing=dp(15),
                padding=dp(20),
                size_hint_y=None
            )
            main_layout.bind(minimum_height=main_layout.setter('height'))

            # Título
            titulo = MDLabel(
                text=f"DETALHES COMPLETOS - {matricula_data['matricula']}",
                theme_text_color="Primary",
                font_style="H6",
                bold=True,
                size_hint_y=None,
                height=dp(40),
                halign='center'
            )
            main_layout.add_widget(titulo)

            # SEÇÃO 1: INFORMAÇÕES BÁSICAS
            sec_basica = self._criar_secao("INFORMAÇÕES BÁSICAS", [
                f"Matrícula: {matricula_data['matricula']}",
                f"Local do registro: {matricula_data['local']}",
                f"Utilizador: {matricula_data.get('usuario_email', 'N/A')}",
                f"Status: {matricula_data.get('status', 'Ativa')}",
                f"Data: {matricula_data.get('created_at', 'N/A')}",
                f"Estado Pagamento: {matricula_data.get('estado_pagamento', 'pendente')}"
            ])
            main_layout.add_widget(sec_basica)

            # Separador
            main_layout.add_widget(LineSeparator())

            # SEÇÃO 2: ESTATÍSTICAS
            sec_estatisticas = self._criar_secao("ESTATÍSTICAS", [
                f"Total de registros hoje: {estatisticas.get('registros_hoje', 1)}",
                f"Total de registros históricos: {estatisticas.get('total_registros', 1)}",
                f"Última atualização: {estatisticas.get('ultima_atualizacao', 'N/A')}",
                f"Fonte: {matricula_data.get('source', 'Local DB')}"
            ])
            main_layout.add_widget(sec_estatisticas)

            # Separador
            main_layout.add_widget(LineSeparator())

            # SEÇÃO 3: HISTÓRICO DE REGISTROS (se disponível)
            if historico_registros:
                sec_historico = BoxLayout(
                    orientation='vertical',
                    size_hint_y=None,
                    height=dp(40 + len(historico_registros) * 25),
                    spacing=dp(5)
                )

                sec_historico.add_widget(MDLabel(
                    text="HISTÓRICO DE REGISTROS",
                    theme_text_color="Primary",
                    font_style="Subtitle1",
                    bold=True,
                    size_hint_y=None,
                    height=dp(30)
                ))

                for i, registro in enumerate(historico_registros[:5]):  # Mostrar últimos 5
                    cor = "Primary" if i == 0 else "Secondary"
                    sec_historico.add_widget(MDLabel(
                        text=f"• {registro.get('data', 'N/A')} - {registro.get('utilizador', 'N/A')}",
                        theme_text_color=cor,
                        font_style="Caption",
                        size_hint_y=None,
                        height=dp(20)
                    ))

                main_layout.add_widget(sec_historico)
                main_layout.add_widget(LineSeparator())

            # SEÇÃO 4: AÇÕES
            sec_acoes = BoxLayout(
                orientation='vertical',
                size_hint_y=None,
                height=dp(100),
                spacing=dp(10)
            )

            sec_acoes.add_widget(MDLabel(
                text="⚙️ AÇÕES",
                theme_text_color="Primary",
                font_style="Subtitle1",
                bold=True,
                size_hint_y=None,
                height=dp(30)
            ))

            # Botões de ação
            btn_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(50), spacing=dp(10))

            # Botão para alterar estado de pagamento
            estado_atual = matricula_data['estado_pagamento']
            novo_estado = "pago" if estado_atual.lower() != "pago" else "pendente"
            btn_estado = MDRaisedButton(
                text=f"Marcar como {'Pago' if novo_estado == 'pago' else 'Pendente'}",
                size_hint_x=0.5,
                md_bg_color=(0.0, 0.36, 0.80, 1),
                on_release=lambda x: self.toggle_payment_status(matricula_data['matricula'], novo_estado)
            )

            # Botão para copiar matrícula
            btn_copiar = MDFlatButton(
                text="Copiar Matrícula",
                size_hint_x=0.5,
                on_release=lambda x: self.copiar_matricula(matricula_data['matricula'])
            )

            btn_layout.add_widget(btn_estado)
            btn_layout.add_widget(btn_copiar)
            sec_acoes.add_widget(btn_layout)

            main_layout.add_widget(sec_acoes)

            content.add_widget(main_layout)

            # Diálogo
            dialog = MDDialog(
                title="",
                type="custom",
                content_cls=content,
                buttons=[
                    MDFlatButton(
                        text="FECHAR",
                        on_release=lambda x: dialog.dismiss()
                    )
                ],
                size_hint=(0.95, 0.9)
            )
            dialog.open()

        except Exception as e:
            logging.error(f"Erro ao mostrar detalhes: {str(e)}")
            self.show_result(f"❌ Erro ao carregar detalhes: {str(e)}", "error")

    def _criar_secao(self, titulo: str, itens: List[str]) -> BoxLayout:
        """Cria uma seção organizada para os detalhes"""
        secao = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(40 + len(itens) * 25),
            spacing=dp(5)
        )
        
        secao.add_widget(MDLabel(
            text=titulo,
            theme_text_color="Primary",
            font_style="Subtitle1",
            bold=True,
            size_hint_y=None,
            height=dp(30)
        ))
        
        for item in itens:
            secao.add_widget(MDLabel(
                text=item,
                theme_text_color="Secondary",
                font_style="Body1",
                size_hint_y=None,
                height=dp(25)
            ))
        
        return secao

    def buscar_estatisticas_matricula(self, matricula):
        """Busca estatísticas da matrícula"""
        try:
            app = MDApp.get_running_app()
            
            # Buscar todos os registros desta matrícula no banco local
            registros = app.db_manager.get_viaturas_by_matricula(matricula)
            
            if not registros:
                return {
                    'total_registros': 1,
                    'registros_hoje': 1,
                    'ultima_atualizacao': datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                }
            
            # Contar registros do dia atual
            hoje = datetime.now().date()
            registros_hoje = 0
            
            for registro in registros:
                if 'created_at' in registro:
                    try:
                        data_registro = datetime.strptime(registro['created_at'], '%Y-%m-%d %H:%M:%S').date()
                        if data_registro == hoje:
                            registros_hoje += 1
                    except:
                        continue
            
            return {
                'total_registros': len(registros),
                'registros_hoje': registros_hoje,
                'ultima_atualizacao': registros[0].get('created_at', 'N/A') if registros else 'N/A'
            }
            
        except Exception as e:
            logging.error(f"Erro ao buscar estatísticas: {str(e)}")
            return {'total_registros': 1, 'registros_hoje': 1, 'ultima_atualizacao': 'N/A'}

    def buscar_historico_registros(self, matricula):
        """Busca histórico de registros da matrícula"""
        try:
            app = MDApp.get_running_app()
            registros = app.db_manager.get_viaturas_by_matricula(matricula)
            
            if not registros:
                return []
            
            historico = []
            for registro in registros:
                historico.append({
                    'data': registro.get('created_at', 'N/A'),
                    'utilizador': registro.get('usuario_email', 'N/A'),
                    'local': registro.get('local', 'N/A'),
                    'estado': registro.get('estado_pagamento', 'Desconhecido')
                })
            
            # Ordenar por data (mais recente primeiro)
            historico.sort(key=lambda x: x['data'], reverse=True)
            return historico
            
        except Exception as e:
            logging.error(f"Erro ao buscar histórico: {str(e)}")
            return []

    def copiar_matricula(self, matricula):
        """Copia matrícula para área de transferência"""
        try:
            import subprocess
            # Para Linux
            subprocess.run(['xclip', '-selection', 'clipboard'], input=matricula.encode('utf-8'))
            self.show_result(f"✅ Matrícula {matricula} copiada!", "success")
        except Exception as e:
            logging.error(f"Erro ao copiar matrícula: {str(e)}")
            self.show_result("❌ Erro ao copiar matrícula", "error")

    def toggle_payment_status(self, matricula, novo_estado):
        """Alterna o estado de pagamento de uma matrícula"""
        try:
            app = MDApp.get_running_app()
            success = app.db_manager.update_payment_status(matricula, novo_estado)

            if success:
                self.show_result(f"✅ Estado de pagamento atualizado para '{novo_estado}'", "success")
                # Fechar diálogo atual e reabrir lista atualizada
                Clock.schedule_once(lambda dt: self.listar_matriculas(), 0.5)
            else:
                self.show_result("❌ Erro ao atualizar estado de pagamento", "error")

        except Exception as e:
            self.show_result(f"❌ Erro: {str(e)}", "error")

    def filter_paid_matriculas(self):
        """Filtra e mostra apenas as matrículas pagas do dia atual do usuário logado"""
        try:
            app = MDApp.get_running_app()
            
            # Verificar se há usuário logado
            if not app.current_user:
                self.show_result("❌ Nenhum usuário logado", "error")
                return
                
            user_id = app.current_user.get('user_id')
            if not user_id:
                self.show_result("❌ ID do usuário não encontrado", "error")
                return
            
            # Mostrar feedback visual
            self.show_result("🔍 Buscando matrículas pagas...", "info")
            self.show_loading(True)
            
            # Processar em background
            Clock.schedule_once(lambda dt: self._fetch_paid_matriculas_from_firebase(user_id), 0.1)
            
        except Exception as e:
            logging.error(f"Erro ao filtrar matrículas pagas: {str(e)}")
            self.show_result(f"❌ Erro: {str(e)}", "error")
            self.show_loading(False)

    def _fetch_paid_matriculas_from_firebase(self, user_id):
        """Busca matrículas pagas do Firebase para o usuário específico"""
        try:
            app = MDApp.get_running_app()
            
            # DEBUG: Verificar qual user_id está sendo usado
            logging.info(f"🔍 User ID do usuário logado: {user_id}")
            logging.info(f"🔍 Email do usuário logado: {app.current_user.get('email')}")
            
            # Construir o caminho correto - usar o user_id dos dados reais
            # Baseado na estrutura: users/EioIMD5YUQYZL6Ll6x6GRWYlikA3/estacionamentos
            firebase_path = f"users/{user_id}/estacionamentos"
            
            logging.info(f"🔍 Buscando em: {firebase_path}")
            
            # Buscar dados do Firebase
            data = app.firebase.get_db_data(firebase_path)
            
            logging.info(f"🔍 Dados recebidos: {data}")
            
            # Se não encontrar dados, tentar buscar todos os estacionamentos
            if not data:
                logging.warning("🔍 Nenhum dado encontrado no caminho específico do usuário")
                logging.info("🔍 Tentando buscar dados gerais...")
                
                # Tentar caminho alternativo - todos os estacionamentos
                alternative_path = "estacionamentos"
                data = app.firebase.get_db_data(alternative_path)
                logging.info(f"🔍 Dados do caminho alternativo: {data}")
                
                if not data:
                    self.show_loading(False)
                    self.show_result("ℹ️ Nenhum registro de estacionamento encontrado", "info")
                    return
            
            # Processar os dados para extrair matrículas pagas do dia
            today = datetime.now().strftime('%Y-%m-%d')
            paid_matriculas = []
            
            logging.info(f"🔍 Processando {len(data) if data else 0} registros...")
            
            # Estrutura dos dados: cada registro tem um ID único com dados dentro
            for registro_id, dados_registro in data.items():
                try:
                    # Verificar se os dados são válidos
                    if not dados_registro or not isinstance(dados_registro, dict):
                        continue
                    
                    # Extrair informações do registro
                    matricula = dados_registro.get('matricula', '')
                    status = dados_registro.get('status', '')
                    data_criacao = dados_registro.get('data_criacao', '')
                    
                    # Converter data_criacao para formato de data simples
                    if data_criacao:
                        try:
                            # Converter de "2025-10-29T14:24:38.590276" para "2025-10-29"
                            if 'T' in data_criacao:
                                data_simples = data_criacao.split('T')[0]
                            else:
                                data_simples = data_criacao
                        except:
                            data_simples = data_criacao
                    else:
                        data_simples = ''
                    
                    logging.info(f"🔍 Analisando {matricula}: status='{status}', data='{data_simples}'")
                    
                    # Critérios para "pago": status ATIVO e data de hoje
                    is_active = status and status.upper() == 'ATIVO'
                    is_today = data_simples == today
                    
                    if is_active and is_today:
                        paid_matriculas.append({
                            'matricula': matricula,
                            'registro_id': registro_id,
                            'local': dados_registro.get('endereco', 'N/A'),
                            'data_registro': data_simples,
                            'hora_registro': dados_registro.get('hora_inicio', 'N/A'),
                            'estado_pagamento': 'pago',  # Consideramos ATIVO como pago
                            'status': status,
                            'usuario_email': dados_registro.get('usuario', 'N/A'),
                            'metodo_pagamento': dados_registro.get('metodo_pagamento', 'N/A'),
                            'valor': dados_registro.get('valor', 'N/A'),
                            'source': 'Firebase'
                        })
                        logging.info(f"✅ {matricula} adicionada (ATIVA hoje)")
                    else:
                        logging.info(f"❌ {matricula} não atende: ativa={is_active}, hoje={is_today}")
                            
                except Exception as e:
                    logging.warning(f"Erro ao processar {registro_id}: {str(e)}")
                    continue
            
            logging.info(f"🔍 Matrículas pagas encontradas: {len(paid_matriculas)}")
            
            # Ordenar por hora
            paid_matriculas.sort(key=lambda x: x.get('hora_registro', ''), reverse=True)
            
            self.show_loading(False)
            
            if paid_matriculas:
                self.show_result(f"✅ {len(paid_matriculas)} matrículas ativas hoje", "success")
                self._show_paid_matriculas_dialog(paid_matriculas)
            else:
                self.show_result("ℹ️ Nenhuma matrícula ativa encontrada para hoje", "info")
                    
        except Exception as e:
            logging.error(f"Erro ao buscar matrículas: {str(e)}")
            self.show_loading(False)
            self.show_result(f"❌ Erro: {str(e)}", "error")

    def filter_all_paid_matriculas(self):
        """Busca TODAS as matrículas pagas/ativas de hoje, de todos os usuários"""
        try:
            app = MDApp.get_running_app()
            
            self.show_result("🔍 Buscando todas as matrículas ativas...", "info")
            self.show_loading(True)
            
            Clock.schedule_once(lambda dt: self._fetch_all_paid_matriculas(), 0.1)
            
        except Exception as e:
            logging.error(f"Erro ao buscar todas as matrículas: {str(e)}")
            self.show_result(f"❌ Erro: {str(e)}", "error")
            self.show_loading(False)

    def _fetch_all_paid_matriculas(self):
        """Busca matrículas ativas de todos os usuários"""
        try:
            app = MDApp.get_running_app()
            
            # Buscar de caminho raiz - todos os estacionamentos
            firebase_path = "estacionamentos"
            
            logging.info(f"🔍 Buscando TODOS os estacionamentos em: {firebase_path}")
            
            data = app.firebase.get_db_data(firebase_path)
            
            logging.info(f"🔍 Dados recebidos: {data}")
            
            # Verificar se houve erro de permissão
            if data is None:
                self.show_loading(False)
                self.show_result("❌ Sem permissão para acessar os dados", "error")
                return
                
            if not data:
                self.show_loading(False)
                self.show_result("ℹ️ Nenhum estacionamento encontrado", "info")
                return
            
            today = datetime.now().strftime('%Y-%m-%d')
            paid_matriculas = []
            
            logging.info(f"🔍 Processando {len(data)} registros totais...")
            
            for registro_id, dados_registro in data.items():
                try:
                    if not dados_registro or not isinstance(dados_registro, dict):
                        continue
                    
                    matricula = dados_registro.get('matricula', '')
                    status = dados_registro.get('status', '')
                    data_criacao = dados_registro.get('data_criacao', '')
                    user_id = dados_registro.get('user_id', '')
                    
                    # Converter data
                    data_simples = ''
                    if data_criacao and 'T' in data_criacao:
                        data_simples = data_criacao.split('T')[0]
                    
                    logging.info(f"🔍 {matricula} (User: {user_id}): status='{status}', data='{data_simples}'")
                    
                    # Critérios
                    is_active = status and status.upper() == 'ATIVO'
                    is_today = data_simples == today
                    
                    if is_active and is_today:
                        paid_matriculas.append({
                            'matricula': matricula,
                            'registro_id': registro_id,
                            'local': dados_registro.get('endereco', 'N/A'),
                            'data_registro': data_simples,
                            'hora_registro': dados_registro.get('hora_inicio', 'N/A'),
                            'estado_pagamento': 'pago',
                            'status': status,
                            'usuario_email': dados_registro.get('usuario', 'N/A'),
                            'user_id': user_id,
                            'metodo_pagamento': dados_registro.get('metodo_pagamento', 'N/A'),
                            'valor': dados_registro.get('valor', 'N/A'),
                            'source': 'Firebase (Todos)'
                        })
                        logging.info(f"✅ {matricula} - ATIVA hoje")
                            
                except Exception as e:
                    logging.warning(f"Erro em {registro_id}: {str(e)}")
                    continue
            
            self.show_loading(False)
            
            if paid_matriculas:
                self.show_result(f"✅ {len(paid_matriculas)} matrículas ativas hoje", "success")
                self._show_paid_matriculas_dialog(paid_matriculas)
            else:
                self.show_result("ℹ️ Nenhuma matrícula ativa hoje", "info")
                    
        except Exception as e:
            logging.error(f"Erro ao buscar todas: {str(e)}")
            self.show_loading(False)
            self.show_result(f"❌ Erro: {str(e)}", "error")

    def _show_paid_matriculas_dialog(self, paid_matriculas):
        """Mostra diálogo com matrículas pagas"""
        today = datetime.now().strftime('%d/%m/%Y')
        
        content = BoxLayout(orientation='vertical', spacing='12dp', padding='12dp', size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        # Header
        header = BoxLayout(orientation='horizontal', size_hint_y=None, height='50dp')
        header.add_widget(MDLabel(
            text=f"[size=18][b]MATRÍCULAS PAGAS - HOJE ({today})[/b][/size]",
            markup=True,
            halign='center',
            size_hint_x=1
        ))
        content.add_widget(header)
        content.add_widget(LineSeparator())
        
        # Search field
        search_field = MDTextField(
            hint_text="Filtrar matrículas...",
            mode="rectangle",
            icon_left="magnify",
            size_hint_y=None,
            height='48dp'
        )
        content.add_widget(search_field)
        content.add_widget(LineSeparator())
        
        # Scroll view for results
        scroll = ScrollView(size_hint=(1, None), height='300dp')
        grid = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
        grid.bind(minimum_height=grid.setter('height'))
        scroll.add_widget(grid)
        content.add_widget(scroll)
        
        # Function to update grid with filtered results
        def update_grid(filtered_matriculas):
            grid.clear_widgets()
            
            if not filtered_matriculas:
                grid.add_widget(MDLabel(
                    text="Nenhuma matrícula paga encontrada para hoje",
                    halign='center',
                    theme_text_color="Secondary",
                    size_hint_y=None,
                    height='40dp'
                ))
            else:
                for matricula in filtered_matriculas:
                    card = MDCard(
                        size_hint_y=None,
                        height='90dp',
                        elevation=2,
                        padding='12dp',
                        radius=[8]
                    )
                    
                    card_layout = BoxLayout(orientation='vertical', spacing='4dp')
                    
                    # Top row - Matrícula e status
                    top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='30dp')
                    top_row.add_widget(MDLabel(
                        text=f"[b]{matricula['matricula']}[/b]",
                        markup=True,
                        theme_text_color="Primary",
                        font_style="H6",
                        size_hint_x=0.7
                    ))
                    
                    top_row.add_widget(MDLabel(
                        text="✅ PAGO",
                        theme_text_color="Primary",
                        font_style="Caption",
                        bold=True,
                        size_hint_x=0.3,
                        halign='right'
                    ))
                    card_layout.add_widget(top_row)
                    
                    # Middle row - Local
                    middle_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='25dp')
                    middle_row.add_widget(MDIconButton(
                        icon="map-marker", 
                        size_hint_x=None, 
                        width='24dp', 
                        theme_text_color="Secondary"
                    ))
                    middle_row.add_widget(MDLabel(
                        text=f"Local: {matricula['local']}",
                        theme_text_color="Secondary", 
                        font_style="Caption",
                        size_hint_x=0.8
                    ))
                    card_layout.add_widget(middle_row)
                    
                    # Bottom row - Hora e usuário
                    bottom_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='25dp')
                    bottom_row.add_widget(MDLabel(
                        text=f"Hora: {matricula.get('hora_registro', 'N/A')}",
                        theme_text_color="Secondary",
                        font_style="Caption",
                        size_hint_x=0.5
                    ))
                    bottom_row.add_widget(MDLabel(
                        text=f"Por: {matricula.get('usuario_email', 'N/A')}",
                        theme_text_color="Secondary",
                        font_style="Caption",
                        size_hint_x=0.5,
                        halign='right'
                    ))
                    card_layout.add_widget(bottom_row)
                    
                    card.add_widget(card_layout)
                    grid.add_widget(card)
        
        # Filter function
        def filter_matriculas(instance, search_text):
            if not search_text.strip():
                filtered = paid_matriculas
            else:
                search_lower = search_text.lower()
                filtered = [m for m in paid_matriculas if search_lower in m['matricula'].lower()]
            update_grid(filtered)
        
        # Bind search field
        search_field.bind(text=filter_matriculas)
        
        # Initial display
        update_grid(paid_matriculas)
        
        # Statistics
        stats_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='40dp')
        stats_layout.add_widget(MDLabel(
            text=f"[b]Total de matrículas pagas hoje: {len(paid_matriculas)}[/b]",
            markup=True,
            theme_text_color="Primary",
            halign='center',
            size_hint_x=1
        ))
        content.add_widget(stats_layout)
        
        # Dialog
        dialog = MDDialog(
            type="custom",
            content_cls=content,
            size_hint=(0.95, 0.9),
            buttons=[
                MDFlatButton(
                    text="FECHAR",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()

    def show_about(self):
        """Mostra a tela sobre o aplicativo"""
        self.manager.current = 'about'


    def verificar_pagamento_status(self, matricula):
        """
        Verifica o status de pagamento no Firebase
        """
        try:
            app = MDApp.get_running_app()
            
            # Validar formato da matrícula primeiro
            if not self.validar_formato_matricula(matricula):
                return {
                    'sucesso': False,
                    'mensagem': 'Formato de matrícula inválido'
                }
            
            logging.info(f"🔍 Verificando status de pagamento para: {matricula}")
            
            # Consultar Firebase
            resultado = app.firebase.get_pagamento_status(matricula)
            
            if resultado['encontrado']:
                return {
                    'sucesso': True,
                    'encontrado': True,
                    'matricula': resultado['matricula'],
                    'status_pagamento': resultado['status_pagamento'],
                    'dados_completos': resultado['dados'],
                    'mensagem': f"Status de pagamento: {resultado['status_pagamento']}"
                }
            else:
                return {
                    'sucesso': True,
                    'encontrado': False,
                    'matricula': resultado['matricula'],
                    'mensagem': resultado.get('mensagem', 'Matrícula não encontrada')
                }
                
        except Exception as e:
            logging.error(f"❌ Erro na verificação de pagamento: {str(e)}")
            return {
                'sucesso': False,
                'mensagem': f"Erro: {str(e)}"
            }
    
    def listar_todos_pagamentos_status(self):
        """
        Lista todos os status de pagamento do Firebase
        """
        try:
            app = MDApp.get_running_app()
            
            logging.info("🔍 Buscando todos os status de pagamento...")
            
            resultado = app.firebase.get_all_pagamentos_status()
            
            if resultado['encontrado']:
                return {
                    'sucesso': True,
                    'total_registros': resultado['total_registros'],
                    'dados': resultado['dados'],
                    'mensagem': f"Encontrados {resultado['total_registros']} registros"
                }
            else:
                return {
                    'sucesso': True,
                    'total_registros': 0,
                    'dados': {},
                    'mensagem': resultado.get('mensagem', 'Nenhum registro encontrado')
                }
                
        except Exception as e:
            logging.error(f"❌ Erro ao listar pagamentos: {str(e)}")
            return {
                'sucesso': False,
                'mensagem': f"Erro: {str(e)}"
            }
    
    def verificar_pagamento_e_estacionamento(self, matricula):
        """
        Verificação combinada: status de pagamento + estacionamento ativo
        """
        try:
            logging.info(f"🔍 Verificação combinada para: {matricula}")
            
            # 1. Verificar status de pagamento
            resultado_pagamento = self.verificar_pagamento_status(matricula)
            
            # 2. Verificar estacionamento ativo
            resultado_estacionamento = self.verificar_estacionamento_ativo(matricula)
            
            # Combinar resultados
            resultado_combinado = {
                'matricula': matricula,
                'timestamp': datetime.now().isoformat(),
                'pagamento': resultado_pagamento,
                'estacionamento': resultado_estacionamento,
                'verificacao_completa': True
            }
            
            # Determinar status geral
            if (resultado_pagamento.get('sucesso') and 
                resultado_pagamento.get('encontrado') and 
                resultado_pagamento.get('status_pagamento', '').upper() == 'PAGO'):
                resultado_combinado['status_geral'] = 'REGULAR'
                resultado_combinado['mensagem_geral'] = '✅ Pagamento em dia'
            elif resultado_estacionamento.get('ativo'):
                resultado_combinado['status_geral'] = 'ATIVO'
                resultado_combinado['mensagem_geral'] = '✅ Estacionamento ativo'
            else:
                resultado_combinado['status_geral'] = 'IRREGULAR'
                resultado_combinado['mensagem_geral'] = '⚠️ Verificar situação'
            
            return resultado_combinado
            
        except Exception as e:
            logging.error(f"❌ Erro na verificação combinada: {str(e)}")
            return {
                'sucesso': False,
                'mensagem': f"Erro: {str(e)}"
            }

    def show_pagamento_status(self):
        """
        Diálogo para verificar status de pagamento específico
        """
        content = BoxLayout(orientation='vertical', spacing='15dp', padding='20dp')
        
        # Campo de entrada
        input_field = MDTextField(
            hint_text="Digite a matrícula",
            icon_left="car",
            mode="rectangle",
            size_hint_y=None,
            height='48dp'
        )
        content.add_widget(input_field)
        
        # Resultado
        result_label = MDLabel(
            text="Digite uma matrícula para verificar",
            theme_text_color="Secondary",
            halign='center',
            size_hint_y=None,
            height='60dp'
        )
        content.add_widget(result_label)
        
        # Botões
        btn_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='48dp', spacing='10dp')
        
        def verificar_status(instance):
            matricula = input_field.text.strip()
            if not matricula:
                result_label.text = "❌ Digite uma matrícula"
                result_label.theme_text_color = "Error"
                return
            
            # Mostrar loading
            result_label.text = "🔍 Consultando..."
            result_label.theme_text_color = "Secondary"
            
            # Processar em background
            def processar(dt):
                resultado = self.verificar_pagamento_status(matricula)
                
                if resultado['sucesso']:
                    if resultado['encontrado']:
                        status = resultado['status_pagamento']
                        cor = "Primary" if status.upper() == 'PAGO' else "Error"
                        result_label.text = f"✅ Status: {status}"
                        result_label.theme_text_color = cor
                    else:
                        result_label.text = "ℹ️ Matrícula não encontrada"
                        result_label.theme_text_color = "Secondary"
                else:
                    result_label.text = f"❌ {resultado['mensagem']}"
                    result_label.theme_text_color = "Error"
            
            Clock.schedule_once(processar, 0.1)
        
        btn_verificar = MDRaisedButton(
            text="VERIFICAR",
            size_hint_x=0.6,
            on_release=verificar_status
        )
        
        btn_fechar = MDFlatButton(
            text="FECHAR",
            size_hint_x=0.4,
            on_release=lambda x: dialog.dismiss()
        )
        
        btn_layout.add_widget(btn_verificar)
        btn_layout.add_widget(btn_fechar)
        content.add_widget(btn_layout)
        
        dialog = MDDialog(
            title="Verificar Status de Pagamento",
            type="custom",
            content_cls=content,
            size_hint=(0.9, 0.6)
        )
        dialog.open()
    
    def show_todos_pagamentos(self):
        """
        Mostra todos os pagamentos do dia com status 'successful' 
        E verifica validade baseado na data e status
        """
        try:
            app = MDApp.get_running_app()
            
            # Obter data atual
            data_hoje = datetime.now().date()
            data_hoje_str = data_hoje.strftime('%Y-%m-%d')
            
            logging.info(f"🔍 Buscando pagamentos para: {data_hoje_str}")
            
            # Buscar todos os pagamentos do Firebase no caminho específico
            resultado = self._buscar_pagamentos_firebase()
            
            if not resultado['sucesso'] or not resultado.get('dados'):
                self.show_result("ℹ️ Nenhum pagamento encontrado", "info")
                return
            
            # Filtrar pagamentos válidos
            pagamentos_validos = []
            pagamentos_expirados = []
            
            dados_pagamentos = resultado['dados']
            
            for pagamento_id, dados_pagamento in dados_pagamentos.items():
                if not dados_pagamento:
                    continue
                    
                # Extrair informações do pagamento
                matricula = dados_pagamento.get('matricula', '')
                status = dados_pagamento.get('status', '').lower()
                data_criacao = dados_pagamento.get('dataCriacao', '')
                data_expiracao = dados_pagamento.get('dataExpiracao', '')
                data_pagamento = dados_pagamento.get('dataPagamento', '')
                
                logging.info(f"🔍 Analisando {matricula}: status={status}, dataCriacao={data_criacao}, dataExpiracao={data_expiracao}")
                
                # ✅ VERIFICAÇÃO 1: Status deve ser 'successful' ou 'active'
                status_valido = status in ['successful', 'active', 'ativo', 'activo', 'completed']
                if not status_valido:
                    continue
                
                # ✅ VERIFICAÇÃO 2: Verificar data de criação (se é do dia atual)
                data_criacao_obj = None
                if data_criacao:
                    try:
                        if 'T' in data_criacao:
                            data_criacao_obj = datetime.fromisoformat(data_criacao.replace('Z', '+00:00')).date()
                        else:
                            data_criacao_obj = datetime.strptime(data_criacao.split()[0], '%Y-%m-%d').date()
                    except Exception as e:
                        logging.warning(f"Erro ao converter dataCriacao {data_criacao}: {str(e)}")
                
                # ✅ VERIFICAÇÃO 3: Verificar data de expiração
                data_expiracao_obj = None
                expirado = False
                
                if data_expiracao:
                    try:
                        if 'T' in data_expiracao:
                            data_expiracao_obj = datetime.fromisoformat(data_expiracao.replace('Z', '+00:00')).date()
                        else:
                            data_expiracao_obj = datetime.strptime(data_expiracao.split()[0], '%Y-%m-%d').date()
                        
                        # Verificar se já expirou
                        if data_expiracao_obj < data_hoje:
                            expirado = True
                            logging.info(f"❌ Pagamento EXPIRADO: {matricula} (expirou em: {data_expiracao_obj})")
                        else:
                            logging.info(f"✅ Pagamento VÁLIDO: {matricula} (válido até: {data_expiracao_obj})")
                            
                    except Exception as e:
                        logging.warning(f"Erro ao converter dataExpiracao {data_expiracao}: {str(e)}")
                
                # ✅ VERIFICAÇÃO 4: Data do pagamento
                data_pagamento_obj = None
                if data_pagamento:
                    try:
                        if 'T' in data_pagamento:
                            data_pagamento_obj = datetime.fromisoformat(data_pagamento.replace('Z', '+00:00')).date()
                        else:
                            data_pagamento_obj = datetime.strptime(data_pagamento.split()[0], '%Y-%m-%d').date()
                    except:
                        pass
                
                # Classificar o pagamento
                pagamento_info = {
                    'id': pagamento_id,
                    'matricula': matricula,
                    'dados': dados_pagamento,
                    'data_criacao': data_criacao_obj,
                    'data_expiracao': data_expiracao_obj,
                    'data_pagamento': data_pagamento_obj,
                    'status': status,
                    'expirado': expirado
                }
                
                if expirado:
                    pagamentos_expirados.append(pagamento_info)
                else:
                    pagamentos_validos.append(pagamento_info)
            
            # Ordenar pagamentos válidos por data de expiração (mais próximos primeiro)
            pagamentos_validos.sort(key=lambda x: (
                x['data_expiracao'] if x['data_expiracao'] else datetime.max.date(),
                x['data_criacao'] if x['data_criacao'] else datetime.min.date()
            ))
            
            # Ordenar pagamentos expirados por data de expiração (mais recentes primeiro)
            pagamentos_expirados.sort(key=lambda x: (
                x['data_expiracao'] if x['data_expiracao'] else datetime.min.date()
            ), reverse=True)
            
            # Mostrar resultados
            self._mostrar_dialog_pagamentos_completo(pagamentos_validos, pagamentos_expirados, data_hoje)
            
        except Exception as e:
            logging.error(f"Erro ao buscar pagamentos: {str(e)}")
            self.show_result(f"❌ Erro: {str(e)}", "error")

    def _buscar_pagamentos_firebase(self):
        """
        Busca pagamentos no Firebase nos caminhos específicos
        """
        try:
            app = MDApp.get_running_app()
            
            # Caminhos possíveis para pagamentos
            caminhos = [
                "ussd/pagamentosstatus",
                "pagamentos",
                "estacionamentos",  # Pode conter informações de pagamento
                "users"  # Pagamentos por usuário
            ]
            
            todos_pagamentos = {}
            
            for caminho in caminhos:
                try:
                    logging.info(f"🔍 Buscando em: {caminho}")
                    data = app.firebase.get_db_data(caminho)
                    
                    if data and isinstance(data, dict):
                        logging.info(f"✅ Encontrados {len(data)} registros em {caminho}")
                        
                        # Processar dados para extrair informações de pagamento
                        for key, value in data.items():
                            if value and isinstance(value, dict):
                                # Verificar se tem informações de pagamento relevantes
                                if any(field in value for field in ['status', 'matricula', 'dataCriacao', 'dataExpiracao']):
                                    pagamento_id = f"{caminho}/{key}"
                                    todos_pagamentos[pagamento_id] = value
                    else:
                        logging.info(f"ℹ️ Nenhum dado em {caminho}")
                        
                except Exception as e:
                    logging.warning(f"Erro ao buscar em {caminho}: {str(e)}")
                    continue
            
            return {
                'sucesso': True,
                'encontrado': len(todos_pagamentos) > 0,
                'total_registros': len(todos_pagamentos),
                'dados': todos_pagamentos,
                'mensagem': f"Encontrados {len(todos_pagamentos)} registros" if todos_pagamentos else "Nenhum registro encontrado"
            }
            
        except Exception as e:
            logging.error(f"Erro ao buscar pagamentos no Firebase: {str(e)}")
            return {
                'sucesso': False,
                'encontrado': False,
                'mensagem': f"Erro: {str(e)}"
            }

    def _mostrar_dialog_pagamentos_completo(self, pagamentos_validos, pagamentos_expirados, data_consulta):
        """Mostra diálogo completo com pagamentos válidos e expirados"""
        
        data_formatada = data_consulta.strftime('%d/%m/%Y')
        
        content = BoxLayout(orientation='vertical', spacing='12dp', padding='12dp', size_hint_y=None)
        content.bind(minimum_height=content.setter('height'))
        
        # Header
        header = BoxLayout(orientation='horizontal', size_hint_y=None, height='50dp')
        header.add_widget(MDLabel(
            text=f"[size=18][b]RELATÓRIO DE PAGAMENTOS - {data_formatada}[/b][/size]",
            markup=True,
            halign='center',
            size_hint_x=1
        ))
        content.add_widget(header)
        content.add_widget(LineSeparator())
        
        # Seção de Pagamentos Válidos
        if pagamentos_validos:
            content.add_widget(MDLabel(
                text=f"✅ PAGAMENTOS VÁLIDOS ({len(pagamentos_validos)})",
                theme_text_color="Primary",
                font_style="H6",
                bold=True,
                size_hint_y=None,
                height='40dp'
            ))
            
            valid_scroll = ScrollView(size_hint=(1, None), height='300dp')
            valid_content = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
            valid_content.bind(minimum_height=valid_content.setter('height'))
            
            for i, pagamento in enumerate(pagamentos_validos, 1):
                card = self._criar_card_pagamento(pagamento, i, "valido")
                valid_content.add_widget(card)
            
            valid_scroll.add_widget(valid_content)
            content.add_widget(valid_scroll)
        
        # Seção de Pagamentos Expirados
        if pagamentos_expirados:
            content.add_widget(MDLabel(
                text=f"❌ PAGAMENTOS EXPIRADOS ({len(pagamentos_expirados)})",
                theme_text_color="Error",
                font_style="H6",
                bold=True,
                size_hint_y=None,
                height='40dp'
            ))
            
            expired_scroll = ScrollView(size_hint=(1, None), height='200dp')
            expired_content = GridLayout(cols=1, spacing='8dp', size_hint_y=None, padding='8dp')
            expired_content.bind(minimum_height=expired_content.setter('height'))
            
            for i, pagamento in enumerate(pagamentos_expirados, 1):
                card = self._criar_card_pagamento(pagamento, i, "expirado")
                expired_content.add_widget(card)
            
            expired_scroll.add_widget(expired_content)
            content.add_widget(expired_scroll)
        
        # Mensagem se não houver pagamentos
        if not pagamentos_validos and not pagamentos_expirados:
            content.add_widget(MDLabel(
                text="Nenhum pagamento encontrado",
                halign='center',
                theme_text_color="Secondary",
                size_hint_y=None,
                height='60dp'
            ))
        
        # Estatísticas
        stats_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height='40dp', spacing='10dp')
        
        stats_text = [
            f"[b]✅ {len(pagamentos_validos)} válidos[/b]",
            f"[color=ff3333]❌ {len(pagamentos_expirados)} expirados[/color]",
            f"[b]📊 Total: {len(pagamentos_validos) + len(pagamentos_expirados)}[/b]"
        ]
        
        for stat in stats_text:
            stats_layout.add_widget(MDLabel(
                text=stat,
                markup=True,
                theme_text_color="Primary",
                halign='center',
                size_hint_x=0.33
            ))
        
        content.add_widget(stats_layout)
        
        # Diálogo
        dialog = MDDialog(
            type="custom",
            content_cls=content,
            size_hint=(0.98, 0.95),
            buttons=[
                MDFlatButton(
                    text="FECHAR",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()
        
        # Mostrar resultado na tela principal
        total_pagamentos = len(pagamentos_validos) + len(pagamentos_expirados)
        if total_pagamentos > 0:
            self.show_result(f"✅ {len(pagamentos_validos)} válidos | ❌ {len(pagamentos_expirados)} expirados", "success")
        else:
            self.show_result("ℹ️ Nenhum pagamento encontrado", "info")

    def _criar_card_pagamento(self, pagamento, numero, tipo):
        """Cria um card individual para pagamento"""
        
        card = MDCard(
            size_hint_y=None,
            height='130dp' if tipo == "valido" else '110dp',
            elevation=2,
            padding='12dp',
            radius=[8]
        )
        
        card_layout = BoxLayout(orientation='vertical', spacing='4dp')
        
        # Top row - Número e matrícula
        top_row = BoxLayout(orientation='horizontal', size_hint_y=None, height='30dp')
        top_row.add_widget(MDLabel(
            text=f"{numero}. {pagamento['matricula']}",
            theme_text_color="Primary",
            font_style="H6",
            bold=True,
            size_hint_x=0.7
        ))
        
        # Status baseado no tipo
        if tipo == "valido":
            data_expiracao = pagamento['data_expiracao']
            if data_expiracao:
                hoje = datetime.now().date()
                dias_restantes = (data_expiracao - hoje).days
                
                if dias_restantes <= 3:
                    status_text = f"⚠️ {dias_restantes}d"
                    status_color = "Error"
                elif dias_restantes <= 7:
                    status_text = f"🟡 {dias_restantes}d"
                    status_color = "Secondary"
                else:
                    status_text = f"✅ {dias_restantes}d"
                    status_color = "Primary"
            else:
                status_text = "✅ VÁLIDO"
                status_color = "Primary"
        else:
            status_text = "❌ EXPIRADO"
            status_color = "Error"
        
        top_row.add_widget(MDLabel(
            text=status_text,
            theme_text_color=status_color,
            font_style="Caption",
            bold=True,
            size_hint_x=0.3,
            halign='right'
        ))
        card_layout.add_widget(top_row)
        
        # Detalhes do pagamento
        dados = pagamento['dados']
        detalhes = []
        
        if dados.get('valor'):
            detalhes.append(f"💰 {dados['valor']}")
        
        if dados.get('metodoPagamento'):
            detalhes.append(f"💳 {dados['metodoPagamento']}")
        
        # Data de criação
        data_criacao = pagamento['data_criacao']
        if data_criacao:
            detalhes.append(f"📅 Criado: {data_criacao.strftime('%d/%m/%Y')}")
        
        if detalhes:
            card_layout.add_widget(MDLabel(
                text=" | ".join(detalhes),
                theme_text_color="Secondary",
                font_style="Caption",
                size_hint_y=None,
                height='25dp'
            ))
        
        # Informações de validade/expiração
        info_tempo = []
        
        data_expiracao = pagamento['data_expiracao']
        if data_expiracao:
            if tipo == "valido":
                info_tempo.append(f"⏰ Válido até: {data_expiracao.strftime('%d/%m/%Y')}")
            else:
                info_tempo.append(f"⏰ Expirou em: {data_expiracao.strftime('%d/%m/%Y')}")
        
        # Informações adicionais
        if dados.get('usuario'):
            info_tempo.append(f"👤 {dados['usuario']}")
        
        if dados.get('local'):
            info_tempo.append(f"📍 {dados['local']}")
        
        if info_tempo:
            card_layout.add_widget(MDLabel(
                text=" | ".join(info_tempo),
                theme_text_color="Secondary",
                font_style="Caption",
                size_hint_y=None,
                height='20dp'
            ))
        
        card.add_widget(card_layout)
        return card



class AboutScreen(MDScreen):
    def go_back(self):
        self.manager.current = 'main'

class VerificaçãoApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.current_user = None
        self.firebase = FirebaseManager()
        self.db_manager = DatabaseManager()
        self.session_manager = SessionManager(self.firebase, self.db_manager)
        self.sync_manager = SyncManager(self.db_manager, self.firebase, self.session_manager)
        self.test_manager = TestManager(self)
        self.permissions_checked = False

    def on_start(self):
        try:
            self.check_permissions()
            if hasattr(self.firebase, 'offline_cache'):
                self.firebase.offline_cache.cleanup_expired_cache()
        except Exception as e:
            logging.error(f"Erro nas permissões: {e}")
            # Carrega sessão mesmo se falhar permissão
            self.load_session()
        
    def check_permissions(self):
        def on_permissions_checked(granted):
            self.permissions_checked = True

        try:
            permissions_manager.check_all_permissions(on_permissions_checked)
        except:
            self.load_session()

    def show_permissions_error(self):
        dialog = MDDialog(
            title="Permissões Necessárias",
            text="O aplicativo precisa de permissões para funcionar corretamente.",
            buttons=[
                MDFlatButton(
                    text="SAIR",
                    on_release=lambda x: self.stop()
                ),
                MDRaisedButton(
                    text="TENTAR NOVAMENTE",
                    on_release=lambda x: self.check_permissions()
                )
            ],
            radius=[10, 10, 10, 10]
        )
        dialog.open()

    def run_tests(self):
        def on_tests_completed(results):
            self.show_test_results(results)

        self.test_manager.run_all_tests(on_tests_completed)

    def show_test_results(self, results):
        summary = self.test_manager.get_test_summary()

        content = BoxLayout(
            orientation='vertical',
            spacing=dp(10),
            size_hint_y=None,
            height=dp(200)
        )

        content.add_widget(MDLabel(
            text=f"Total: {summary['total_tests']} | Aprovados: {summary['passed_tests']} | Reprovados: {summary['failed_tests']}",
            theme_text_color="Primary"
        ))

        content.add_widget(MDLabel(
            text=f"Taxa de sucesso: {summary['success_rate']:.1f}%",
            theme_text_color="Secondary"
        ))

        if summary['results']:
            content.add_widget(MDLabel(
                text="Últimos testes:",
                theme_text_color="Primary",
                font_style="H6"
            ))

            for result in summary['results'][-5:]:
                status_icon = "✓" if result['result'] == "PASSOU" else "✗"
                content.add_widget(MDLabel(
                    text=f"{status_icon} {result['category']}: {result['test_name']}",
                    theme_text_color="Primary" if result['result'] == "PASSOU" else "Error",
                    font_style="Caption"
                ))

        dialog = MDDialog(
            title="Resultados dos Testes",
            type="custom",
            content_cls=content,
            buttons=[
                MDRaisedButton(
                    text="VER RELATÓRIO COMPLETO",
                    on_release=lambda x: self.show_full_test_report()
                ),
                MDFlatButton(
                    text="FECHAR",
                    on_release=lambda x: dialog.dismiss()
                )
            ]
        )
        dialog.open()

    def show_full_test_report(self):
        try:
            with open('test_report.txt', 'r', encoding='utf-8') as f:
                report_content = f.read()

            dialog = MDDialog(
                title="Relatório Completo de Testes",
                text=report_content[:1000] + "..." if len(report_content) > 1000 else report_content,
                buttons=[
                    MDFlatButton(
                        text="FECHAR",
                        on_release=lambda x: dialog.dismiss()
                    )
                ]
            )
            dialog.open()

        except FileNotFoundError:
            dialog = MDDialog(
                title="Erro",
                text="Relatório de testes não encontrado. Execute os testes primeiro.",
                buttons=[
                    MDFlatButton(
                        text="OK",
                        on_release=lambda x: dialog.dismiss()
                    )
                ]
            )
            dialog.open()

    def load_session(self):
        try:
            from kivy.storage.jsonstore import JsonStore
            store = JsonStore('session.json')
            if store.exists('auth'):
                auth_data = store.get('auth')
                self.root.current = 'main'
            else:
                self.root.current = 'login'
        except:
            self.root.current = 'login'

    def on_stop(self):
        logging.info("Encerrando aplicação...")
        
        try:
            if hasattr(self, 'sync_manager'):
                try:
                    self.sync_manager.stop_sync_service()
                except Exception as e:
                    logging.warning(f"Erro ao parar sincronização: {e}")
            
            if hasattr(self, 'firebase'):
                try:
                    if hasattr(self.firebase, 'save_tokens'):
                        self.firebase.save_tokens()
                    elif hasattr(self.firebase, '_save_tokens'):
                        self.firebase._save_tokens()
                except Exception as e:
                    logging.warning(f"Erro ao salvar tokens: {e}")
            
            if hasattr(self, 'current_user') and self.current_user:
                try:
                    self._save_session_before_exit()
                except Exception as e:
                    logging.warning(f"Erro ao salvar sessão: {e}")
                    
        except Exception as e:
            logging.error(f"Erro geral no encerramento: {e}")
        
        logging.info("Aplicação encerrada")

    def _save_session_before_exit(self):
        from kivy.storage.jsonstore import JsonStore
        try:
            store = JsonStore('session.json')
            store.put('auth',
                email=self.current_user['email'],
                refresh_token=self.current_user.get('refreshToken', ''),
                stats=self.current_user.get('stats', {
                    'pesquisas': 0,
                    'registros': 0,
                    'ultimas_viaturas': []
                })
            )
        except Exception as e:
            logging.error(f"Erro ao salvar sessão final: {e}")

    def animate_logo(self, logo):
        # Modern entrance animation with bounce effect
        entrance = (
            Animation(opacity=0, scale=0.8, duration=0.1) +
            Animation(opacity=1, scale=1.1, duration=0.8, t='out_back') +
            Animation(scale=1.0, duration=0.4, t='out_bounce')
        )

        # Breathing effect with subtle rotation
        breathe = (
            Animation(scale=1.05, angle=2, duration=2.0, t='in_out_sine') +
            Animation(scale=0.98, angle=-1, duration=2.0, t='in_out_sine') +
            Animation(scale=1.02, angle=0, duration=1.5, t='in_out_sine')
        )

        # Pulse effect for modern feel
        pulse = (
            Animation(scale=1.08, opacity=0.95, duration=0.6, t='out_quad') +
            Animation(scale=1.0, opacity=1.0, duration=0.8, t='in_out_quad')
        )

        # Combine animations
        modern_sequence = entrance + breathe + pulse

        entrance.start(logo)

        def start_breathing(*args):
            breathe.repeat = True
            breathe.start(logo)

            # Add occasional pulse
            def add_pulse(*args):
                if hasattr(logo, '_pulse_scheduled'):
                    return
                logo._pulse_scheduled = True
                Clock.schedule_once(lambda dt: pulse.start(logo), 0)
                Clock.schedule_once(lambda dt: setattr(logo, '_pulse_scheduled', False), 3)

            Clock.schedule_interval(add_pulse, 4)

        entrance.bind(on_complete=start_breathing)

    def build(self):
        try:
            self.theme_cls.primary_palette = "Blue"
            self.theme_cls.theme_style = "Light"
            Builder.load_string(KV)
            from kivy.uix.screenmanager import ScreenManager
            sm = ScreenManager()
            sm.add_widget(SplashScreen(name='splash'))
            sm.add_widget(LoginScreen(name='login'))
            sm.add_widget(MainScreen(name='main'))
            sm.add_widget(CameraScreen(name='camera'))
            sm.add_widget(AboutScreen(name='about'))
            sm.current = 'splash'
            return sm
        except Exception as e:
            import traceback
            error_msg = traceback.format_exc()
            # Salva crash log no diretório gravável
            crash_log_path = os.path.join(log_dir, 'crash_build.log')
            with open(crash_log_path, 'w') as f:
                f.write(error_msg)
            # Retorna um app mínimo para ver o erro
            from kivy.uix.label import Label
            return Label(text=f"Erro na inicialização:\n{str(e)[:200]}")

if __name__ == '__main__':
    VerificaçãoApp().run()
