#!/usr/bin/env python3
"""
Script para criar manualmente um funcionário do tipo "verificar" no sistema Emme Verificação
Este script cria apenas o registro no banco local, assumindo que o funcionário já foi criado no Firebase
"""

import sys
import os
import hashlib
import json
from datetime import datetime

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database_manager import DatabaseManager

def criar_funcionario_manual():
    """Cria um funcionário manualmente no banco local"""

    # Dados do funcionário (assumindo que já foi criado no Firebase)
    funcionario_data = {
        'nome': 'João Verificador',
        'codigo': 'VER001',
        'email': 'verificar@emme.com',
        'tipo': 'verificar',
        'status': 'ativo',
        'meta_diaria': 250,
        'user_id': 'nDV8mPuJQbSaXuheUQ0i3D0Cza42',  # User ID obtido anteriormente
        'data_criacao': datetime.now().isoformat(),
        'permissoes': {
            'verificar_matriculas': True,
            'registrar_viaturas': True,
            'visualizar_relatorios': False,
            'gerir_usuarios': False,
            'gerir_senhas': False
        }
    }

    # Senha inicial (mesma usada no Firebase)
    senha = 'Verificar123!'
    password_hash = hashlib.sha256(senha.encode()).hexdigest()

    print("🔧 Criando funcionário manualmente no banco local...")
    print(f"📧 Email: {funcionario_data['email']}")
    print(f"👤 Nome: {funcionario_data['nome']}")
    print(f"🏷️  Tipo: {funcionario_data['tipo']}")
    print(f"📊 Meta diária: {funcionario_data['meta_diaria']}")
    print(f"🆔 User ID: {funcionario_data['user_id']}")

    # Inicializar gerenciador do banco
    db_manager = DatabaseManager()

    try:
        # Verificar se o usuário já existe
        usuario_existente = db_manager.get_user(funcionario_data['email'])
        if usuario_existente:
            print("⚠️  Usuário já existe no banco local, atualizando dados...")
        else:
            print("📝 Criando novo usuário no banco local...")

        # Salvar/atualizar no banco local
        print("\n💽 Salvando no banco de dados local...")
        stats_iniciais = {
            'pesquisas': 0,
            'registros': 0,
            'ultimas_viaturas': [],
            'ultimas_verificacoes': [],
            'meta_diaria': funcionario_data['meta_diaria']
        }

        success = db_manager.save_user(
            email=funcionario_data['email'],
            password_hash=password_hash,
            firebase_uid=funcionario_data['user_id'],
            stats=stats_iniciais
        )

        if success:
            print("✅ Funcionário salvo no banco local com sucesso")

            # Adicionar ao histórico
            db_manager.add_historico(
                funcionario_data['email'],
                'criacao_funcionario_manual',
                None,
                f'Funcionário {funcionario_data["tipo"]} criado manualmente: {funcionario_data["nome"]}'
            )
            print("✅ Histórico de criação adicionado")
        else:
            print("❌ Erro ao salvar no banco local")
            return False

        print("\n🎉 Funcionário criado com sucesso no banco local!")
        print("\n" + "="*60)
        print("INSTRUÇÕES PARA COMPLETAR A CRIAÇÃO:")
        print("="*60)
        print("1. ACESSE O FIREBASE CONSOLE:")
        print("   https://console.firebase.google.com/project/emmeprojectv01/database/emmeprojectv01-default-rtdb/data")
        print()
        print("2. NAVEGUE ATÉ A TABELA 'Funcionarios'")
        print()
        print("3. CRIE UM NOVO REGISTRO COM O SEGUINTE CAMINHO:")
        print(f"   Funcionarios/{funcionario_data['user_id']}")
        print()
        print("4. COLE OS SEGUINTES DADOS JSON:")
        print(json.dumps(funcionario_data, indent=2, ensure_ascii=False))
        print()
        print("="*60)
        print("DADOS DO FUNCIONÁRIO CRIADO:")
        print("="*60)
        print(f"Nome: {funcionario_data['nome']}")
        print(f"Email: {funcionario_data['email']}")
        print(f"Tipo: {funcionario_data['tipo']}")
        print(f"Código: {funcionario_data['codigo']}")
        print(f"Status: {funcionario_data['status']}")
        print(f"Meta diária: {funcionario_data['meta_diaria']}")
        print(f"User ID: {funcionario_data['user_id']}")
        print(f"Senha inicial: {senha}")
        print("="*60)
        print("\n⚠️  IMPORTANTE:")
        print("   - Anote a senha inicial e forneça ao funcionário!")
        print("   - O funcionário deve alterar a senha no primeiro login.")
        print("   - Complete a criação no Firebase Console seguindo as instruções acima.")

        return True

    except Exception as e:
        print(f"❌ Erro inesperado: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🚀 Criando funcionário manualmente...")
    sucesso = criar_funcionario_manual()

    if sucesso:
        print("\n✅ Processo concluído com sucesso!")
        print("   Agora complete a criação no Firebase Console.")
        sys.exit(0)
    else:
        print("\n❌ Falha na criação do funcionário!")
        sys.exit(1)
