import logging
from datetime import datetime

class SessionManager:
    def __init__(self, firebase_manager, database_manager):
        self.firebase = firebase_manager
        self.db = database_manager
        self.current_user = None
        self.logger = logging.getLogger(__name__)
    
    def create_session(self, user_data):
        """Cria uma sessão de usuário"""
        self.current_user = user_data
        self.logger.info(f"Sessão criada para: {user_data.get('email')}")
        return True
    
    def get_current_user(self):
        """Retorna usuário atual"""
        return self.current_user
    
    def refresh_session_if_needed(self):
        """Verifica se precisa renovar a sessão"""
        if not self.current_user:
            return False
        return True
    
    def get_current_user_email(self):
        """Retorna email do usuário atual"""
        return self.current_user.get('email') if self.current_user else None
    
    def destroy_session(self):
        """Destrói a sessão atual"""
        self.current_user = None
        self.logger.info("Sessão destruída")
