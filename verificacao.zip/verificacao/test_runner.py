#!/usr/bin/env python3
"""
Script para executar testes automatizados sem interface gráfica
"""

import sys
import os
import logging

# Adicionar diretório atual ao path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('test_execution.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

class MockApp:
    """Mock da aplicação para testes"""
    def __init__(self):
        self.current_user = None
        self.db_manager = None
        self.firebase = None
        self.sync_manager = None
        self.session_manager = None

def run_tests():
    """Executa todos os testes"""
    try:
        from test_manager import TestManager

        # Criar app mock
        mock_app = MockApp()

        # Criar test manager
        test_manager = TestManager(mock_app)

        # Resultados dos testes
        test_results = []

        def test_callback(results):
            test_results.extend(results)
            logging.info("Testes concluídos!")

        # Executar testes
        logging.info("Iniciando suite de testes...")
        test_manager.run_all_tests(test_callback)

        # Aguardar conclusão (simular)
        import time
        time.sleep(5)  # Tempo para testes completarem

        # Mostrar resumo
        summary = test_manager.get_test_summary()
        logging.info(f"=== RESUMO DOS TESTES ===")
        logging.info(f"Total: {summary['total_tests']}")
        logging.info(f"Aprovados: {summary['passed_tests']}")
        logging.info(f"Reprovados: {summary['failed_tests']}")
        logging.info(f"Taxa de sucesso: {summary['success_rate']:.1f}%")

        # Verificar se relatório foi gerado
        if os.path.exists('test_report.txt'):
            logging.info("Relatório de testes gerado: test_report.txt")
        else:
            logging.warning("Relatório de testes não foi gerado")

        return summary

    except Exception as e:
        logging.error(f"Erro ao executar testes: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == '__main__':
    logging.info("=== INICIANDO EXECUÇÃO DE TESTES ===")
    results = run_tests()
    if results:
        success_rate = results['success_rate']
        if success_rate >= 80:
            logging.info("✓ Testes passaram com sucesso!")
            sys.exit(0)
        else:
            logging.warning(f"⚠️ Taxa de sucesso baixa: {success_rate:.1f}%")
            sys.exit(1)
    else:
        logging.error("✗ Falha na execução dos testes")
        sys.exit(1)
